import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function generateAccountNumber() {
  const prefix = Math.random() > 0.5 ? "4" : "6";
  const rest = Array.from({ length: 9 }, () => Math.floor(Math.random() * 10)).join("");
  return prefix + rest;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();

    const { firstName, lastName, email, accountType, password, pin } = body;

    if (!firstName || !lastName || !email || !accountType || !password || !pin) {
      return Response.json({ error: "Missing required fields" }, { status: 400 });
    }

    const accountNumber = generateAccountNumber();
    const fullName = `${firstName} ${lastName}`;

    const emailBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f4f4; margin: 0; padding: 0; }
    .container { max-width: 580px; margin: 20px auto; background: #fff; border-radius: 8px; overflow: hidden; }
    .header { background: #00bcd4; padding: 20px; text-align: center; }
    .header-logo { font-size: 22px; font-weight: bold; color: #fff; letter-spacing: 2px; }
    .header-sub { font-size: 13px; color: #e0f7fa; letter-spacing: 1px; }
    .welcome-band { background: #111; padding: 24px; text-align: center; }
    .welcome-band h1 { color: #fff; font-size: 32px; margin: 0; letter-spacing: 4px; }
    .body { padding: 28px 32px; color: #333; font-size: 14px; line-height: 1.7; }
    .body p { margin: 0 0 14px; }
    .table { width: 100%; border-collapse: collapse; margin: 18px 0; }
    .table td { border: 1px solid #ddd; padding: 9px 14px; font-size: 14px; }
    .table td:first-child { color: #555; background: #f9f9f9; width: 45%; }
    .table td:last-child { font-weight: 600; color: #111; }
    .link { color: #00bcd4; text-decoration: none; }
    .footer { background: #00bcd4; padding: 18px; text-align: center; }
    .footer p { color: #fff; font-size: 14px; font-weight: bold; margin: 0 0 4px; }
    .footer small { color: #e0f7fa; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="header-logo">&#9711; CINNIONCPF</div>
      <div class="header-sub">FINANCE BANK</div>
    </div>
    <div class="welcome-band">
      <h1>WELCOME</h1>
    </div>
    <div class="body">
      <p>Hello, <strong>${fullName}</strong></p>
      <p>Thank you so much for allowing us to help you with your recent account opening. We are committed to providing our customers with the highest level of service and the most innovative banking products possible.</p>
      <p>We are very glad you choose us as your financial institution and hope you will take advantage of our wide variety of savings, investment and loan products, all designed to meet your specific needs.</p>
      <p><strong>Your account is been Processed and we will get back to you once your account is been verified</strong></p>
      <table class="table">
        <tr><td>Full name</td><td>${fullName}</td></tr>
        <tr><td>Account No</td><td>${accountNumber}</td></tr>
        <tr><td>Account Type</td><td>${accountType}</td></tr>
        <tr><td>Account Password</td><td>****</td></tr>
        <tr><td>Account Pin</td><td>****</td></tr>
      </table>
      <p>Please use your <strong>Account No: ${accountNumber}</strong> as your Account ID when logging in.</p>
      <p>For more detailed information about any of our products or services, please refer to our website, <a href="http://cinnioncpf.com/account" class="link">http://cinnioncpf.com/account</a>, or visit any of our convenient locations.</p>
      <p>Respectfully,<br/><strong>cinnioncpf</strong></p>
    </div>
    <div class="footer">
      <p>Need more help?</p>
      <small>We're here to help you out</small>
    </div>
  </div>
</body>
</html>
    `;

    // Save account record to database for admin management
    try {
      await base44.asServiceRole.entities.BankAccount.create({
        accountNumber,
        fullName,
        email,
        accountType,
        balance: 0,
        status: "active",
        country: body.country || "",
        phone: body.phone || "",
      });
    } catch (dbErr) {
      console.log("DB save note:", dbErr.message);
    }

    // Try to send email - works for app users
    try {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: email,
        subject: `Welcome ${fullName} - cinnioncpf`,
        body: emailBody,
        from_name: "CraftCredit Finance Bank"
      });
    } catch (emailErr) {
      // Email may fail for non-registered users; still return account number
      console.log("Email send note:", emailErr.message);
    }

    return Response.json({
      success: true,
      accountNumber,
      fullName,
      message: "Account created successfully."
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});