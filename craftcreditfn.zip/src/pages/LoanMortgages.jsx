import React, { useState } from "react";
import DashboardLayout from "../components/dashboard/DashboardLayout";
import { DollarSign, ArrowRight } from "lucide-react";

const inputCls = "w-full px-3 py-3 border border-gray-200 rounded text-sm text-gray-700 placeholder-gray-300 outline-none focus:border-blue-400";

export default function LoanMortgages() {
  const [form, setForm] = useState({ amount: "", narration: "" });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <DashboardLayout>
      <div className="p-5 pb-16">
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h1 className="text-xl font-semibold text-gray-800 text-center mb-6">Loan/Mortages Application</h1>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-500 block mb-1">Amount</label>
              <div className="flex items-center border border-gray-200 rounded overflow-hidden">
                <span className="px-3 py-3 bg-gray-50 border-r border-gray-200"><DollarSign className="w-4 h-4 text-blue-400" /></span>
                <input className="flex-1 px-3 py-3 text-sm outline-none placeholder-gray-300" placeholder="Amount" value={form.amount} onChange={e => set("amount", e.target.value)} type="number" />
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-500 block mb-1">Receiver (Customer Care)</label>
              <input className={inputCls + " bg-gray-50"} value="Customer Service" readOnly />
            </div>
            <div>
              <label className="text-sm text-gray-500 block mb-1">Naration/Purpose</label>
              <textarea className={inputCls + " h-28 resize-none"} placeholder="Loan Description" value={form.narration} onChange={e => set("narration", e.target.value)} />
            </div>
            <div className="flex justify-center pt-2">
              <button className="flex items-center gap-2 px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700">
                <ArrowRight className="w-4 h-4" /> Submit
              </button>
            </div>
          </div>
        </div>
        <p className="text-center text-xs text-gray-400 mt-8">Copyright © 2025 Cinnioncpf Finance Bank. All rights reserved.</p>
      </div>
    </DashboardLayout>
  );
}