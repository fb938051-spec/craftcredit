import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Check, Eye, EyeOff, Copy, Loader2, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

const COUNTRIES = [
  "Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia","Australia","Austria",
  "Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin",
  "Bolivia","Bosnia & Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Cambodia","Cameroon",
  "Canada","Chile","China","Colombia","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic",
  "Denmark","Dominican Republic","Ecuador","Egypt","El Salvador","Estonia","Ethiopia","Finland",
  "France","Gabon","Georgia","Germany","Ghana","Greece","Guatemala","Haiti","Honduras","Hungary",
  "Iceland","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan","Jordan",
  "Kazakhstan","Kenya","Kuwait","Latvia","Lebanon","Libya","Lithuania","Luxembourg","Malaysia",
  "Maldives","Mali","Malta","Mexico","Moldova","Morocco","Mozambique","Myanmar","Nepal","Netherlands",
  "New Zealand","Nicaragua","Nigeria","Norway","Oman","Pakistan","Panama","Paraguay","Peru",
  "Philippines","Poland","Portugal","Qatar","Romania","Russia","Rwanda","Saudi Arabia","Senegal",
  "Serbia","Singapore","Slovakia","Slovenia","South Africa","South Korea","South Sudan","Spain",
  "Sri Lanka","Sudan","Sweden","Switzerland","Syria","Taiwan","Tanzania","Thailand","Togo",
  "Trinidad & Tobago","Tunisia","Turkey","Uganda","Ukraine","United Arab Emirates","United Kingdom",
  "United States","Uruguay","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"
];

const ACCOUNT_TYPES = [
  "Savings Account","Current Account","Premium Checking Account",
  "Fixed Deposit","Non Resident Account","Online Banking","Joint Account"
];

function StepIndicator({ current }) {
  return (
    <div className="flex items-center justify-center gap-0 mb-6">
      {[1, 2, 3, "✓"].map((s, i) => {
        const stepNum = i + 1;
        const done = current > stepNum;
        const active = current === stepNum;
        const isCheck = i === 3;
        return (
          <React.Fragment key={i}>
            <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-all
              ${done || (isCheck && current > 3) ? "bg-blue-600 border-blue-600 text-white" :
                active ? "bg-blue-600 border-blue-600 text-white" :
                "bg-white border-gray-300 text-gray-400"}`}>
              {isCheck ? <Check className="w-4 h-4" /> : s}
            </div>
            {i < 3 && <div className={`h-[2px] w-10 sm:w-14 ${current > stepNum ? "bg-blue-600" : "bg-gray-200"}`} />}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function FieldError({ msg }) {
  if (!msg) return null;
  return <p className="text-red-500 text-xs mt-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />{msg}</p>;
}

function ValidationBanner({ errors }) {
  const msgs = Object.values(errors).filter(Boolean);
  if (msgs.length === 0) return null;
  return (
    <div className="bg-red-50 border border-red-300 rounded-lg px-4 py-3 mb-4 flex gap-2">
      <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
      <div>
        <p className="text-red-700 text-sm font-semibold mb-1">Please fix the following errors:</p>
        <ul className="list-disc list-inside space-y-0.5">
          {msgs.map((m, i) => <li key={i} className="text-red-600 text-xs">{m}</li>)}
        </ul>
      </div>
    </div>
  );
}

const baseCls = "w-full px-3 py-3 bg-gray-100 rounded text-sm text-gray-700 placeholder-gray-400 border outline-none transition-colors";
const inputCls = (err) => `${baseCls} ${err ? "border-red-400 bg-red-50 focus:bg-red-50" : "border-transparent focus:bg-gray-200"}`;
const selectCls = (err) => `w-full px-3 py-3 bg-gray-100 rounded text-sm text-gray-500 border outline-none appearance-none transition-colors ${err ? "border-red-400 bg-red-50" : "border-transparent focus:bg-gray-200"}`;

export default function CreateAccount() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [captchaInput, setCaptchaInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [generatedAccountNumber, setGeneratedAccountNumber] = useState("");
  const [copied, setCopied] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});

  const [form, setForm] = useState({
    firstName: "", lastName: "", occupation: "", country: "", currency: "DOLLAR $",
    gender: "male", street: "", apt: "", city: "", state: "", zip: "",
    email: "", accountType: "", password: "", confirmPassword: "", pin: "", phone: "",
    dob: "", profileImage: null, idFront: null, idBack: null,
  });

  const set = (k, v) => {
    setForm(f => ({ ...f, [k]: v }));
    // Clear error for that field on change
    setFieldErrors(e => ({ ...e, [k]: "" }));
  };

  const captchaCode = "NJ269";

  // ── Step validators ─────────────────────────────────────────────
  const validateStep1 = () => {
    const errs = {};
    if (!form.firstName.trim()) errs.firstName = "First Name is required.";
    if (!form.lastName.trim()) errs.lastName = "Last Name is required.";
    if (!form.country) errs.country = "Please select your country.";
    if (!form.street.trim()) errs.street = "Street Address is required.";
    if (!form.city.trim()) errs.city = "City is required.";
    if (!form.state.trim()) errs.state = "State is required.";
    if (!form.zip.trim()) errs.zip = "Zip Code is required.";
    return errs;
  };

  const validateStep2 = () => {
    const errs = {};
    if (!form.email.trim()) {
      errs.email = "Email Address is required.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = "Please enter a valid email address.";
    }
    if (!form.accountType) errs.accountType = "Please select an account type.";
    if (!form.password) {
      errs.password = "Password is required.";
    } else if (form.password.length < 6) {
      errs.password = "Password must be at least 6 characters.";
    }
    if (!form.confirmPassword) {
      errs.confirmPassword = "Please confirm your password.";
    } else if (form.password !== form.confirmPassword) {
      errs.confirmPassword = "Passwords do not match.";
    }
    if (!form.pin) {
      errs.pin = "PIN is required.";
    } else if (form.pin.length < 4) {
      errs.pin = "PIN must be at least 4 digits.";
    }
    if (!form.phone.trim()) {
      errs.phone = "Phone Number is required.";
    } else if (!/^\+?[\d\s\-()]{7,}$/.test(form.phone)) {
      errs.phone = "Please enter a valid phone number.";
    }
    return errs;
  };

  const validateStep3 = () => {
    const errs = {};
    if (!form.dob) {
      errs.dob = "Date of Birth is required.";
    } else {
      const age = Math.floor((Date.now() - new Date(form.dob)) / (365.25 * 24 * 60 * 60 * 1000));
      if (age < 18) errs.dob = "You must be at least 18 years old to open an account.";
    }
    return errs;
  };

  const goNext = (validator, nextStep) => {
    const errs = validator();
    setFieldErrors(errs);
    if (Object.keys(errs).length === 0) {
      setStep(nextStep);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleSubmit = async () => {
    const errs = {};
    if (!form.profileImage) errs.profileImage = "Profile image is required.";
    if (!form.idFront) errs.idFront = "ID Card Front is required.";
    if (!form.idBack) errs.idBack = "ID Card Back is required.";
    if (!captchaInput.trim()) {
      errs.captcha = "Please enter the captcha code.";
    } else if (captchaInput.toUpperCase() !== captchaCode) {
      errs.captcha = "Captcha is incorrect. Please try again.";
    }
    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setSubmitError("");
    setLoading(true);

    // Convert profile image to base64 for localStorage storage
    let profileImageBase64 = null;
    if (form.profileImage) {
      profileImageBase64 = await new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.readAsDataURL(form.profileImage);
      });
    }

    const response = await base44.functions.invoke("createBankAccount", {
      firstName: form.firstName,
      lastName: form.lastName,
      email: form.email,
      accountType: form.accountType,
      password: form.password,
      pin: form.pin,
      phone: form.phone,
      country: form.country,
      currency: form.currency,
      gender: form.gender,
      dob: form.dob,
    });

    setLoading(false);

    const data = response.data;
    if (data && data.success) {
      const accountNumber = data.accountNumber;
      setGeneratedAccountNumber(accountNumber);

      const accounts = JSON.parse(localStorage.getItem("bankAccounts") || "[]");
      accounts.push({
        accountNumber,
        fullName: `${form.firstName} ${form.lastName}`,
        accountType: form.accountType,
        password: form.password,
        pin: form.pin,
        email: form.email,
        profileImage: profileImageBase64,
      });
      localStorage.setItem("bankAccounts", JSON.stringify(accounts));
      setShowSuccess(true);
    } else {
      setSubmitError(data?.error || "Something went wrong. Please try again.");
    }
  };

  const copyAccountNumber = () => {
    navigator.clipboard.writeText(generatedAccountNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="relative h-44 overflow-hidden">
        <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=600&h=300&fit=crop" alt="header" className="w-full h-full object-cover object-top" />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <h1 className="text-3xl font-bold text-white text-center leading-tight">Create Your Bank<br />Account</h1>
        </div>
      </div>

      <div className="px-5 pt-6">
        <p className="text-center text-gray-500 text-sm mb-5">Fill all required fields (*) to proceed to the next step</p>
        <StepIndicator current={step} />

        {/* STEP 1 — Personal Info */}
        {step === 1 && (
          <div>
            <h2 className="font-bold text-gray-900 text-lg mb-1">Personal Info</h2>
            <p className="text-gray-400 text-xs mb-4">Fields marked with * are required.</p>

            <ValidationBanner errors={fieldErrors} />

            <div className="space-y-3">
              <div>
                <input className={inputCls(fieldErrors.firstName)} placeholder="First Name *" value={form.firstName} onChange={e => set("firstName", e.target.value)} />
                <FieldError msg={fieldErrors.firstName} />
              </div>
              <div>
                <input className={inputCls(fieldErrors.lastName)} placeholder="Last Name *" value={form.lastName} onChange={e => set("lastName", e.target.value)} />
                <FieldError msg={fieldErrors.lastName} />
              </div>
              <div>
                <input className={inputCls(false)} placeholder="Occupation (optional)" value={form.occupation} onChange={e => set("occupation", e.target.value)} />
              </div>
              <div>
                <div className="relative">
                  <select className={selectCls(fieldErrors.country)} value={form.country} onChange={e => set("country", e.target.value)}>
                    <option value="">Select Country *</option>
                    {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  <span className="absolute right-3 top-3.5 text-gray-400 pointer-events-none">▾</span>
                </div>
                <FieldError msg={fieldErrors.country} />
              </div>
              <div className="relative">
                <select className={selectCls(false)} value={form.currency} onChange={e => set("currency", e.target.value)}>
                  <option>DOLLAR $</option><option>EURO €</option><option>GBP £</option>
                </select>
                <span className="absolute right-3 top-3.5 text-gray-400 pointer-events-none">▾</span>
              </div>
              <div className="flex items-center gap-4 py-1">
                <span className="text-gray-600 text-sm font-medium">Gender</span>
                {["male", "female"].map(g => (
                  <label key={g} className="flex items-center gap-1.5 text-sm text-gray-700 cursor-pointer">
                    <input type="radio" name="gender" value={g} checked={form.gender === g} onChange={() => set("gender", g)} className="accent-blue-600" />
                    {g.charAt(0).toUpperCase() + g.slice(1)}
                  </label>
                ))}
              </div>
            </div>

            <h2 className="font-bold text-gray-900 text-lg mt-6 mb-1">Residential Address</h2>
            <p className="text-gray-400 text-xs mb-4">Your legal residential address.</p>
            <div className="space-y-3">
              <div>
                <input className={inputCls(fieldErrors.street)} placeholder="Street Address *" value={form.street} onChange={e => set("street", e.target.value)} />
                <FieldError msg={fieldErrors.street} />
              </div>
              <div>
                <input className={inputCls(false)} placeholder="Apt / Suite / Unit (optional)" value={form.apt} onChange={e => set("apt", e.target.value)} />
              </div>
              <div>
                <input className={inputCls(fieldErrors.city)} placeholder="City *" value={form.city} onChange={e => set("city", e.target.value)} />
                <FieldError msg={fieldErrors.city} />
              </div>
              <div>
                <input className={inputCls(fieldErrors.state)} placeholder="State *" value={form.state} onChange={e => set("state", e.target.value)} />
                <FieldError msg={fieldErrors.state} />
              </div>
              <div>
                <input className={inputCls(fieldErrors.zip)} placeholder="Zip Code *" value={form.zip} onChange={e => set("zip", e.target.value)} />
                <FieldError msg={fieldErrors.zip} />
              </div>
            </div>

            <div className="mt-6 flex justify-end pb-4">
              <button
                onClick={() => goNext(validateStep1, 2)}
                className="px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700 transition-colors"
              >
                Next Step →
              </button>
            </div>
            <p className="text-center text-sm text-gray-500 pb-6">
              Already have an account? <Link to="/signin" className="text-blue-600 underline">Sign In</Link>
            </p>
          </div>
        )}

        {/* STEP 2 — Login Info */}
        {step === 2 && (
          <div>
            <h2 className="font-bold text-gray-900 text-lg mb-1">Account & Login Details</h2>
            <p className="text-gray-400 text-xs mb-4">Set up your credentials for online banking access.</p>

            <ValidationBanner errors={fieldErrors} />

            <div className="space-y-3">
              <div>
                <input className={inputCls(fieldErrors.email)} placeholder="Email Address *" type="email" value={form.email} onChange={e => set("email", e.target.value)} />
                <FieldError msg={fieldErrors.email} />
              </div>
              <div>
                <div className="relative">
                  <select className={selectCls(fieldErrors.accountType)} value={form.accountType} onChange={e => set("accountType", e.target.value)}>
                    <option value="">Select Account Type *</option>
                    {ACCOUNT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                  <span className="absolute right-3 top-3.5 text-gray-400 pointer-events-none">▾</span>
                </div>
                <FieldError msg={fieldErrors.accountType} />
              </div>
              <div>
                <div className="relative">
                  <input className={inputCls(fieldErrors.password)} placeholder="Password * (min. 6 characters)" type={showPass ? "text" : "password"} value={form.password} onChange={e => set("password", e.target.value)} />
                  <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-3 text-gray-400">
                    {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                <FieldError msg={fieldErrors.password} />
              </div>
              <div>
                <div className="relative">
                  <input className={inputCls(fieldErrors.confirmPassword)} placeholder="Confirm Password *" type={showConfirm ? "text" : "password"} value={form.confirmPassword} onChange={e => set("confirmPassword", e.target.value)} />
                  <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="absolute right-3 top-3 text-gray-400">
                    {showConfirm ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                <FieldError msg={fieldErrors.confirmPassword} />
              </div>
              <div>
                <input className={inputCls(fieldErrors.pin)} placeholder="Transaction PIN * (4–6 digits)" type="password" maxLength={6} value={form.pin} onChange={e => set("pin", e.target.value.replace(/\D/g, ""))} />
                <FieldError msg={fieldErrors.pin} />
              </div>
              <div>
                <input className={inputCls(fieldErrors.phone)} placeholder="Phone Number *" type="tel" value={form.phone} onChange={e => set("phone", e.target.value)} />
                <FieldError msg={fieldErrors.phone} />
              </div>
            </div>

            <div className="mt-6 flex justify-between pb-4">
              <button onClick={() => { setStep(1); setFieldErrors({}); }} className="px-6 py-3 bg-gray-200 text-gray-700 font-semibold rounded text-sm hover:bg-gray-300 transition-colors">← Previous</button>
              <button onClick={() => goNext(validateStep2, 3)} className="px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700 transition-colors">Next Step →</button>
            </div>
            <p className="text-center text-sm text-gray-500 pb-6">
              Already have an account? <Link to="/signin" className="text-blue-600 underline">Sign In</Link>
            </p>
          </div>
        )}

        {/* STEP 3 — Date of Birth */}
        {step === 3 && (
          <div>
            <h2 className="font-bold text-gray-900 text-lg mb-1">Date of Birth</h2>
            <p className="text-gray-500 text-sm mb-5">We're required by law to verify your age. You must be 18 or older to open an account.</p>

            <ValidationBanner errors={fieldErrors} />

            <div>
              <input className={inputCls(fieldErrors.dob)} placeholder="Date of Birth *" type="date" value={form.dob} onChange={e => set("dob", e.target.value)} />
              <FieldError msg={fieldErrors.dob} />
            </div>

            <div className="mt-6 flex justify-between pb-4">
              <button onClick={() => { setStep(2); setFieldErrors({}); }} className="px-6 py-3 bg-gray-200 text-gray-700 font-semibold rounded text-sm hover:bg-gray-300 transition-colors">← Previous</button>
              <button onClick={() => goNext(validateStep3, 4)} className="px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700 transition-colors">Next Step →</button>
            </div>
            <p className="text-center text-sm text-gray-500 pb-6">
              Already have an account? <Link to="/signin" className="text-blue-600 underline">Sign In</Link>
            </p>
          </div>
        )}

        {/* STEP 4 — Documents */}
        {step === 4 && (
          <div>
            <h2 className="font-bold text-gray-900 text-lg mb-1">Upload Documents</h2>
            <p className="text-gray-400 text-xs mb-4">Upload clear images of your identification documents.</p>

            <ValidationBanner errors={fieldErrors} />

            <div className="space-y-4">
              {[
                { label: "Profile Photo *", key: "profileImage" },
                { label: "ID Card — Front *", key: "idFront" },
                { label: "ID Card — Back *", key: "idBack" },
              ].map(({ label, key }) => (
                <div key={key}>
                  <label className="text-sm font-medium text-gray-700 block mb-1">{label}</label>
                  <div className={`rounded-lg px-3 py-2 flex items-center gap-2 border ${fieldErrors[key] ? "bg-red-50 border-red-400" : "bg-gray-100 border-transparent"}`}>
                    <label className="px-3 py-1.5 bg-white border border-gray-300 rounded text-xs cursor-pointer font-medium hover:bg-gray-50">
                      Choose File
                      <input type="file" className="hidden" accept="image/*" onChange={e => set(key, e.target.files[0])} />
                    </label>
                    <span className={`text-xs truncate ${form[key] ? "text-green-600 font-medium" : "text-gray-400"}`}>
                      {form[key] ? `✓ ${form[key].name}` : "No file chosen"}
                    </span>
                  </div>
                  <FieldError msg={fieldErrors[key]} />
                </div>
              ))}

              {/* Captcha */}
              <div>
                <label className="text-sm font-medium text-gray-700 block mb-1">Security Verification *</label>
                <div className="flex items-center gap-3">
                  <div className="bg-gray-900 px-4 py-2.5 rounded-lg font-mono font-bold text-white text-lg tracking-widest select-none flex-shrink-0 border-2 border-dashed border-gray-500">
                    {captchaCode}
                  </div>
                  <div className="flex-1">
                    <input
                      className={inputCls(fieldErrors.captcha)}
                      placeholder="Enter the code above"
                      value={captchaInput}
                      onChange={e => { setCaptchaInput(e.target.value); setFieldErrors(fe => ({ ...fe, captcha: "" })); }}
                    />
                  </div>
                </div>
                <FieldError msg={fieldErrors.captcha} />
              </div>

              {submitError && (
                <div className="bg-red-50 border border-red-300 text-red-600 text-sm rounded-lg px-4 py-3 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  {submitError}
                </div>
              )}
            </div>

            <div className="mt-6 flex justify-between pb-4">
              <button onClick={() => { setStep(3); setFieldErrors({}); }} className="px-6 py-3 bg-gray-200 text-gray-700 font-semibold rounded text-sm hover:bg-gray-300 transition-colors">← Previous</button>
              <button onClick={handleSubmit} disabled={loading} className="px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700 transition-colors flex items-center gap-2 disabled:opacity-70">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                {loading ? "Processing..." : "Submit Application"}
              </button>
            </div>
            <p className="text-center text-sm text-gray-500 pb-6">
              Already have an account? <Link to="/signin" className="text-blue-600 underline">Sign In</Link>
            </p>
          </div>
        )}
      </div>

      {/* Success Modal */}
      {showSuccess && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4">
          <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
            <div className="bg-cyan-500 px-6 py-4 text-center">
              <div className="text-white font-extrabold text-lg tracking-widest">⊙ CINNIONCPF</div>
              <div className="text-cyan-100 text-xs tracking-wider">FINANCE BANK</div>
            </div>
            <div className="bg-gray-900 py-5 text-center">
              <h2 className="text-white text-3xl font-extrabold tracking-widest">WELCOME</h2>
            </div>
            <div className="px-6 py-5">
              <p className="text-gray-700 text-sm mb-3">Hello, <strong>{form.firstName} {form.lastName}</strong></p>
              <p className="text-gray-600 text-xs mb-4">Your account has been created successfully. A confirmation email has been sent to <strong>{form.email}</strong>. Please use your Account Number to log in.</p>

              <table className="w-full text-xs border-collapse mb-4">
                <tbody>
                  {[
                    ["Full name", `${form.firstName} ${form.lastName}`],
                    ["Account No", generatedAccountNumber],
                    ["Account Type", form.accountType],
                    ["Account Password", "****"],
                    ["Account Pin", "****"],
                  ].map(([label, value]) => (
                    <tr key={label}>
                      <td className="border border-gray-200 px-3 py-2 bg-gray-50 text-gray-500">{label}</td>
                      <td className="border border-gray-200 px-3 py-2 font-semibold text-gray-800">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 flex items-center justify-between gap-2">
                <div>
                  <div className="text-xs text-blue-600 font-semibold mb-0.5">Your Account ID (use to Sign In)</div>
                  <div className="font-mono font-bold text-blue-800 text-base">{generatedAccountNumber}</div>
                </div>
                <button onClick={copyAccountNumber} className="flex items-center gap-1 bg-blue-600 text-white text-xs px-3 py-2 rounded hover:bg-blue-700 flex-shrink-0">
                  <Copy className="w-3 h-3" /> {copied ? "Copied!" : "Copy"}
                </button>
              </div>

              <p className="text-xs text-gray-500 text-center mb-4">Your account is being processed and we will get back to you once verified.</p>

              <button onClick={() => navigate("/signin")} className="w-full py-2.5 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700">
                Go to Sign In
              </button>
            </div>
            <div className="bg-cyan-500 py-3 text-center">
              <p className="text-white text-sm font-bold">Need more help?</p>
              <p className="text-cyan-100 text-xs">We're here to help you out</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}