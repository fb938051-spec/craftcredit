import React, { useState } from "react";
import DashboardLayout from "../components/dashboard/DashboardLayout";
import { DollarSign, ArrowRight } from "lucide-react";

const COUNTRIES = ["Afghanistan","Albania","Algeria","Argentina","Australia","Austria","Bahamas","Bangladesh","Belgium","Brazil","Canada","China","Colombia","Denmark","Egypt","Ethiopia","Finland","France","Germany","Ghana","Greece","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan","Jordan","Kenya","Malaysia","Mexico","Morocco","Netherlands","New Zealand","Nigeria","Norway","Pakistan","Philippines","Poland","Portugal","Qatar","Romania","Russia","Saudi Arabia","South Africa","South Korea","Spain","Sri Lanka","Sweden","Switzerland","Tanzania","Thailand","Turkey","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Vietnam","Zimbabwe"];
const ACCOUNT_TYPES = ["Savings Account","Current Account","Checking Account","Fixed Deposit","Non Resident Account","Online Banking","Domiciliary Account","Joint Account"];

const inputCls = "w-full px-3 py-3 border border-gray-200 rounded text-sm text-gray-700 placeholder-gray-300 outline-none focus:border-blue-400";

export default function WireTransfer() {
  const [form, setForm] = useState({ amount: "", beneficiaryName: "", bankName: "", accountNumber: "", country: "", swiftCode: "", iban: "", accountType: "Savings Account", narration: "" });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <DashboardLayout>
      <div className="p-5 pb-16">
        <h1 className="text-xl font-semibold text-gray-800 text-center mb-6">Wire Transfer</h1>
        <div className="space-y-4">
          <div>
            <label className="text-sm text-gray-500 block mb-1">Amount</label>
            <div className="flex items-center border border-gray-200 rounded overflow-hidden">
              <span className="px-3 py-3 bg-gray-50 border-r border-gray-200"><DollarSign className="w-4 h-4 text-gray-400" /></span>
              <input className="flex-1 px-3 py-3 text-sm outline-none placeholder-gray-300" placeholder="Amount" value={form.amount} onChange={e => set("amount", e.target.value)} type="number" />
            </div>
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">Beneficiary Account Name</label>
            <input className={inputCls} placeholder="Beneficiary Account Name" value={form.beneficiaryName} onChange={e => set("beneficiaryName", e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">Bank Name</label>
            <input className={inputCls} placeholder="Bank Name" value={form.bankName} onChange={e => set("bankName", e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">Beneficiary Account Number</label>
            <input className={inputCls} placeholder="Beneficiary Account Number" value={form.accountNumber} onChange={e => set("accountNumber", e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">Select Country</label>
            <select className={inputCls} value={form.country} onChange={e => set("country", e.target.value)}>
              <option value="">Select Country</option>
              {COUNTRIES.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">Swift Code</label>
            <input className={inputCls} placeholder="Swift Code" value={form.swiftCode} onChange={e => set("swiftCode", e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">IBAN/Routing Number</label>
            <input className={inputCls} placeholder="IBAN/Routing Number" value={form.iban} onChange={e => set("iban", e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">Select Account Type</label>
            <select className={inputCls} value={form.accountType} onChange={e => set("accountType", e.target.value)}>
              {ACCOUNT_TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm text-gray-500 block mb-1">Naration/Purpose</label>
            <textarea className={inputCls + " h-24 resize-none"} placeholder="Fund Description" value={form.narration} onChange={e => set("narration", e.target.value)} />
          </div>
          <div className="flex justify-center pt-2">
            <button className="flex items-center gap-2 px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700">
              <ArrowRight className="w-4 h-4" /> Transfer
            </button>
          </div>
        </div>
        <p className="text-center text-xs text-gray-400 mt-8">Copyright © 2025 Cinnioncpf Finance Bank. All rights reserved.</p>
      </div>
    </DashboardLayout>
  );
}