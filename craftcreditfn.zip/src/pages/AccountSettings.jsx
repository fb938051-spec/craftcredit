import React, { useState } from "react";
import DashboardLayout from "../components/dashboard/DashboardLayout";

const inputCls = "w-full px-3 py-3 bg-gray-100 rounded text-sm text-gray-500 outline-none";

export default function AccountSettings() {
  const [oldPass, setOldPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");

  return (
    <DashboardLayout>
      <div className="p-4 pb-16 space-y-4">
        {/* General Information */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="font-bold text-gray-800 text-sm uppercase tracking-wider mb-4">GENERAL INFORMATION</h2>
          <div className="flex flex-col items-center mb-4">
            <div className="relative mb-2">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
                alt="profile"
                className="w-16 h-16 rounded-full border-4 border-purple-200 object-cover"
              />
            </div>
            <p className="text-xs text-gray-400 mb-1">1776027685...</p>
            <p className="text-xs text-blue-500 mb-1">Upload or Drag...</p>
            <button className="text-xs text-blue-500 underline mb-2">Upload Picture</button>
            <button className="px-4 py-1.5 bg-blue-600 text-white text-xs rounded">Save</button>
          </div>
          <div className="space-y-2">
            {[
              { label: "Account No", value: "4027564935" },
              { label: "Account Type", value: "Current" },
              { label: "Email", value: "45563867" },
              { label: "Gender", value: "Male" },
              { label: "Marital Status", value: "Alone" },
            ].map(f => (
              <div key={f.label}>
                <p className="text-xs text-gray-400 mb-0.5">{f.label}</p>
                <input className={inputCls} value={f.value} readOnly />
              </div>
            ))}
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="font-bold text-gray-800 text-sm uppercase tracking-wider mb-4">CONTACT INFORMATION</h2>
          <div>
            <p className="text-xs text-gray-400 mb-0.5">Current Address</p>
            <input className={inputCls} value="Hbsdb, Midway New Realm Bsbs" readOnly />
          </div>
        </div>

        {/* Change Password */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="font-bold text-gray-800 text-sm uppercase tracking-wider mb-4">CHANGE PASSWORD</h2>
          <div className="space-y-2">
            <div>
              <p className="text-xs text-gray-400 mb-0.5">Old Password</p>
              <input className={inputCls} type="password" placeholder="Old Password" value={oldPass} onChange={e => setOldPass(e.target.value)} />
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-0.5">New Password</p>
              <input className={inputCls} type="password" placeholder="New Password" value={newPass} onChange={e => setNewPass(e.target.value)} />
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-0.5">Confirm Password</p>
              <input className={inputCls} type="password" placeholder="Confirm Password" value={confirmPass} onChange={e => setConfirmPass(e.target.value)} />
            </div>
            <button className="px-6 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded hover:bg-blue-700">Change Password</button>
          </div>
        </div>

        {/* Change PIN */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="font-bold text-gray-800 text-sm uppercase tracking-wider mb-4">CHANGE PIN</h2>
          <div className="space-y-2">
            <div>
              <p className="text-xs text-gray-400 mb-0.5">Current Pin</p>
              <input className={inputCls} type="password" placeholder="Current Pin" value={currentPin} onChange={e => setCurrentPin(e.target.value)} />
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-0.5">New Pin</p>
              <input className={inputCls} type="password" placeholder="New Pin" value={newPin} onChange={e => setNewPin(e.target.value)} />
            </div>
            <div>
              <p className="text-xs text-gray-400 mb-0.5">Confirm Pin</p>
              <input className={inputCls} type="password" placeholder="Confirm Pin" value={confirmPin} onChange={e => setConfirmPin(e.target.value)} />
            </div>
            <button className="px-6 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded hover:bg-blue-700">Change Pin</button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}