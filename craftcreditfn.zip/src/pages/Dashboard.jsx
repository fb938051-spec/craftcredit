import React, { useState } from "react";
import DashboardLayout from "../components/dashboard/DashboardLayout";
import { Plus, Copy } from "lucide-react";

function BankingDetailsModal({ onClose }) {
  const copy = (text) => navigator.clipboard.writeText(text);
  const fields = [
    { label: "Bank Name", value: "Cinnioncpf Finance Bank" },
    { label: "Account Number", value: "••••••••••" },
    { label: "Routine Number", value: "362583736" },
    { label: "Swift Code", value: "RHYU79F" },
  ];
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4">
      <div className="bg-white w-full max-w-sm rounded-xl shadow-xl p-6">
        <div className="flex justify-between items-center mb-5">
          <h2 className="font-bold text-gray-900 text-lg">Banking Details</h2>
          <button onClick={onClose} className="text-gray-400 text-xl font-bold">×</button>
        </div>
        <div className="space-y-4">
          {fields.map(f => (
            <div key={f.label}>
              <label className="text-xs text-gray-500 block mb-1">{f.label}</label>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-gray-100 rounded px-3 py-2.5 text-sm text-gray-400">{f.value}</div>
                <button onClick={() => copy(f.value)} className="flex items-center gap-1 px-3 py-2.5 bg-blue-600 text-white text-xs font-semibold rounded">
                  <Copy className="w-3 h-3" /> Copy
                </button>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-5 flex justify-end">
          <button onClick={onClose} className="px-5 py-2 border border-gray-200 rounded text-sm text-gray-500 hover:bg-gray-50">Discard</button>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [showBanking, setShowBanking] = useState(false);
  const [depositOpen, setDepositOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);

  return (
    <DashboardLayout>
      <div className="pb-8">
        {/* Balance card */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 px-5 pt-5 pb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=60&h=60&fit=crop&crop=face"
                alt="user" className="w-8 h-8 rounded-full border-2 border-white/40 object-cover" />
              <span className="text-white font-semibold text-sm">Thomas James</span>
            </div>
            <button onClick={() => setShowBanking(true)} className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <Plus className="w-5 h-5 text-white" />
            </button>
          </div>
          <p className="text-white/70 text-sm">Balance :</p>
          <p className="text-white text-3xl font-bold mt-1">$0.00</p>
        </div>

        {/* Deposit / Transfer toggles */}
        <div className="bg-white mx-3 -mt-3 rounded-xl shadow-sm p-4">
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div>
              <button
                onClick={() => setDepositOpen(!depositOpen)}
                className="w-full flex items-center justify-between px-3 py-2.5 border border-gray-200 rounded text-sm font-medium text-gray-700"
              >
                Deposit <span>{depositOpen ? "▲" : "▼"}</span>
              </button>
              {depositOpen && (
                <a href="/dashboard/deposit">
                  <button className="w-full mt-2 py-2 bg-green-400 text-white text-sm font-semibold rounded">Deposit</button>
                </a>
              )}
            </div>
            <div>
              <button
                onClick={() => setTransferOpen(!transferOpen)}
                className="w-full flex items-center justify-between px-3 py-2.5 border border-gray-200 rounded text-sm font-medium text-gray-700"
              >
                Transfer <span>{transferOpen ? "▲" : "▼"}</span>
              </button>
              {transferOpen && (
                <a href="/dashboard/wire-transfer">
                  <button className="w-full mt-2 py-2 bg-blue-600 text-white text-sm font-semibold rounded">Transfer</button>
                </a>
              )}
            </div>
          </div>

          <div className="flex justify-center mb-4">
            <span className="px-6 py-1 bg-green-400 text-white text-xs font-bold rounded-full">ACTIVE</span>
          </div>

          <div className="space-y-1.5 text-sm mb-4">
            <div className="flex justify-between"><span className="text-gray-500">Account Limit:</span><span className="font-medium">$0.00</span></div>
            <div className="flex justify-between"><span className="text-gray-500">Transfer Limit Remain:</span><span className="text-red-500 font-medium">$0.00</span></div>
            <div className="flex justify-between"><span className="text-gray-500">Last Login IP:</span><span className="text-red-500 font-medium">102.90.82.80</span></div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <a href="/dashboard/domestic-transfer">
              <button className="w-full py-2.5 bg-purple-100 text-purple-600 text-xs font-semibold rounded-full">Domestic Transfer</button>
            </a>
            <a href="/dashboard/wire-transfer">
              <button className="w-full py-2.5 bg-teal-100 text-teal-600 text-xs font-semibold rounded-full">Wire Transfer</button>
            </a>
            <a href="/dashboard/transactions/domestic">
              <button className="w-full py-2.5 bg-purple-100 text-purple-600 text-xs font-semibold rounded-full">Domestic Transactions</button>
            </a>
            <a href="/dashboard/transactions/wire">
              <button className="w-full py-2.5 bg-teal-100 text-teal-600 text-xs font-semibold rounded-full">Wire Transactions</button>
            </a>
          </div>
        </div>

        {/* Recent Credit/Debit Transactions */}
        <div className="mx-3 mt-4 bg-white rounded-xl shadow-sm p-4">
          <h3 className="font-bold text-gray-900 mb-3">Recent Credit/Debit Transactions</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-teal-50 text-gray-500">
                  <th className="py-2 px-2 text-left">S/N</th>
                  <th className="py-2 px-2 text-left">AMOUNT</th>
                  <th className="py-2 px-2 text-left">TYPE</th>
                  <th className="py-2 px-2 text-left">SENDER / RECEIVER</th>
                  <th className="py-2 px-2 text-left">DESCRIPTION</th>
                  <th className="py-2 px-2 text-left">CREATED AT</th>
                </tr>
              </thead>
              <tbody>
                <tr><td colSpan={6} className="text-center py-4 text-gray-400 text-xs">No data available</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Domestic Transactions */}
        <div className="mx-3 mt-4 bg-white rounded-xl shadow-sm p-4">
          <h3 className="font-bold text-gray-900 mb-3">Recent Domestic Transactions</h3>
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs text-gray-500">Results:</span>
            <select className="border border-gray-200 rounded px-2 py-1 text-xs">
              <option>7</option><option>10</option><option>25</option>
            </select>
          </div>
          <div className="flex items-center border border-gray-200 rounded px-3 py-2 mb-3 gap-2">
            <span className="text-gray-300">🔍</span>
            <input className="flex-1 text-xs outline-none placeholder-gray-300" placeholder="Search..." />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-teal-50 text-gray-500">
                  <th className="py-2 px-2 text-left">S/N</th>
                  <th className="py-2 px-2 text-left">Amount</th>
                  <th className="py-2 px-2 text-left">Transaction ID</th>
                  <th className="py-2 px-2 text-left">Account Name</th>
                  <th className="py-2 px-2 text-left">Transfer Type</th>
                  <th className="py-2 px-2 text-left">Transfer Status</th>
                </tr>
              </thead>
              <tbody>
                <tr><td colSpan={6} className="text-center py-4 text-gray-400">No data available in table</td></tr>
              </tbody>
            </table>
          </div>
          <p className="text-xs text-gray-400 text-center mt-2">Showing 0 to 0 of 0 entries</p>
          <div className="flex gap-2 mt-2">
            <button className="w-7 h-7 border border-gray-200 rounded flex items-center justify-center text-gray-400">←</button>
            <button className="w-7 h-7 border border-gray-200 rounded flex items-center justify-center text-gray-400">→</button>
          </div>
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">Copyright © 2025 Cinnioncpf Finance Bank. All rights reserved.</p>
      </div>

      {showBanking && <BankingDetailsModal onClose={() => setShowBanking(false)} />}
    </DashboardLayout>
  );
}