import React, { useState } from "react";
import DashboardLayout from "../components/dashboard/DashboardLayout";
import { DollarSign, ArrowRight, Copy } from "lucide-react";

const inputCls = "w-full px-3 py-3 border border-gray-200 rounded text-sm text-gray-700 placeholder-gray-300 outline-none focus:border-blue-400";

export default function OnlineDeposit() {
  const [amount, setAmount] = useState("");
  const [cryptoType, setCryptoType] = useState("");
  const [walletAddress] = useState("bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh");
  const [file, setFile] = useState(null);

  return (
    <DashboardLayout>
      <div className="p-5 pb-16">
        <div className="space-y-5">
          <div>
            <label className="text-sm text-gray-500 block mb-1">Amount</label>
            <div className="flex items-center border border-gray-200 rounded overflow-hidden">
              <span className="px-3 py-3 bg-gray-50 border-r border-gray-200"><DollarSign className="w-4 h-4 text-blue-400" /></span>
              <input className="flex-1 px-3 py-3 text-sm outline-none placeholder-gray-300" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} type="number" />
            </div>
          </div>

          <div>
            <label className="text-sm text-gray-500 block mb-1">Crypto Type</label>
            <select className={inputCls} value={cryptoType} onChange={e => setCryptoType(e.target.value)}>
              <option value="">Select</option>
              <option>Bitcoin (BTC)</option>
              <option>Ethereum (ETH)</option>
              <option>USDT (TRC20)</option>
              <option>USDT (ERC20)</option>
            </select>
          </div>

          <div>
            <label className="text-sm text-gray-500 block mb-1">Wallet Address</label>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-gray-100 rounded px-3 py-3 text-sm text-gray-400 truncate">{walletAddress}</div>
              <button onClick={() => navigator.clipboard.writeText(walletAddress)} className="flex items-center gap-1 px-3 py-3 bg-blue-600 text-white text-xs font-semibold rounded">
                <Copy className="w-3 h-3" /> Copy
              </button>
            </div>
          </div>

          <div>
            <label className="text-sm text-blue-500 font-medium block mb-2">Upload (Single File) ×</label>
            <div className="flex items-center border border-gray-200 rounded overflow-hidden">
              <span className="px-4 py-3 text-sm text-gray-500 bg-gray-50 border-r border-gray-200">Choose file...</span>
              <label className="px-4 py-3 bg-gray-100 text-sm font-medium text-gray-600 cursor-pointer hover:bg-gray-200">
                Browse
                <input type="file" className="hidden" onChange={e => setFile(e.target.files[0])} />
              </label>
            </div>
          </div>

          {/* Image placeholder */}
          <div className="flex justify-center py-4">
            <div className="relative w-36 h-32">
              <div className="absolute inset-0 bg-white border border-gray-200 rounded shadow-sm flex items-center justify-center translate-x-4 translate-y-4">
                <div className="w-16 h-12 flex flex-col items-center justify-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 self-start ml-1 mb-1" />
                  <div className="text-blue-500 text-2xl">🏔</div>
                </div>
              </div>
              <div className="absolute inset-0 bg-white border border-gray-200 rounded shadow-sm flex items-center justify-center translate-x-2 translate-y-2">
                <div className="text-blue-500 text-2xl">🏔</div>
              </div>
              <div className="absolute inset-0 bg-white border border-gray-200 rounded shadow flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-red-500 self-start absolute top-2 left-2" />
                <div className="text-blue-500 text-3xl">🏔</div>
              </div>
            </div>
          </div>

          <div className="flex justify-center pt-2">
            <button className="flex items-center gap-2 px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700">
              <ArrowRight className="w-4 h-4" /> Deposit
            </button>
          </div>
        </div>
        <p className="text-center text-xs text-gray-400 mt-8">Copyright © 2025 Cinnioncpf Finance Bank. All rights reserved.</p>
      </div>
    </DashboardLayout>
  );
}