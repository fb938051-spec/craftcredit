import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Search, Mail, AlertTriangle, Lock, Unlock, RefreshCw,
  ShieldX, ShieldCheck, Loader2, CheckCircle, AlertCircle,
  Send, Ban, Snowflake, ChevronDown
} from "lucide-react";

const STATUS_STYLES = {
  active:      "bg-emerald-500/10 text-emerald-400",
  frozen:      "bg-blue-500/10 text-blue-400",
  restricted:  "bg-amber-500/10 text-amber-400",
  suspended:   "bg-red-500/10 text-red-400",
  closed:      "bg-gray-500/10 text-gray-400",
};

function Badge({ status }) {
  return (
    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${STATUS_STYLES[status] || STATUS_STYLES.active}`}>
      {status}
    </span>
  );
}

function Section({ title, icon: Icon, color, children }) {
  return (
    <div className={`bg-gray-900 border rounded-xl p-5 space-y-4 ${color || "border-gray-800"}`}>
      <div className="flex items-center gap-2">
        <Icon className="w-4 h-4 text-gray-400" />
        <h3 className="text-white font-semibold text-sm">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function Toast({ msg, type }) {
  if (!msg) return null;
  return (
    <div className={`flex items-center gap-2 rounded-lg px-4 py-3 text-sm ${
      type === "success" ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-400"
                        : "bg-red-500/10 border border-red-500/30 text-red-400"
    }`}>
      {type === "success" ? <CheckCircle className="w-4 h-4 flex-shrink-0" /> : <AlertCircle className="w-4 h-4 flex-shrink-0" />}
      {msg}
    </div>
  );
}

export default function AdminClients() {
  const [accounts, setAccounts] = useState([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState({ msg: "", type: "" });

  // Email state
  const [emailSubject, setEmailSubject] = useState("");
  const [emailBody, setEmailBody] = useState("");

  // Warning state
  const [warning, setWarning] = useState("");

  // Restriction state
  const [restrictionNote, setRestrictionNote] = useState("");
  const [transferRestricted, setTransferRestricted] = useState(false);
  const [withdrawalRestricted, setWithdrawalRestricted] = useState(false);

  const notify = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast({ msg: "", type: "" }), 4000);
  };

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.BankAccount.list();
    setAccounts(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = accounts.filter(a =>
    (a.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
    (a.accountNumber || "").includes(search) ||
    (a.email || "").toLowerCase().includes(search.toLowerCase())
  );

  const selectAccount = (acc) => {
    setSelected(acc);
    setWarning(acc.warningMessage || "");
    setRestrictionNote(acc.restrictionNote || "");
    setTransferRestricted(acc.transferRestricted || false);
    setWithdrawalRestricted(acc.withdrawalRestricted || false);
    setEmailSubject("");
    setEmailBody("");
    setToast({ msg: "", type: "" });
  };

  const refreshSelected = async () => {
    const data = await base44.entities.BankAccount.list();
    setAccounts(data);
    const updated = data.find(a => a.id === selected?.id);
    if (updated) selectAccount(updated);
  };

  // ── Actions ──────────────────────────────────────────

  const sendEmail = async () => {
    if (!emailSubject.trim() || !emailBody.trim()) return notify("Please fill in subject and message.", "error");
    setBusy(true);
    await base44.integrations.Core.SendEmail({
      to: selected.email,
      subject: emailSubject,
      body: `Dear ${selected.fullName},\n\n${emailBody}\n\nRegards,\nCraftCredit Finance Bank`,
    });
    setEmailSubject("");
    setEmailBody("");
    setBusy(false);
    notify(`Email sent to ${selected.email}`);
  };

  const saveWarning = async () => {
    setBusy(true);
    await base44.entities.BankAccount.update(selected.id, { warningMessage: warning });
    if (warning.trim() && selected.email) {
      base44.integrations.Core.SendEmail({
        to: selected.email,
        subject: "⚠️ Important Notice from CraftCredit Finance Bank",
        body: `Dear ${selected.fullName},\n\n${warning}\n\nIf you have questions, please contact customer support.\n\nRegards,\nCraftCredit Finance Bank`,
      });
    }
    await refreshSelected();
    setBusy(false);
    notify("Warning message saved and emailed to client.");
  };

  const clearWarning = async () => {
    setBusy(true);
    await base44.entities.BankAccount.update(selected.id, { warningMessage: "" });
    setWarning("");
    await refreshSelected();
    setBusy(false);
    notify("Warning cleared.");
  };

  const saveRestrictions = async () => {
    setBusy(true);
    await base44.entities.BankAccount.update(selected.id, {
      transferRestricted,
      withdrawalRestricted,
      restrictionNote,
      status: (transferRestricted || withdrawalRestricted) ? "restricted" : selected.status === "restricted" ? "active" : selected.status,
    });
    if (selected.email && (transferRestricted || withdrawalRestricted)) {
      base44.integrations.Core.SendEmail({
        to: selected.email,
        subject: "🔒 Account Restrictions Applied",
        body: `Dear ${selected.fullName},\n\nYour account has been subject to the following restrictions:\n${transferRestricted ? "• Outgoing transfers have been blocked.\n" : ""}${withdrawalRestricted ? "• Withdrawals have been blocked.\n" : ""}${restrictionNote ? `\nReason: ${restrictionNote}` : ""}\n\nPlease contact our support team for more information.\n\nRegards,\nCraftCredit Finance Bank`,
      });
    }
    await refreshSelected();
    setBusy(false);
    notify("Restrictions updated.");
  };

  const setAccountStatus = async (newStatus) => {
    setBusy(true);
    await base44.entities.BankAccount.update(selected.id, { status: newStatus });
    if (selected.email) {
      const messages = {
        frozen:     { subject: "❄️ Account Frozen", body: `Your CraftCredit account (${selected.accountNumber}) has been temporarily frozen. No transactions will be processed during this period. Please contact support for assistance.` },
        suspended:  { subject: "🚫 Account Suspended", body: `Your CraftCredit account (${selected.accountNumber}) has been suspended. Please contact our customer support team immediately.` },
        active:     { subject: "✅ Account Reactivated", body: `Good news! Your CraftCredit account (${selected.accountNumber}) has been reactivated. You can now access all banking services.` },
        closed:     { subject: "Account Closed", body: `Your CraftCredit account (${selected.accountNumber}) has been closed. Thank you for banking with us.` },
      };
      const m = messages[newStatus];
      if (m) {
        base44.integrations.Core.SendEmail({
          to: selected.email,
          subject: m.subject,
          body: `Dear ${selected.fullName},\n\n${m.body}\n\nRegards,\nCraftCredit Finance Bank`,
        });
      }
    }
    await refreshSelected();
    setBusy(false);
    notify(`Account status set to "${newStatus}".`);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Client Management</h1>
          <p className="text-gray-400 text-sm mt-1">Email, warn, restrict, freeze or suspend accounts</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm border border-gray-700 rounded-lg px-3 py-2 hover:border-gray-600 transition-colors">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      <div className="grid lg:grid-cols-5 gap-5">
        {/* Account List */}
        <div className="lg:col-span-2 bg-gray-900 border border-gray-800 rounded-xl overflow-hidden flex flex-col">
          <div className="p-4 border-b border-gray-800">
            <div className="flex items-center gap-2 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2.5">
              <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search name, account, email..."
                className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600"
              />
            </div>
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <div className="w-7 h-7 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="overflow-y-auto max-h-[600px] divide-y divide-gray-800">
              {filtered.length === 0 ? (
                <div className="text-center py-12 text-gray-600 text-sm">No accounts found</div>
              ) : filtered.map(acc => (
                <button
                  key={acc.id}
                  onClick={() => selectAccount(acc)}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 hover:bg-gray-800 transition-colors text-left ${selected?.id === acc.id ? "bg-blue-600/10 border-l-2 border-l-blue-500" : ""}`}
                >
                  <div className="w-9 h-9 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-sm flex-shrink-0">
                    {(acc.fullName || "?")[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white text-sm font-medium truncate">{acc.fullName}</div>
                    <div className="text-gray-500 text-xs font-mono">{acc.accountNumber}</div>
                  </div>
                  <Badge status={acc.status || "active"} />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Panel */}
        <div className="lg:col-span-3 space-y-4">
          {!selected ? (
            <div className="bg-gray-900 border border-gray-800 rounded-xl py-24 text-center">
              <Search className="w-10 h-10 text-gray-700 mx-auto mb-3" />
              <p className="text-gray-500">Select a client to manage</p>
            </div>
          ) : (
            <>
              {/* Client Header */}
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-2xl flex-shrink-0">
                    {(selected.fullName || "?")[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-bold text-lg">{selected.fullName}</div>
                    <div className="text-gray-400 text-sm">{selected.email}</div>
                    <div className="text-gray-500 text-xs font-mono mt-0.5">{selected.accountNumber} · {selected.accountType}</div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <Badge status={selected.status || "active"} />
                    <div className="text-emerald-400 font-bold text-base mt-1">
                      ${(selected.balance || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                </div>

                {/* Quick Flags */}
                {(selected.transferRestricted || selected.withdrawalRestricted || selected.warningMessage) && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {selected.warningMessage && <span className="text-xs bg-amber-500/10 text-amber-400 px-2 py-1 rounded-full">⚠️ Has Warning</span>}
                    {selected.transferRestricted && <span className="text-xs bg-red-500/10 text-red-400 px-2 py-1 rounded-full">🚫 Transfer Blocked</span>}
                    {selected.withdrawalRestricted && <span className="text-xs bg-red-500/10 text-red-400 px-2 py-1 rounded-full">🚫 Withdrawal Blocked</span>}
                  </div>
                )}
              </div>

              <Toast msg={toast.msg} type={toast.type} />

              {/* Account Status Control */}
              <Section title="Account Status Control" icon={ShieldCheck} color="border-gray-800">
                <p className="text-gray-500 text-xs">Change the account status. The client will be notified via email automatically.</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { status: "active", label: "Activate", icon: ShieldCheck, cls: "bg-emerald-600 hover:bg-emerald-500" },
                    { status: "frozen", label: "Freeze", icon: Snowflake, cls: "bg-blue-600 hover:bg-blue-500" },
                    { status: "suspended", label: "Suspend", icon: Ban, cls: "bg-red-600 hover:bg-red-500" },
                    { status: "closed", label: "Close", icon: ShieldX, cls: "bg-gray-600 hover:bg-gray-500" },
                  ].map(({ status, label, icon: Icon, cls }) => (
                    <button
                      key={status}
                      disabled={busy || selected.status === status}
                      onClick={() => setAccountStatus(status)}
                      className={`flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-white text-xs font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed ${cls}`}
                    >
                      {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Icon className="w-3.5 h-3.5" />}
                      {label}
                    </button>
                  ))}
                </div>
              </Section>

              {/* Send Email */}
              <Section title="Send Email to Client" icon={Mail} color="border-gray-800">
                <input
                  value={emailSubject}
                  onChange={e => setEmailSubject(e.target.value)}
                  placeholder="Email subject..."
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
                />
                <textarea
                  value={emailBody}
                  onChange={e => setEmailBody(e.target.value)}
                  placeholder="Write your message here..."
                  rows={4}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-blue-500 transition-colors placeholder-gray-600"
                />
                <button
                  onClick={sendEmail}
                  disabled={busy}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-all disabled:opacity-50"
                >
                  {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  Send Email
                </button>
              </Section>

              {/* Warning Message */}
              <Section title="Warning Message" icon={AlertTriangle} color="border-amber-900/40">
                <p className="text-gray-500 text-xs">This message will be displayed to the client and sent via email.</p>
                <textarea
                  value={warning}
                  onChange={e => setWarning(e.target.value)}
                  placeholder="e.g. Your account is under review for suspicious activity..."
                  rows={3}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-amber-500 transition-colors placeholder-gray-600"
                />
                <div className="flex gap-2">
                  <button
                    onClick={saveWarning}
                    disabled={busy}
                    className="flex items-center gap-2 bg-amber-600 hover:bg-amber-500 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-all disabled:opacity-50"
                  >
                    {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <AlertTriangle className="w-4 h-4" />}
                    Save & Send Warning
                  </button>
                  {selected.warningMessage && (
                    <button
                      onClick={clearWarning}
                      disabled={busy}
                      className="text-gray-400 hover:text-white text-sm px-4 py-2.5 rounded-lg border border-gray-700 hover:border-gray-500 transition-all"
                    >
                      Clear Warning
                    </button>
                  )}
                </div>
              </Section>

              {/* Restrictions */}
              <Section title="Account Restrictions" icon={Lock} color="border-red-900/40">
                <p className="text-gray-500 text-xs">Block specific actions on this account. Client will be notified via email.</p>
                <div className="space-y-3">
                  {[
                    { label: "Block Outgoing Transfers", key: "transferRestricted", value: transferRestricted, set: setTransferRestricted },
                    { label: "Block Withdrawals", key: "withdrawalRestricted", value: withdrawalRestricted, set: setWithdrawalRestricted },
                  ].map(({ label, key, value, set }) => (
                    <label key={key} className="flex items-center justify-between bg-gray-800 rounded-lg px-4 py-3 cursor-pointer hover:bg-gray-750 transition-colors">
                      <span className="text-white text-sm">{label}</span>
                      <div
                        onClick={() => set(v => !v)}
                        className={`relative w-11 h-6 rounded-full transition-colors cursor-pointer ${value ? "bg-red-600" : "bg-gray-600"}`}
                      >
                        <div className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${value ? "translate-x-5" : "translate-x-0"}`} />
                      </div>
                    </label>
                  ))}
                  <textarea
                    value={restrictionNote}
                    onChange={e => setRestrictionNote(e.target.value)}
                    placeholder="Internal note / reason for restriction (optional)..."
                    rows={2}
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-red-500 transition-colors placeholder-gray-600"
                  />
                  <button
                    onClick={saveRestrictions}
                    disabled={busy}
                    className="flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-all disabled:opacity-50"
                  >
                    {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                    Apply Restrictions
                  </button>
                </div>
              </Section>
            </>
          )}
        </div>
      </div>
    </div>
  );
}