import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Search, User, DollarSign, RefreshCw, Loader2, CheckSquare, Square, Snowflake, Mail, X, Send } from "lucide-react";

const STATUSES = ["active", "restricted", "frozen"];

const STATUS_STYLE = {
  active:     "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  restricted: "bg-amber-500/10  text-amber-400  border-amber-500/20",
  frozen:     "bg-blue-500/10   text-blue-400   border-blue-500/20",
  suspended:  "bg-red-500/10    text-red-400    border-red-500/20",
  closed:     "bg-gray-500/10   text-gray-400   border-gray-500/20",
};

export default function AdminAccounts() {
  const [accounts, setAccounts] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [toggling, setToggling] = useState({});
  const [selected, setSelected] = useState(new Set());
  const [bulkLoading, setBulkLoading] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailSubject, setEmailSubject] = useState("");
  const [emailBody, setEmailBody] = useState("");
  const [toast, setToast] = useState("");

  const load = () => {
    setLoading(true);
    base44.entities.BankAccount.list().then(data => {
      setAccounts(data);
      setLoading(false);
    });
  };

  useEffect(load, []);

  const notify = (msg) => { setToast(msg); setTimeout(() => setToast(""), 3500); };

  const filtered = accounts.filter(a =>
    (a.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
    (a.accountNumber || "").includes(search) ||
    (a.email || "").toLowerCase().includes(search.toLowerCase())
  );

  const allSelected = filtered.length > 0 && filtered.every(a => selected.has(a.id));
  const toggleAll = () => {
    if (allSelected) {
      setSelected(s => { const n = new Set(s); filtered.forEach(a => n.delete(a.id)); return n; });
    } else {
      setSelected(s => { const n = new Set(s); filtered.forEach(a => n.add(a.id)); return n; });
    }
  };
  const toggleOne = (id) => setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const cycleStatus = async (acc) => {
    const current = acc.status || "active";
    if (!STATUSES.includes(current)) return;
    const next = STATUSES[(STATUSES.indexOf(current) + 1) % STATUSES.length];
    setToggling(t => ({ ...t, [acc.id]: true }));
    await base44.entities.BankAccount.update(acc.id, { status: next });
    // Log activity
    await base44.entities.Transaction.create({
      accountNumber: acc.accountNumber,
      fullName: acc.fullName,
      type: "credit",
      amount: 0,
      description: `Account status changed: ${current} → ${next}`,
      reference: `STATUS-${Date.now()}`,
      performedBy: "Administrator",
    });
    setAccounts(prev => prev.map(a => a.id === acc.id ? { ...a, status: next } : a));
    setToggling(t => ({ ...t, [acc.id]: false }));
  };

  const bulkFreeze = async () => {
    if (selected.size === 0) return;
    setBulkLoading(true);
    const toFreeze = accounts.filter(a => selected.has(a.id));
    await Promise.all(toFreeze.map(acc =>
      base44.entities.BankAccount.update(acc.id, { status: "frozen" }).then(() =>
        base44.entities.Transaction.create({
          accountNumber: acc.accountNumber,
          fullName: acc.fullName,
          type: "credit",
          amount: 0,
          description: "Account frozen via bulk action by Administrator",
          reference: `BULK-FREEZE-${Date.now()}`,
          performedBy: "Administrator",
        })
      )
    ));
    setAccounts(prev => prev.map(a => selected.has(a.id) ? { ...a, status: "frozen" } : a));
    setSelected(new Set());
    setBulkLoading(false);
    notify(`${toFreeze.length} account(s) frozen.`);
  };

  const bulkSendEmail = async () => {
    if (!emailSubject.trim() || !emailBody.trim()) return;
    setBulkLoading(true);
    const targets = accounts.filter(a => selected.has(a.id) && a.email);
    await Promise.all(targets.map(acc =>
      base44.integrations.Core.SendEmail({
        to: acc.email,
        subject: emailSubject,
        body: `Dear ${acc.fullName},\n\n${emailBody}\n\nRegards,\nCraftCredit Finance Bank`,
      })
    ));
    setBulkLoading(false);
    setShowEmailModal(false);
    setEmailSubject("");
    setEmailBody("");
    setSelected(new Set());
    notify(`Email sent to ${targets.length} recipient(s).`);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Manage Accounts</h1>
          <p className="text-gray-400 text-sm mt-1">{accounts.length} registered accounts</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm border border-gray-700 rounded-lg px-3 py-2 hover:border-gray-600 transition-colors">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {toast && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-sm px-4 py-3 rounded-lg">{toast}</div>
      )}

      {/* Search */}
      <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-xl px-4 py-3">
        <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search by name, account number or email..."
          className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600"
        />
      </div>

      {/* Bulk Action Bar */}
      {selected.size > 0 && (
        <div className="flex items-center gap-3 bg-blue-600/10 border border-blue-600/30 rounded-xl px-4 py-3">
          <span className="text-blue-400 text-sm font-semibold">{selected.size} selected</span>
          <div className="flex gap-2 ml-auto">
            <button
              onClick={bulkFreeze}
              disabled={bulkLoading}
              className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-3 py-2 rounded-lg transition-all disabled:opacity-50"
            >
              {bulkLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Snowflake className="w-3.5 h-3.5" />}
              Freeze All
            </button>
            <button
              onClick={() => setShowEmailModal(true)}
              className="flex items-center gap-1.5 bg-gray-700 hover:bg-gray-600 text-white text-xs font-semibold px-3 py-2 rounded-lg transition-all"
            >
              <Mail className="w-3.5 h-3.5" /> Email Selected
            </button>
            <button onClick={() => setSelected(new Set())} className="text-gray-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-gray-900 border border-gray-800 rounded-xl py-16 text-center">
          <User className="w-10 h-10 text-gray-700 mx-auto mb-3" />
          <p className="text-gray-500">No accounts found</p>
        </div>
      ) : (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="px-4 py-3.5">
                    <button onClick={toggleAll} className="text-gray-500 hover:text-white">
                      {allSelected ? <CheckSquare className="w-4 h-4 text-blue-400" /> : <Square className="w-4 h-4" />}
                    </button>
                  </th>
                  <th className="text-left px-4 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Account Holder</th>
                  <th className="text-left px-4 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Account No.</th>
                  <th className="text-left px-4 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Type</th>
                  <th className="text-left px-4 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Balance</th>
                  <th className="text-left px-4 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {filtered.map(acc => {
                  const status = acc.status || "active";
                  const canToggle = STATUSES.includes(status);
                  const isSelected = selected.has(acc.id);
                  return (
                    <tr key={acc.id} className={`hover:bg-gray-800/40 transition-colors ${isSelected ? "bg-blue-600/5" : ""}`}>
                      <td className="px-4 py-4 text-center">
                        <button onClick={() => toggleOne(acc.id)} className="text-gray-500 hover:text-white">
                          {isSelected ? <CheckSquare className="w-4 h-4 text-blue-400" /> : <Square className="w-4 h-4" />}
                        </button>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-600/20 border border-blue-600/30 flex items-center justify-center text-blue-400 text-xs font-bold flex-shrink-0">
                            {(acc.fullName || "?")[0].toUpperCase()}
                          </div>
                          <div>
                            <div className="text-white font-medium">{acc.fullName}</div>
                            <div className="text-gray-500 text-xs">{acc.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 font-mono text-gray-300 text-xs">{acc.accountNumber}</td>
                      <td className="px-4 py-4 text-gray-400 text-xs">{acc.accountType || "—"}</td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-1 text-emerald-400 font-semibold">
                          <DollarSign className="w-3.5 h-3.5" />
                          {(acc.balance || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <button
                          onClick={() => canToggle && cycleStatus(acc)}
                          disabled={toggling[acc.id] || !canToggle}
                          title={canToggle ? "Click to cycle: active → restricted → frozen" : `Status: ${status}`}
                          className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border transition-all
                            ${STATUS_STYLE[status] || STATUS_STYLE.active}
                            ${canToggle ? "cursor-pointer hover:opacity-80 active:scale-95" : "cursor-default opacity-70"}`}
                        >
                          {toggling[acc.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
                          {status}
                          {canToggle && !toggling[acc.id] && <span className="opacity-50 text-[10px]">⟳</span>}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Bulk Email Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4">
          <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold text-lg">Email {selected.size} Selected Accounts</h3>
              <button onClick={() => setShowEmailModal(false)} className="text-gray-500 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <input
              value={emailSubject}
              onChange={e => setEmailSubject(e.target.value)}
              placeholder="Email subject..."
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2.5 text-white text-sm outline-none focus:border-blue-500 placeholder-gray-600"
            />
            <textarea
              value={emailBody}
              onChange={e => setEmailBody(e.target.value)}
              placeholder="Write your message..."
              rows={5}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-blue-500 placeholder-gray-600"
            />
            <div className="flex gap-3">
              <button
                onClick={bulkSendEmail}
                disabled={bulkLoading}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold px-5 py-2.5 rounded-lg disabled:opacity-50"
              >
                {bulkLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                Send Email
              </button>
              <button onClick={() => setShowEmailModal(false)} className="text-gray-400 hover:text-white text-sm px-4 py-2.5 border border-gray-700 rounded-lg">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}