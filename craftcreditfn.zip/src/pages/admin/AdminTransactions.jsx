import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Search, RefreshCw, ArrowUpCircle, ArrowDownCircle, DollarSign, X, Receipt } from "lucide-react";
import moment from "moment";

const TYPE_CONFIG = {
  credit:           { label: "Credit",   color: "text-emerald-400", bg: "bg-emerald-500/10", sign: "+" },
  debit:            { label: "Debit",    color: "text-red-400",     bg: "bg-red-500/10",     sign: "−" },
  loan_disbursement:{ label: "Loan",     color: "text-blue-400",    bg: "bg-blue-500/10",    sign: "+" },
  deposit:          { label: "Deposit",  color: "text-purple-400",  bg: "bg-purple-500/10",  sign: "+" },
};

const STATUS_STYLE = {
  active:     "bg-emerald-500/10 text-emerald-400",
  frozen:     "bg-blue-500/10 text-blue-400",
  restricted: "bg-amber-500/10 text-amber-400",
  suspended:  "bg-red-500/10 text-red-400",
  closed:     "bg-gray-500/10 text-gray-400",
};

export default function AdminTransactions() {
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [search, setSearch] = useState("");
  const [txSearch, setTxSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const load = async () => {
    setLoading(true);
    const [accs, txs] = await Promise.all([
      base44.entities.BankAccount.list(),
      base44.entities.Transaction.list("-created_date", 500),
    ]);
    setAccounts(accs);
    setTransactions(txs.filter(t => t.amount > 0)); // exclude status-change logs
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filteredAccounts = accounts.filter(a =>
    (a.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
    (a.accountNumber || "").includes(search) ||
    (a.email || "").toLowerCase().includes(search.toLowerCase())
  );

  const accountTxs = selectedAccount
    ? transactions.filter(t => t.accountNumber === selectedAccount.accountNumber)
    : [];

  const filteredTxs = accountTxs.filter(t => {
    const matchSearch = (t.description || "").toLowerCase().includes(txSearch.toLowerCase()) || (t.reference || "").includes(txSearch);
    const matchType = typeFilter === "all" || t.type === typeFilter;
    return matchSearch && matchType;
  });

  const totalCredit = accountTxs.filter(t => t.type !== "debit").reduce((s, t) => s + (t.amount || 0), 0);
  const totalDebit  = accountTxs.filter(t => t.type === "debit").reduce((s, t) => s + (t.amount || 0), 0);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Transaction History</h1>
          <p className="text-gray-400 text-sm mt-1">View detailed transactions per account</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm border border-gray-700 rounded-lg px-3 py-2 hover:border-gray-600 transition-colors">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      <div className="grid lg:grid-cols-5 gap-5">
        {/* Account Selector */}
        <div className="lg:col-span-2 bg-gray-900 border border-gray-800 rounded-xl overflow-hidden flex flex-col">
          <div className="p-4 border-b border-gray-800">
            <div className="flex items-center gap-2 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2.5">
              <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search accounts..."
                className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600"
              />
            </div>
          </div>
          {loading ? (
            <div className="flex justify-center py-12"><div className="w-7 h-7 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
          ) : (
            <div className="overflow-y-auto max-h-[560px] divide-y divide-gray-800">
              {filteredAccounts.map(acc => (
                <button
                  key={acc.id}
                  onClick={() => { setSelectedAccount(acc); setTxSearch(""); setTypeFilter("all"); }}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 hover:bg-gray-800 transition-colors text-left ${selectedAccount?.id === acc.id ? "bg-blue-600/10 border-l-2 border-l-blue-500" : ""}`}
                >
                  <div className="w-9 h-9 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-sm flex-shrink-0">
                    {(acc.fullName || "?")[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white text-sm font-medium truncate">{acc.fullName}</div>
                    <div className="text-gray-500 text-xs font-mono">{acc.accountNumber}</div>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full capitalize ${STATUS_STYLE[acc.status || "active"]}`}>
                      {acc.status || "active"}
                    </span>
                    <div className="text-emerald-400 text-xs font-semibold mt-1">
                      ${(acc.balance || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Transaction Panel */}
        <div className="lg:col-span-3 space-y-4">
          {!selectedAccount ? (
            <div className="bg-gray-900 border border-gray-800 rounded-xl py-24 text-center">
              <Receipt className="w-10 h-10 text-gray-700 mx-auto mb-3" />
              <p className="text-gray-500">Select an account to view transactions</p>
            </div>
          ) : (
            <>
              {/* Account Summary */}
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-white font-bold text-lg">{selectedAccount.fullName}</div>
                    <div className="text-gray-400 text-xs font-mono">{selectedAccount.accountNumber} · {selectedAccount.accountType}</div>
                  </div>
                  <button onClick={() => setSelectedAccount(null)} className="text-gray-600 hover:text-white"><X className="w-4 h-4" /></button>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-gray-800 rounded-lg p-3">
                    <div className="text-gray-500 text-xs mb-1">Current Balance</div>
                    <div className="text-emerald-400 font-bold">${(selectedAccount.balance || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                  </div>
                  <div className="bg-gray-800 rounded-lg p-3">
                    <div className="text-gray-500 text-xs mb-1">Total Credits</div>
                    <div className="text-emerald-400 font-bold">+${totalCredit.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                  </div>
                  <div className="bg-gray-800 rounded-lg p-3">
                    <div className="text-gray-500 text-xs mb-1">Total Debits</div>
                    <div className="text-red-400 font-bold">−${totalDebit.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                  </div>
                </div>
              </div>

              {/* Filters */}
              <div className="flex gap-2">
                <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 flex-1">
                  <Search className="w-3.5 h-3.5 text-gray-500 flex-shrink-0" />
                  <input
                    value={txSearch}
                    onChange={e => setTxSearch(e.target.value)}
                    placeholder="Search transactions..."
                    className="flex-1 bg-transparent text-white text-xs outline-none placeholder-gray-600"
                  />
                </div>
                <select
                  value={typeFilter}
                  onChange={e => setTypeFilter(e.target.value)}
                  className="bg-gray-900 border border-gray-800 text-gray-300 text-xs rounded-lg px-3 py-2 outline-none"
                >
                  <option value="all">All Types</option>
                  <option value="credit">Credit</option>
                  <option value="debit">Debit</option>
                  <option value="loan_disbursement">Loan</option>
                  <option value="deposit">Deposit</option>
                </select>
              </div>

              {/* Transaction List */}
              {filteredTxs.length === 0 ? (
                <div className="bg-gray-900 border border-gray-800 rounded-xl py-12 text-center">
                  <DollarSign className="w-8 h-8 text-gray-700 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">No transactions found</p>
                </div>
              ) : (
                <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
                  <div className="px-4 py-2.5 border-b border-gray-800 text-xs text-gray-500">{filteredTxs.length} transactions</div>
                  <div className="divide-y divide-gray-800 max-h-[400px] overflow-y-auto">
                    {filteredTxs.map(tx => {
                      const cfg = TYPE_CONFIG[tx.type] || { label: tx.type, color: "text-gray-400", bg: "bg-gray-500/10", sign: "" };
                      return (
                        <div key={tx.id} className="flex items-center gap-4 px-4 py-3.5 hover:bg-gray-800/40 transition-colors">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${cfg.bg}`}>
                            {tx.type === "debit" ? <ArrowDownCircle className={`w-4 h-4 ${cfg.color}`} /> : <ArrowUpCircle className={`w-4 h-4 ${cfg.color}`} />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-white text-sm font-medium">{tx.description || cfg.label}</div>
                            <div className="text-gray-500 text-xs">{tx.reference || "—"} · {moment(tx.created_date).format("MMM D, YYYY h:mm A")}</div>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <div className={`font-bold text-sm ${cfg.color}`}>{cfg.sign}${(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                            <span className={`text-xs px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}