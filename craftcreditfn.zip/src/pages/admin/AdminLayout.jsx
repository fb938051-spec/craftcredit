import React, { useState, useEffect } from "react";
import { Outlet, Link, useLocation, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard, Users, CreditCard, FileText,
  LogOut, Menu, X, Building2, ChevronRight, ShieldAlert, Activity, Receipt, Bell
} from "lucide-react";

const navItems = [
  { label: "Overview", path: "/admin", icon: LayoutDashboard },
  { label: "Manage Accounts", path: "/admin/accounts", icon: Users },
  { label: "Fund Account", path: "/admin/fund", icon: CreditCard },
  { label: "Loans & Transfers", path: "/admin/loans", icon: FileText },
  { label: "Client Management", path: "/admin/clients", icon: ShieldAlert },
  { label: "Transaction History", path: "/admin/transactions", icon: Receipt },
  { label: "Activity Log", path: "/admin/activity", icon: Activity },
];

const ADMIN_ACCOUNT = "6533338597";

export default function AdminLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [pendingLoanCount, setPendingLoanCount] = useState(0);

  // Guard: only admin account can access
  useEffect(() => {
    const raw = localStorage.getItem("bankUser");
    if (!raw) { navigate("/signin", { replace: true }); return; }
    const bankUser = JSON.parse(raw);
    const acct = String(bankUser.accountNumber || "").trim();
    if (acct !== ADMIN_ACCOUNT) {
      navigate("/dashboard", { replace: true });
    }
  }, []);

  useEffect(() => {
    base44.entities.LoanApplication.filter({ status: "pending" }).then(data => {
      setPendingLoanCount(data.length);
    });
    const unsubscribe = base44.entities.LoanApplication.subscribe((event) => {
      if (event.type === "create") setPendingLoanCount(c => c + 1);
      if (event.type === "update" && event.data?.status !== "pending") setPendingLoanCount(c => Math.max(0, c - 1));
    });
    return () => unsubscribe();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("bankUser");
    navigate("/signin");
  };

  return (
    <div className="min-h-screen bg-gray-950 flex">
      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-gray-900 border-r border-gray-800 flex flex-col
        transform transition-transform duration-300 lg:relative lg:translate-x-0
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
      `}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-gray-800">
          <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="text-white font-bold text-sm leading-tight">CraftCredit</div>
            <div className="text-blue-400 text-xs font-medium">Admin Portal</div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto text-gray-500 hover:text-white lg:hidden">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const active = location.pathname === item.path || (item.path !== "/admin" && location.pathname.startsWith(item.path));
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all group ${
                  active
                    ? "bg-blue-600 text-white"
                    : "text-gray-400 hover:bg-gray-800 hover:text-white"
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1">{item.label}</span>
                {active && <ChevronRight className="w-3.5 h-3.5 opacity-60" />}
              </Link>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="px-3 py-4 border-t border-gray-800">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="bg-gray-900 border-b border-gray-800 px-4 py-3 flex items-center gap-4 sticky top-0 z-30">
          <button onClick={() => setSidebarOpen(true)} className="text-gray-400 hover:text-white lg:hidden">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <span className="text-gray-400 text-xs uppercase tracking-widest font-semibold">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/admin/loans" className="relative text-gray-400 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              {pendingLoanCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-amber-500 rounded-full flex items-center justify-center text-white text-[10px] font-bold">
                  {pendingLoanCount > 9 ? "9+" : pendingLoanCount}
                </span>
              )}
            </Link>
            <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-white text-xs font-bold">A</span>
            </div>
            <span className="text-gray-300 text-sm hidden sm:block">Administrator</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}