import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { FileText, CheckCircle, XCircle, Clock, Search, RefreshCw, Loader2, AlertCircle, X, RotateCcw, ArrowRightLeft } from "lucide-react";

function LoanModal({ loan, onClose, onUpdate }) {
  const [note, setNote] = useState(loan.adminNote || "");
  const [loading, setLoading] = useState(false);

  const handleDecision = async (decision) => {
    setLoading(true);
    await base44.entities.LoanApplication.update(loan.id, { status: decision, adminNote: note });

    if (decision === "approved") {
      const accounts = await base44.entities.BankAccount.filter({ accountNumber: loan.accountNumber });
      if (accounts.length > 0) {
        const acc = accounts[0];
        const balanceBefore = acc.balance || 0;
        const balanceAfter = balanceBefore + loan.amount;
        await base44.entities.BankAccount.update(acc.id, { balance: balanceAfter });
        await base44.entities.Transaction.create({
          accountNumber: loan.accountNumber,
          fullName: loan.fullName,
          type: "loan_disbursement",
          amount: loan.amount,
          balanceBefore,
          balanceAfter,
          description: `Loan approved: ${loan.purpose}`,
          reference: `LOAN-${loan.id}`,
          status: "completed",
          performedBy: "Administrator",
        });
      }
      if (loan.email) {
        base44.integrations.Core.SendEmail({
          to: loan.email,
          subject: "✅ Your Loan Application Has Been Approved",
          body: `Dear ${loan.fullName},\n\nYour loan application for $${loan.amount.toLocaleString()} has been approved and funds disbursed to your account.\n\nLoan Purpose: ${loan.purpose}${note ? `\nAdmin Note: ${note}` : ""}\n\nThank you for banking with CraftCredit Finance Bank.`,
        });
      }
    } else if (decision === "rejected") {
      if (loan.email) {
        base44.integrations.Core.SendEmail({
          to: loan.email,
          subject: "❌ Loan Application Update",
          body: `Dear ${loan.fullName},\n\nYour loan application for $${(loan.amount || 0).toLocaleString()} could not be approved at this time.${note ? `\nNote: ${note}` : ""}\n\nContact support for more information.\n\nCraftCredit Finance Bank.`,
        });
      }
    }

    setLoading(false);
    onUpdate();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center px-4">
      <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <h2 className="text-white font-bold text-lg">Review Loan Application</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="flex items-center gap-3 bg-gray-800 rounded-xl p-4">
            <div className="w-11 h-11 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-lg flex-shrink-0">
              {(loan.fullName || "?")[0].toUpperCase()}
            </div>
            <div>
              <div className="text-white font-semibold">{loan.fullName}</div>
              <div className="text-gray-400 text-xs font-mono">{loan.accountNumber}</div>
            </div>
            <span className={`ml-auto text-xs font-semibold px-2.5 py-1 rounded-full ${
              loan.status === "pending" ? "bg-amber-500/10 text-amber-400" :
              loan.status === "approved" ? "bg-emerald-500/10 text-emerald-400" :
              "bg-red-500/10 text-red-400"
            }`}>{loan.status}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gray-800 rounded-lg p-3">
              <div className="text-gray-500 text-xs mb-1">Loan Amount</div>
              <div className="text-emerald-400 font-bold text-lg">${(loan.amount || 0).toLocaleString()}</div>
            </div>
            <div className="bg-gray-800 rounded-lg p-3">
              <div className="text-gray-500 text-xs mb-1">Applied On</div>
              <div className="text-white text-sm font-medium">{loan.created_date ? new Date(loan.created_date).toLocaleDateString() : "—"}</div>
            </div>
          </div>
          <div className="bg-gray-800 rounded-lg p-3">
            <div className="text-gray-500 text-xs mb-1">Loan Purpose</div>
            <div className="text-white text-sm">{loan.purpose || "—"}</div>
          </div>
          <div>
            <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider block mb-2">Admin Note (optional)</label>
            <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Add a note..."
              rows={2} className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-blue-500 placeholder-gray-600" />
          </div>
        </div>
        {loan.status === "pending" ? (
          <div className="px-6 pb-6 grid grid-cols-2 gap-3">
            <button onClick={() => handleDecision("rejected")} disabled={loading}
              className="flex items-center justify-center gap-2 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm disabled:opacity-60">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />} Reject
            </button>
            <button onClick={() => handleDecision("approved")} disabled={loading}
              className="flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm disabled:opacity-60">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />} Approve & Disburse
            </button>
          </div>
        ) : (
          <div className="px-6 pb-6">
            <button onClick={onClose} className="w-full py-3 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold text-sm">Close</button>
          </div>
        )}
      </div>
    </div>
  );
}

function TransferModal({ tx, onClose, onUpdate }) {
  const [note, setNote] = useState("");
  const [loading, setLoading] = useState(false);

  const handleAction = async (action) => {
    setLoading(true);
    if (action === "approve") {
      // Deduct balance from sender
      const accounts = await base44.entities.BankAccount.filter({ accountNumber: tx.accountNumber });
      if (accounts.length > 0) {
        const acc = accounts[0];
        const balanceBefore = acc.balance || 0;
        const newBalance = Math.max(0, balanceBefore - tx.amount);
        await base44.entities.BankAccount.update(acc.id, { balance: newBalance });
        await base44.entities.Transaction.update(tx.id, {
          status: "completed",
          balanceBefore,
          balanceAfter: newBalance,
          performedBy: "Administrator",
        });
      } else {
        await base44.entities.Transaction.update(tx.id, { status: "completed", performedBy: "Administrator" });
      }
    } else if (action === "decline") {
      await base44.entities.Transaction.update(tx.id, { status: "declined", performedBy: "Administrator" });
    } else if (action === "reverse") {
      // Reverse: if completed, refund the amount
      const accounts = await base44.entities.BankAccount.filter({ accountNumber: tx.accountNumber });
      if (accounts.length > 0) {
        const acc = accounts[0];
        const balanceBefore = acc.balance || 0;
        const newBalance = balanceBefore + tx.amount;
        await base44.entities.BankAccount.update(acc.id, { balance: newBalance });
      }
      await base44.entities.Transaction.update(tx.id, { status: "reversed", performedBy: "Administrator" });
    }
    setLoading(false);
    onUpdate();
    onClose();
  };

  const isProcessing = tx.status === "processing";
  const isCompleted = tx.status === "completed";

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center px-4">
      <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <h2 className="text-white font-bold text-lg">Review Transfer</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="bg-gray-800 rounded-xl p-4 space-y-2">
            <div className="flex justify-between text-sm"><span className="text-gray-400">Sender</span><span className="text-white font-medium">{tx.fullName}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Account</span><span className="text-white font-mono text-xs">{tx.accountNumber}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Recipient</span><span className="text-white font-medium">{tx.beneficiaryName || "—"}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Recipient Bank</span><span className="text-white">{tx.beneficiaryBank || "—"}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Recipient Acct</span><span className="text-white font-mono text-xs">{tx.beneficiaryAccount || "—"}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Amount</span><span className="text-emerald-400 font-bold">${(tx.amount || 0).toLocaleString()}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Type</span><span className="text-white capitalize">{(tx.type || "").replace(/_/g, " ")}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Reference</span><span className="text-white font-mono text-xs">{tx.reference || "—"}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Narration</span><span className="text-gray-300 text-xs text-right max-w-[60%]">{tx.narration || tx.description || "—"}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-400">Date</span><span className="text-white">{tx.created_date ? new Date(tx.created_date).toLocaleString() : "—"}</span></div>
          </div>
          <div className={`text-xs font-semibold px-3 py-1.5 rounded-full w-fit ${
            tx.status === "processing" ? "bg-amber-500/10 text-amber-400" :
            tx.status === "completed" ? "bg-emerald-500/10 text-emerald-400" :
            tx.status === "declined" ? "bg-red-500/10 text-red-400" :
            "bg-purple-500/10 text-purple-400"
          }`}>Status: {tx.status}</div>
        </div>
        <div className="px-6 pb-6 flex gap-3 flex-wrap">
          {isProcessing && (
            <>
              <button onClick={() => handleAction("approve")} disabled={loading}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm disabled:opacity-60">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />} Approve
              </button>
              <button onClick={() => handleAction("decline")} disabled={loading}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm disabled:opacity-60">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />} Decline
              </button>
            </>
          )}
          {isCompleted && (
            <button onClick={() => handleAction("reverse")} disabled={loading}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-sm disabled:opacity-60">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />} Reverse Transfer
            </button>
          )}
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold text-sm">Close</button>
        </div>
      </div>
    </div>
  );
}

export default function AdminLoans() {
  const [loans, setLoans] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [loadingLoans, setLoadingLoans] = useState(true);
  const [loadingTransfers, setLoadingTransfers] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [selectedLoan, setSelectedLoan] = useState(null);
  const [selectedTransfer, setSelectedTransfer] = useState(null);
  const [tab, setTab] = useState("loans");

  const load = () => {
    setLoadingLoans(true);
    setLoadingTransfers(true);
    base44.entities.LoanApplication.list("-created_date").then(data => { setLoans(data); setLoadingLoans(false); });
    base44.entities.Transaction.filter({}, "-created_date", 200).then(data => {
      setTransfers(data.filter(t => t.type === "wire_transfer" || t.type === "domestic_transfer"));
      setLoadingTransfers(false);
    });
  };

  useEffect(load, []);

  const filteredLoans = loans.filter(l => {
    const matchSearch = (l.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
      (l.accountNumber || "").includes(search);
    const matchFilter = filter === "all" || l.status === filter;
    return matchSearch && matchFilter;
  });

  const filteredTransfers = transfers.filter(t => {
    const matchSearch = (t.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
      (t.accountNumber || "").includes(search) ||
      (t.reference || "").toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "all" || t.status === filter;
    return matchSearch && matchFilter;
  });

  const loanCounts = {
    all: loans.length,
    pending: loans.filter(l => l.status === "pending").length,
    approved: loans.filter(l => l.status === "approved").length,
    rejected: loans.filter(l => l.status === "rejected").length,
  };

  const txCounts = {
    all: transfers.length,
    processing: transfers.filter(t => t.status === "processing").length,
    completed: transfers.filter(t => t.status === "completed").length,
    declined: transfers.filter(t => t.status === "declined").length,
    reversed: transfers.filter(t => t.status === "reversed").length,
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Loans & Transfers</h1>
          <p className="text-gray-400 text-sm mt-1">Review and approve customer requests</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm border border-gray-700 rounded-lg px-3 py-2 hover:border-gray-600 transition-colors">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        <button onClick={() => { setTab("loans"); setFilter("all"); }}
          className={`px-5 py-2 rounded-lg text-sm font-semibold transition-all ${tab === "loans" ? "bg-blue-600 text-white" : "bg-gray-800 text-gray-400 hover:text-white"}`}>
          Loan Applications {loanCounts.pending > 0 && <span className="ml-1 bg-amber-500 text-white text-xs px-1.5 py-0.5 rounded-full">{loanCounts.pending}</span>}
        </button>
        <button onClick={() => { setTab("transfers"); setFilter("all"); }}
          className={`px-5 py-2 rounded-lg text-sm font-semibold transition-all ${tab === "transfers" ? "bg-blue-600 text-white" : "bg-gray-800 text-gray-400 hover:text-white"}`}>
          Transfers {txCounts.processing > 0 && <span className="ml-1 bg-amber-500 text-white text-xs px-1.5 py-0.5 rounded-full">{txCounts.processing}</span>}
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {tab === "loans" && ["all", "pending", "approved", "rejected"].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all capitalize ${
              filter === f
                ? f === "pending" ? "bg-amber-600 text-white"
                  : f === "approved" ? "bg-emerald-600 text-white"
                  : f === "rejected" ? "bg-red-600 text-white"
                  : "bg-blue-600 text-white"
                : "bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700"
            }`}>
            {f} <span className="ml-1 opacity-70">({loanCounts[f] ?? 0})</span>
          </button>
        ))}
        {tab === "transfers" && ["all", "processing", "completed", "declined", "reversed"].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all capitalize ${
              filter === f
                ? f === "processing" ? "bg-amber-600 text-white"
                  : f === "completed" ? "bg-emerald-600 text-white"
                  : f === "declined" ? "bg-red-600 text-white"
                  : f === "reversed" ? "bg-purple-600 text-white"
                  : "bg-blue-600 text-white"
                : "bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700"
            }`}>
            {f} <span className="ml-1 opacity-70">({txCounts[f] ?? 0})</span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-xl px-4 py-3">
        <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search by name, account or reference..."
          className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600" />
      </div>

      {/* Loans Table */}
      {tab === "loans" && (
        loadingLoans ? (
          <div className="flex justify-center py-16"><div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
        ) : filteredLoans.length === 0 ? (
          <div className="bg-gray-900 border border-gray-800 rounded-xl py-16 text-center">
            <FileText className="w-10 h-10 text-gray-700 mx-auto mb-3" />
            <p className="text-gray-500">No loan applications found</p>
          </div>
        ) : (
          <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-800">
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Applicant</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Account No.</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Amount</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Purpose</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Date</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Status</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {filteredLoans.map(loan => (
                    <tr key={loan.id} className="hover:bg-gray-800/40 transition-colors">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 text-xs font-bold flex-shrink-0">
                            {(loan.fullName || "?")[0].toUpperCase()}
                          </div>
                          <span className="text-white font-medium">{loan.fullName}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-gray-400 font-mono text-xs">{loan.accountNumber}</td>
                      <td className="px-5 py-4 text-emerald-400 font-bold">${(loan.amount || 0).toLocaleString()}</td>
                      <td className="px-5 py-4 text-gray-400 max-w-[160px] truncate">{loan.purpose}</td>
                      <td className="px-5 py-4 text-gray-500 text-xs">{loan.created_date ? new Date(loan.created_date).toLocaleDateString() : "—"}</td>
                      <td className="px-5 py-4">
                        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                          loan.status === "pending" ? "bg-amber-500/10 text-amber-400" :
                          loan.status === "approved" ? "bg-emerald-500/10 text-emerald-400" :
                          "bg-red-500/10 text-red-400"}`}>
                          {loan.status === "pending" && <Clock className="w-3 h-3 inline mr-1" />}
                          {loan.status === "approved" && <CheckCircle className="w-3 h-3 inline mr-1" />}
                          {loan.status === "rejected" && <XCircle className="w-3 h-3 inline mr-1" />}
                          {loan.status}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <button onClick={() => setSelectedLoan(loan)}
                          className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                            loan.status === "pending" ? "bg-blue-600 hover:bg-blue-500 text-white" : "bg-gray-800 hover:bg-gray-700 text-gray-300"
                          }`}>
                          {loan.status === "pending" ? "Review" : "View"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      )}

      {/* Transfers Table */}
      {tab === "transfers" && (
        loadingTransfers ? (
          <div className="flex justify-center py-16"><div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" /></div>
        ) : filteredTransfers.length === 0 ? (
          <div className="bg-gray-900 border border-gray-800 rounded-xl py-16 text-center">
            <ArrowRightLeft className="w-10 h-10 text-gray-700 mx-auto mb-3" />
            <p className="text-gray-500">No transfers found</p>
          </div>
        ) : (
          <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-800">
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Sender</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Recipient</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Amount</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Type</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Reference</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Date</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Status</th>
                    <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {filteredTransfers.map(tx => (
                    <tr key={tx.id} className={`hover:bg-gray-800/40 transition-colors ${tx.status === "processing" ? "animate-pulse" : ""}`}>
                      <td className="px-5 py-4">
                        <div className="text-white font-medium">{tx.fullName}</div>
                        <div className="text-gray-500 text-xs font-mono">{tx.accountNumber}</div>
                      </td>
                      <td className="px-5 py-4">
                        <div className="text-white">{tx.beneficiaryName || "—"}</div>
                        <div className="text-gray-500 text-xs">{tx.beneficiaryBank || ""}</div>
                      </td>
                      <td className="px-5 py-4 text-red-400 font-bold">-${(tx.amount || 0).toLocaleString()}</td>
                      <td className="px-5 py-4 text-gray-400 capitalize text-xs">{(tx.type || "").replace(/_/g, " ")}</td>
                      <td className="px-5 py-4 text-gray-500 font-mono text-xs">{tx.reference || "—"}</td>
                      <td className="px-5 py-4 text-gray-500 text-xs">{tx.created_date ? new Date(tx.created_date).toLocaleDateString() : "—"}</td>
                      <td className="px-5 py-4">
                        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                          tx.status === "processing" ? "bg-amber-500/10 text-amber-400" :
                          tx.status === "completed" ? "bg-emerald-500/10 text-emerald-400" :
                          tx.status === "declined" ? "bg-red-500/10 text-red-400" :
                          "bg-purple-500/10 text-purple-400"}`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <button onClick={() => setSelectedTransfer(tx)}
                          className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors ${
                            tx.status === "processing" ? "bg-blue-600 hover:bg-blue-500 text-white" : "bg-gray-800 hover:bg-gray-700 text-gray-300"
                          }`}>
                          {tx.status === "processing" ? "Review" : "View"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )
      )}

      {selectedLoan && <LoanModal loan={selectedLoan} onClose={() => setSelectedLoan(null)} onUpdate={load} />}
      {selectedTransfer && <TransferModal tx={selectedTransfer} onClose={() => setSelectedTransfer(null)} onUpdate={load} />}
    </div>
  );
}