import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Search, DollarSign, CheckCircle, AlertCircle, Loader2, User } from "lucide-react";

export default function AdminFund() {
  const [accounts, setAccounts] = useState([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("credit");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    base44.entities.BankAccount.list().then(setAccounts);
  }, []);

  const filtered = accounts.filter(a =>
    (a.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
    (a.accountNumber || "").includes(search)
  );

  const handleSelect = (acc) => {
    setSelected(acc);
    setSearch(acc.fullName);
    setSuccess("");
    setError("");
  };

  const handleSubmit = async () => {
    if (!selected) return setError("Please select an account.");
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) return setError("Enter a valid amount.");
    if (!description.trim()) return setError("Please add a description.");

    setError("");
    setLoading(true);

    const balanceBefore = selected.balance || 0;
    const balanceAfter = type === "credit"
      ? balanceBefore + amt
      : Math.max(0, balanceBefore - amt);

    // Update account balance
    await base44.entities.BankAccount.update(selected.id, { balance: balanceAfter });

    // Log transaction
    await base44.entities.Transaction.create({
      accountNumber: selected.accountNumber,
      fullName: selected.fullName,
      type,
      amount: amt,
      balanceBefore,
      balanceAfter,
      description,
      reference: `ADM-${Date.now()}`,
      performedBy: "Administrator",
    });

    // Refresh account data
    const updated = await base44.entities.BankAccount.list();
    setAccounts(updated);
    const updatedAcc = updated.find(a => a.id === selected.id);
    setSelected(updatedAcc || null);

    // Send email notification if account has email
    if (selected.email) {
      base44.integrations.Core.SendEmail({
        to: selected.email,
        subject: type === "credit" ? "💰 Funds Credited to Your Account" : "💳 Account Debit Notification",
        body: type === "credit"
          ? `Dear ${selected.fullName},\n\nWe are pleased to inform you that your CraftCredit account has been credited.\n\nTransaction Details:\n- Type: Credit\n- Amount: +$${amt.toLocaleString("en-US", { minimumFractionDigits: 2 })}\n- Description: ${description}\n- Previous Balance: $${balanceBefore.toLocaleString("en-US", { minimumFractionDigits: 2 })}\n- New Balance: $${balanceAfter.toLocaleString("en-US", { minimumFractionDigits: 2 })}\n- Account Number: ${selected.accountNumber}\n\nPlease log in to your account to verify this transaction.\n\nThank you for banking with CraftCredit Finance Bank.\n\nBest regards,\nCraftCredit Finance Bank`
          : `Dear ${selected.fullName},\n\nThis is to notify you that a debit has been made on your CraftCredit account.\n\nTransaction Details:\n- Type: Debit\n- Amount: -$${amt.toLocaleString("en-US", { minimumFractionDigits: 2 })}\n- Description: ${description}\n- Previous Balance: $${balanceBefore.toLocaleString("en-US", { minimumFractionDigits: 2 })}\n- New Balance: $${balanceAfter.toLocaleString("en-US", { minimumFractionDigits: 2 })}\n- Account Number: ${selected.accountNumber}\n\nIf you did not authorize this transaction, please contact us immediately.\n\nThank you for banking with CraftCredit Finance Bank.\n\nBest regards,\nCraftCredit Finance Bank`,
      });
    }

    setLoading(false);
    setSuccess(`Successfully ${type === "credit" ? "credited" : "debited"} $${amt.toLocaleString()} ${type === "credit" ? "to" : "from"} ${selected.fullName}'s account.`);
    setAmount("");
    setDescription("");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-white text-2xl font-bold">Fund Account</h1>
        <p className="text-gray-400 text-sm mt-1">Credit or debit any customer account instantly</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Account Selector */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 space-y-4">
          <h2 className="text-white font-semibold text-base">Select Account</h2>
          <div className="flex items-center gap-2 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2.5">
            <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
            <input
              value={search}
              onChange={e => { setSearch(e.target.value); setSelected(null); }}
              placeholder="Search name or account number..."
              className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600"
            />
          </div>

          {search && !selected && (
            <div className="border border-gray-700 rounded-lg overflow-hidden max-h-60 overflow-y-auto">
              {filtered.length === 0 ? (
                <div className="text-center py-6 text-gray-600 text-sm">No accounts found</div>
              ) : filtered.map(acc => (
                <button
                  key={acc.id}
                  onClick={() => handleSelect(acc)}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-800 transition-colors border-b border-gray-800 last:border-0 text-left"
                >
                  <div className="w-9 h-9 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-sm flex-shrink-0">
                    {(acc.fullName || "?")[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white text-sm font-medium truncate">{acc.fullName}</div>
                    <div className="text-gray-500 text-xs font-mono">{acc.accountNumber}</div>
                  </div>
                  <div className="text-emerald-400 text-xs font-semibold">
                    ${(acc.balance || 0).toLocaleString()}
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* Selected account card */}
          {selected && (
            <div className="bg-blue-600/10 border border-blue-600/30 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-lg">
                  {(selected.fullName || "?")[0].toUpperCase()}
                </div>
                <div>
                  <div className="text-white font-semibold">{selected.fullName}</div>
                  <div className="text-gray-400 text-xs font-mono">{selected.accountNumber}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div className="bg-gray-800 rounded-lg p-3">
                  <div className="text-gray-500 text-xs mb-1">Account Type</div>
                  <div className="text-white text-sm font-medium">{selected.accountType || "—"}</div>
                </div>
                <div className="bg-gray-800 rounded-lg p-3">
                  <div className="text-gray-500 text-xs mb-1">Current Balance</div>
                  <div className="text-emerald-400 text-sm font-bold">
                    ${(selected.balance || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                  </div>
                </div>
              </div>
              <button
                onClick={() => { setSelected(null); setSearch(""); }}
                className="text-xs text-gray-500 hover:text-gray-300 underline"
              >
                Change account
              </button>
            </div>
          )}
        </div>

        {/* Fund Form */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 space-y-5">
          <h2 className="text-white font-semibold text-base">Transaction Details</h2>

          {/* Type toggle */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-gray-800 rounded-lg">
            <button
              onClick={() => setType("credit")}
              className={`py-2.5 rounded-md text-sm font-semibold transition-all ${type === "credit" ? "bg-emerald-600 text-white shadow" : "text-gray-400 hover:text-white"}`}
            >
              Credit (+)
            </button>
            <button
              onClick={() => setType("debit")}
              className={`py-2.5 rounded-md text-sm font-semibold transition-all ${type === "debit" ? "bg-red-600 text-white shadow" : "text-gray-400 hover:text-white"}`}
            >
              Debit (−)
            </button>
          </div>

          {/* Amount */}
          <div>
            <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider block mb-2">Amount (USD)</label>
            <div className="flex items-center gap-2 bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 focus-within:border-blue-500 transition-colors">
              <DollarSign className="w-4 h-4 text-gray-500 flex-shrink-0" />
              <input
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.00"
                className="flex-1 bg-transparent text-white text-lg font-semibold outline-none placeholder-gray-700"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider block mb-2">Description / Narration</label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="e.g. Account funding by admin, Bonus credit..."
              rows={3}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-blue-500 transition-colors placeholder-gray-600"
            />
          </div>

          {/* Preview */}
          {selected && amount && parseFloat(amount) > 0 && (
            <div className={`rounded-lg p-3 border ${type === "credit" ? "bg-emerald-500/5 border-emerald-500/20" : "bg-red-500/5 border-red-500/20"}`}>
              <div className="text-gray-400 text-xs mb-1">New Balance After Transaction</div>
              <div className={`text-lg font-bold ${type === "credit" ? "text-emerald-400" : "text-red-400"}`}>
                ${(type === "credit"
                  ? (selected.balance || 0) + parseFloat(amount)
                  : Math.max(0, (selected.balance || 0) - parseFloat(amount))
                ).toLocaleString("en-US", { minimumFractionDigits: 2 })}
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-3 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          )}
          {success && (
            <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-4 py-3 text-emerald-400 text-sm">
              <CheckCircle className="w-4 h-4 flex-shrink-0" />
              {success}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={loading || !selected}
            className={`w-full py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
              type === "credit" ? "bg-emerald-600 hover:bg-emerald-500 text-white" : "bg-red-600 hover:bg-red-500 text-white"
            }`}
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <DollarSign className="w-4 h-4" />}
            {loading ? "Processing..." : `${type === "credit" ? "Credit" : "Debit"} Account`}
          </button>
        </div>
      </div>
    </div>
  );
}