import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { RefreshCw, Search, Activity, DollarSign, ShieldAlert, ArrowUpCircle, ArrowDownCircle } from "lucide-react";
import moment from "moment";

const TYPE_CONFIG = {
  credit:           { label: "Credit",          color: "text-emerald-400", bg: "bg-emerald-500/10", icon: ArrowUpCircle },
  debit:            { label: "Debit",            color: "text-red-400",     bg: "bg-red-500/10",     icon: ArrowDownCircle },
  loan_disbursement:{ label: "Loan",             color: "text-blue-400",    bg: "bg-blue-500/10",    icon: DollarSign },
  deposit:          { label: "Deposit",          color: "text-purple-400",  bg: "bg-purple-500/10",  icon: ArrowUpCircle },
};

export default function AdminActivityLog() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const load = async () => {
    setLoading(true);
    const data = await base44.entities.Transaction.list("-created_date", 200);
    setLogs(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = logs.filter(l => {
    const matchSearch =
      (l.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
      (l.accountNumber || "").includes(search) ||
      (l.description || "").toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || l.type === typeFilter;
    return matchSearch && matchType;
  });

  // Only show logs that have a description (status changes have descriptions)
  // Split into admin actions vs fund adjustments
  const adminActions = filtered.filter(l => l.amount === 0 || (l.description || "").includes("status changed") || (l.description || "").includes("frozen") || (l.description || "").includes("BULK"));
  const fundActions = filtered.filter(l => l.amount > 0);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Activity Log</h1>
          <p className="text-gray-400 text-sm mt-1">All admin actions and fund adjustments</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm border border-gray-700 rounded-lg px-3 py-2 hover:border-gray-600 transition-colors">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-xl px-4 py-2.5 flex-1 min-w-48">
          <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search name, account, description..."
            className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600"
          />
        </div>
        <select
          value={typeFilter}
          onChange={e => setTypeFilter(e.target.value)}
          className="bg-gray-900 border border-gray-800 text-gray-300 text-sm rounded-xl px-4 py-2.5 outline-none"
        >
          <option value="all">All Types</option>
          <option value="credit">Credit</option>
          <option value="debit">Debit</option>
          <option value="loan_disbursement">Loan Disbursement</option>
          <option value="deposit">Deposit</option>
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-gray-900 border border-gray-800 rounded-xl py-16 text-center">
          <Activity className="w-10 h-10 text-gray-700 mx-auto mb-3" />
          <p className="text-gray-500">No activity found</p>
        </div>
      ) : (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-800 text-xs text-gray-500 font-semibold uppercase tracking-wider">
            {filtered.length} entries
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left px-5 py-3 text-gray-500 font-semibold text-xs uppercase tracking-wider">Date & Time</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-semibold text-xs uppercase tracking-wider">Account</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-semibold text-xs uppercase tracking-wider">Type</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-semibold text-xs uppercase tracking-wider">Amount</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-semibold text-xs uppercase tracking-wider">Description</th>
                  <th className="text-left px-5 py-3 text-gray-500 font-semibold text-xs uppercase tracking-wider">Performed By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {filtered.map(log => {
                  const cfg = TYPE_CONFIG[log.type] || { label: log.type, color: "text-gray-400", bg: "bg-gray-500/10", icon: Activity };
                  const Icon = cfg.icon;
                  const isStatusChange = !log.amount || log.amount === 0;
                  return (
                    <tr key={log.id} className="hover:bg-gray-800/40 transition-colors">
                      <td className="px-5 py-3.5 text-gray-400 text-xs whitespace-nowrap">
                        <div>{moment(log.created_date).format("MMM D, YYYY")}</div>
                        <div className="text-gray-600">{moment(log.created_date).format("h:mm A")}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="text-white text-sm font-medium">{log.fullName || "—"}</div>
                        <div className="text-gray-500 text-xs font-mono">{log.accountNumber}</div>
                      </td>
                      <td className="px-5 py-3.5">
                        {isStatusChange ? (
                          <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full bg-purple-500/10 text-purple-400">
                            <ShieldAlert className="w-3 h-3" /> Status Change
                          </span>
                        ) : (
                          <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.bg} ${cfg.color}`}>
                            <Icon className="w-3 h-3" /> {cfg.label}
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3.5">
                        {log.amount > 0 ? (
                          <span className={`font-semibold ${log.type === "debit" ? "text-red-400" : "text-emerald-400"}`}>
                            {log.type === "debit" ? "−" : "+"}${log.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                          </span>
                        ) : (
                          <span className="text-gray-600">—</span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-gray-400 text-xs max-w-xs truncate">{log.description || "—"}</td>
                      <td className="px-5 py-3.5 text-gray-500 text-xs">{log.performedBy || "System"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}