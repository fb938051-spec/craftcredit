import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Mail, Send, Search, Users, User, Loader2, CheckCircle, AlertCircle } from "lucide-react";

export default function AdminEmail() {
  const [accounts, setAccounts] = useState([]);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null); // null = all users
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");
  const [mode, setMode] = useState("individual"); // "individual" | "all"

  useEffect(() => {
    base44.entities.BankAccount.list().then(setAccounts);
  }, []);

  const filtered = accounts.filter(a =>
    (a.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
    (a.accountNumber || "").includes(search) ||
    (a.email || "").toLowerCase().includes(search.toLowerCase())
  );

  const handleSend = async () => {
    if (!subject.trim()) return setError("Please enter a subject.");
    if (!body.trim()) return setError("Please enter a message body.");
    if (mode === "individual" && !selected) return setError("Please select a recipient.");

    setError("");
    setLoading(true);

    const recipients = mode === "all" ? accounts : [selected];
    const validRecipients = recipients.filter(a => a.email);

    await Promise.all(validRecipients.map(acc =>
      base44.integrations.Core.SendEmail({
        to: acc.email,
        subject,
        body: body.replace("{name}", acc.fullName).replace("{accountNumber}", acc.accountNumber),
      })
    ));

    setLoading(false);
    setSuccess(`Email sent to ${validRecipients.length} recipient(s) successfully.`);
    setSubject("");
    setBody("");
    setSelected(null);
    setSearch("");
    setTimeout(() => setSuccess(""), 5000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-white text-2xl font-bold">Email Clients</h1>
        <p className="text-gray-400 text-sm mt-1">Send emails to individual customers or broadcast to all</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recipient Selector */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 space-y-4">
          <h2 className="text-white font-semibold">Select Recipients</h2>

          {/* Mode toggle */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-gray-800 rounded-lg">
            <button
              onClick={() => { setMode("individual"); setSelected(null); }}
              className={`py-2.5 rounded-md text-sm font-semibold flex items-center justify-center gap-2 transition-all ${mode === "individual" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white"}`}
            >
              <User className="w-4 h-4" /> Individual
            </button>
            <button
              onClick={() => { setMode("all"); setSelected(null); setSearch(""); }}
              className={`py-2.5 rounded-md text-sm font-semibold flex items-center justify-center gap-2 transition-all ${mode === "all" ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white"}`}
            >
              <Users className="w-4 h-4" /> All Clients
            </button>
          </div>

          {mode === "all" && (
            <div className="bg-blue-600/10 border border-blue-600/30 rounded-xl p-4 text-center">
              <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <div className="text-white font-semibold">{accounts.length} Clients</div>
              <div className="text-gray-400 text-xs mt-1">Email will be sent to all registered account holders</div>
              <div className="text-gray-500 text-xs mt-1">Tip: Use <span className="text-blue-400 font-mono">{"{name}"}</span> and <span className="text-blue-400 font-mono">{"{accountNumber}"}</span> as placeholders</div>
            </div>
          )}

          {mode === "individual" && (
            <>
              <div className="flex items-center gap-2 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2.5">
                <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
                <input
                  value={search}
                  onChange={e => { setSearch(e.target.value); setSelected(null); }}
                  placeholder="Search name, email, or account..."
                  className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600"
                />
              </div>

              {search && !selected && (
                <div className="border border-gray-700 rounded-lg overflow-hidden max-h-52 overflow-y-auto">
                  {filtered.length === 0 ? (
                    <div className="text-center py-6 text-gray-600 text-sm">No accounts found</div>
                  ) : filtered.map(acc => (
                    <button
                      key={acc.id}
                      onClick={() => { setSelected(acc); setSearch(acc.fullName); }}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-800 transition-colors border-b border-gray-800 last:border-0 text-left"
                    >
                      <div className="w-8 h-8 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-xs flex-shrink-0">
                        {(acc.fullName || "?")[0].toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-white text-sm font-medium truncate">{acc.fullName}</div>
                        <div className="text-gray-500 text-xs">{acc.email}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {selected && (
                <div className="bg-blue-600/10 border border-blue-600/30 rounded-xl p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 font-bold text-base flex-shrink-0">
                    {(selected.fullName || "?")[0].toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-white font-semibold">{selected.fullName}</div>
                    <div className="text-gray-400 text-xs">{selected.email}</div>
                    <div className="text-gray-500 text-xs font-mono">{selected.accountNumber}</div>
                  </div>
                  <button onClick={() => { setSelected(null); setSearch(""); }} className="text-gray-600 hover:text-gray-400 text-xs underline flex-shrink-0">Change</button>
                </div>
              )}
            </>
          )}
        </div>

        {/* Compose */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-5 space-y-4">
          <h2 className="text-white font-semibold">Compose Message</h2>

          <div>
            <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider block mb-2">Subject</label>
            <input
              value={subject}
              onChange={e => setSubject(e.target.value)}
              placeholder="Email subject..."
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none focus:border-blue-500 transition-colors placeholder-gray-600"
            />
          </div>

          <div>
            <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider block mb-2">Message Body</label>
            <textarea
              value={body}
              onChange={e => setBody(e.target.value)}
              placeholder={`Type your message here...\n\nYou can use {name} and {accountNumber} as dynamic placeholders.`}
              rows={7}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-blue-500 transition-colors placeholder-gray-600"
            />
          </div>

          {error && (
            <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-lg px-4 py-3 text-red-400 text-sm">
              <AlertCircle className="w-4 h-4 flex-shrink-0" /> {error}
            </div>
          )}
          {success && (
            <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-4 py-3 text-emerald-400 text-sm">
              <CheckCircle className="w-4 h-4 flex-shrink-0" /> {success}
            </div>
          )}

          <button
            onClick={handleSend}
            disabled={loading}
            className="w-full py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            {loading ? "Sending..." : mode === "all" ? `Send to All ${accounts.length} Clients` : "Send Email"}
          </button>
        </div>
      </div>
    </div>
  );
}