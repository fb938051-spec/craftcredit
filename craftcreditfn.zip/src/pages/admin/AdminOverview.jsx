import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Users, DollarSign, FileText, TrendingUp, ArrowRight, Clock, CheckCircle, XCircle, Bell, X } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

export default function AdminOverview() {
  const [accounts, setAccounts] = useState([]);
  const [loans, setLoans] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newLoanAlerts, setNewLoanAlerts] = useState([]);
  const seenIds = useRef(new Set());

  useEffect(() => {
    Promise.all([
      base44.entities.BankAccount.list(),
      base44.entities.LoanApplication.list("-created_date", 50),
      base44.entities.Transaction.list("-created_date", 10),
    ]).then(([a, l, t]) => {
      setAccounts(a);
      setLoans(l);
      setTransactions(t);
      // Seed seen IDs so existing loans don't trigger alerts on load
      l.forEach(loan => seenIds.current.add(loan.id));
      setLoading(false);
    });

    // Real-time subscription for new loan applications
    const unsubscribe = base44.entities.LoanApplication.subscribe((event) => {
      if (event.type === "create" && !seenIds.current.has(event.id)) {
        seenIds.current.add(event.id);
        const loan = event.data;
        setNewLoanAlerts(prev => [...prev, { id: event.id, loan }]);
        setLoans(prev => [loan, ...prev]);
      }
    });

    return () => unsubscribe();
  }, []);

  const dismissAlert = (id) => setNewLoanAlerts(prev => prev.filter(a => a.id !== id));

  const totalBalance = accounts.reduce((s, a) => s + (a.balance || 0), 0);
  const pendingLoans = loans.filter(l => l.status === "pending");
  const approvedLoans = loans.filter(l => l.status === "approved");
  const pendingLoanVolume = pendingLoans.reduce((s, l) => s + (l.amount || 0), 0);
  const approvedLoanVolume = approvedLoans.reduce((s, l) => s + (l.amount || 0), 0);

  // Build chart data: last 6 months buckets
  const chartData = (() => {
    const months = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const label = d.toLocaleString("default", { month: "short" });
      const y = d.getFullYear();
      const m = d.getMonth();
      const deposits = accounts
        .filter(a => { const c = new Date(a.created_date); return c.getFullYear() === y && c.getMonth() === m; })
        .reduce((s, a) => s + (a.balance || 0), 0);
      const loanVol = loans
        .filter(l => l.status === "pending" && (() => { const c = new Date(l.created_date); return c.getFullYear() === y && c.getMonth() === m; })())
        .reduce((s, l) => s + (l.amount || 0), 0);
      months.push({ month: label, Deposits: deposits, "Pending Loans": loanVol });
    }
    return months;
  })();

  const stats = [
    { label: "Total Accounts", value: accounts.length, icon: Users, light: "bg-blue-500/10 text-blue-400" },
    { label: "Total Deposits", value: `$${totalBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}`, icon: DollarSign, light: "bg-emerald-500/10 text-emerald-400" },
    { label: "Pending Loans", value: pendingLoans.length, icon: Clock, light: "bg-amber-500/10 text-amber-400" },
    { label: "Approved Loans", value: approvedLoans.length, icon: TrendingUp, light: "bg-purple-500/10 text-purple-400" },
  ];

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-white text-2xl font-bold">Dashboard Overview</h1>
        <p className="text-gray-400 text-sm mt-1">Welcome back, Administrator</p>
      </div>

      {/* New Loan Alerts */}
      {newLoanAlerts.length > 0 && (
        <div className="space-y-2">
          {newLoanAlerts.map(({ id, loan }) => (
            <div key={id} className="flex items-center gap-3 bg-amber-500/10 border border-amber-500/30 rounded-xl px-4 py-3 animate-pulse-once">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                <Bell className="w-4 h-4 text-amber-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-amber-300 text-sm font-semibold">New Loan Application Submitted</p>
                <p className="text-amber-400/70 text-xs truncate">
                  {loan?.fullName || "A user"} applied for ${(loan?.amount || 0).toLocaleString()} — {loan?.purpose || "no purpose given"}
                </p>
              </div>
              <Link to="/admin/loans" className="text-amber-400 text-xs font-semibold hover:underline whitespace-nowrap">
                Review →
              </Link>
              <button onClick={() => dismissAlert(id)} className="text-amber-500 hover:text-amber-300 ml-1">
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(s => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-xl p-4">
              <div className={`w-10 h-10 rounded-lg ${s.light} flex items-center justify-center mb-3`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-white text-xl font-bold">{s.value}</div>
              <div className="text-gray-500 text-xs mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Growth Chart */}
      <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-white font-semibold">Bank Growth Overview</h2>
            <p className="text-gray-500 text-xs mt-0.5">Total deposits vs. pending loan volume by month</p>
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-gray-400"><span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block" /> Deposits</span>
            <span className="flex items-center gap-1.5 text-gray-400"><span className="w-3 h-3 rounded-sm bg-amber-500 inline-block" /> Pending Loans</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={chartData} barCategoryGap="30%" barGap={4}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
            <XAxis dataKey="month" tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "#6b7280", fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => v >= 1000 ? `$${(v/1000).toFixed(0)}k` : `$${v}`} />
            <Tooltip
              contentStyle={{ backgroundColor: "#111827", border: "1px solid #1f2937", borderRadius: "8px", color: "#fff", fontSize: "12px" }}
              formatter={(value) => [`$${value.toLocaleString()}`, undefined]}
            />
            <Bar dataKey="Deposits" fill="#10b981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Pending Loans" fill="#f59e0b" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="bg-gray-800/50 rounded-lg px-4 py-3">
            <div className="text-gray-500 text-xs mb-1">Total Deposit Volume</div>
            <div className="text-emerald-400 font-bold text-lg">${totalBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
          </div>
          <div className="bg-gray-800/50 rounded-lg px-4 py-3">
            <div className="text-gray-500 text-xs mb-1">Pending Loan Volume</div>
            <div className="text-amber-400 font-bold text-lg">${pendingLoanVolume.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Recent Loan Applications */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800">
            <h2 className="text-white font-semibold flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" /> Recent Loan Applications
            </h2>
            <Link to="/admin/loans" className="text-blue-400 text-xs hover:underline flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-gray-800">
            {loans.slice(0, 5).length === 0 ? (
              <div className="text-center py-8 text-gray-600 text-sm">No loan applications yet</div>
            ) : loans.slice(0, 5).map(loan => (
              <div key={loan.id} className="flex items-center gap-3 px-5 py-3">
                <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {(loan.fullName || "?")[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium truncate">{loan.fullName}</div>
                  <div className="text-gray-500 text-xs">${(loan.amount || 0).toLocaleString()}</div>
                </div>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
                  loan.status === "pending" ? "bg-amber-500/10 text-amber-400" :
                  loan.status === "approved" ? "bg-emerald-500/10 text-emerald-400" :
                  "bg-red-500/10 text-red-400"
                }`}>
                  {loan.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-gray-800">
            <h2 className="text-white font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" /> Recent Transactions
            </h2>
          </div>
          <div className="divide-y divide-gray-800">
            {transactions.slice(0, 5).length === 0 ? (
              <div className="text-center py-8 text-gray-600 text-sm">No transactions yet</div>
            ) : transactions.slice(0, 5).map(tx => (
              <div key={tx.id} className="flex items-center gap-3 px-5 py-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                  tx.type === "credit" || tx.type === "deposit" || tx.type === "loan_disbursement"
                    ? "bg-emerald-500/10" : "bg-red-500/10"
                }`}>
                  {tx.type === "credit" || tx.type === "deposit" || tx.type === "loan_disbursement"
                    ? <CheckCircle className="w-4 h-4 text-emerald-400" />
                    : <XCircle className="w-4 h-4 text-red-400" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium truncate">{tx.fullName || tx.accountNumber}</div>
                  <div className="text-gray-500 text-xs capitalize">{tx.type?.replace("_", " ")}</div>
                </div>
                <div className={`text-sm font-semibold ${
                  tx.type === "debit" ? "text-red-400" : "text-emerald-400"
                }`}>
                  {tx.type === "debit" ? "-" : "+"}${(tx.amount || 0).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}