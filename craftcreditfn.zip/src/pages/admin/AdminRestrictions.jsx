import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Search, ShieldAlert, ShieldOff, ShieldCheck, Snowflake, AlertTriangle,
  Loader2, CheckCircle, AlertCircle, RefreshCw, X
} from "lucide-react";

const STATUS_CONFIG = {
  active:      { label: "Active",      color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/30", icon: ShieldCheck },
  frozen:      { label: "Frozen",      color: "text-blue-400",    bg: "bg-blue-500/10 border-blue-500/30",       icon: Snowflake },
  restricted:  { label: "Restricted",  color: "text-amber-400",   bg: "bg-amber-500/10 border-amber-500/30",     icon: ShieldAlert },
  suspended:   { label: "Suspended",   color: "text-orange-400",  bg: "bg-orange-500/10 border-orange-500/30",   icon: ShieldOff },
  closed:      { label: "Closed",      color: "text-red-400",     bg: "bg-red-500/10 border-red-500/30",         icon: X },
};

function AccountModal({ account, onClose, onSave }) {
  const [status, setStatus] = useState(account.status || "active");
  const [warningMessage, setWarningMessage] = useState(account.warningMessage || "");
  const [restrictionNote, setRestrictionNote] = useState(account.restrictionNote || "");
  const [frozenReason, setFrozenReason] = useState(account.frozenReason || "");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState("");

  const handleSave = async () => {
    setLoading(true);
    await base44.entities.BankAccount.update(account.id, {
      status,
      warningMessage,
      restrictionNote,
      frozenReason,
    });

    // Notify user by email if status changed
    if (account.email && status !== account.status) {
      const messages = {
        frozen: `Your CraftCredit account (${account.accountNumber}) has been temporarily frozen.\n\nReason: ${frozenReason || "Please contact support for more information."}\n\nTo resolve this, please contact our customer support team.`,
        restricted: `Your CraftCredit account (${account.accountNumber}) has been placed under restrictions.\n\nNote: ${restrictionNote || "Please contact support for more information."}\n\nSome account features may be limited. Contact support to resolve this.`,
        suspended: `Your CraftCredit account (${account.accountNumber}) has been suspended.\n\nPlease contact customer support for more information and next steps.`,
        active: `Great news! Your CraftCredit account (${account.accountNumber}) has been restored to active status. You can now access all account features normally.`,
      };
      if (messages[status]) {
        base44.integrations.Core.SendEmail({
          to: account.email,
          subject: status === "active" ? "✅ Account Restored" : `⚠️ Account ${STATUS_CONFIG[status]?.label} Notice`,
          body: `Dear ${account.fullName},\n\n${messages[status]}\n\nBest regards,\nCraftCredit Finance Bank`,
        });
      }
    }

    // Notify if warning added
    if (account.email && warningMessage && warningMessage !== account.warningMessage) {
      base44.integrations.Core.SendEmail({
        to: account.email,
        subject: "⚠️ Important Notice from CraftCredit Finance Bank",
        body: `Dear ${account.fullName},\n\nThis is an important notice regarding your account (${account.accountNumber}):\n\n${warningMessage}\n\nIf you have any questions, please contact our customer support immediately.\n\nBest regards,\nCraftCredit Finance Bank`,
      });
    }

    setLoading(false);
    setSuccess("Account updated successfully.");
    setTimeout(() => { onSave(); onClose(); }, 1200);
  };

  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.active;

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center px-4 overflow-y-auto">
      <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-lg my-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <div>
            <h2 className="text-white font-bold text-lg">Manage Account</h2>
            <p className="text-gray-500 text-xs mt-0.5">{account.fullName} · {account.accountNumber}</p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 py-5 space-y-5">
          {/* Account Status */}
          <div>
            <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider block mb-3">Account Status</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {Object.entries(STATUS_CONFIG).map(([key, conf]) => {
                const Icon = conf.icon;
                return (
                  <button
                    key={key}
                    onClick={() => setStatus(key)}
                    className={`flex items-center gap-2 px-3 py-2.5 rounded-lg border text-sm font-semibold transition-all ${
                      status === key ? `${conf.bg} ${conf.color} border-opacity-100` : "bg-gray-800 border-gray-700 text-gray-500 hover:text-gray-300"
                    }`}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    {conf.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Warning Message */}
          <div>
            <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 mb-2">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Warning Message (shown to user)
            </label>
            <textarea
              value={warningMessage}
              onChange={e => setWarningMessage(e.target.value)}
              placeholder="e.g. Your account is under review. Please contact support."
              rows={3}
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-amber-500 transition-colors placeholder-gray-600"
            />
            <p className="text-gray-600 text-xs mt-1">This message will be emailed to the client immediately.</p>
          </div>

          {/* Frozen Reason */}
          {(status === "frozen") && (
            <div>
              <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 mb-2">
                <Snowflake className="w-3.5 h-3.5 text-blue-400" /> Reason for Freeze
              </label>
              <textarea
                value={frozenReason}
                onChange={e => setFrozenReason(e.target.value)}
                placeholder="e.g. Suspicious activity detected, pending investigation..."
                rows={2}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-blue-500 transition-colors placeholder-gray-600"
              />
            </div>
          )}

          {/* Restriction Note */}
          {(status === "restricted") && (
            <div>
              <label className="text-gray-400 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 mb-2">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" /> Restriction Details
              </label>
              <textarea
                value={restrictionNote}
                onChange={e => setRestrictionNote(e.target.value)}
                placeholder="e.g. Outgoing transfers disabled pending KYC verification..."
                rows={2}
                className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-sm outline-none resize-none focus:border-amber-500 transition-colors placeholder-gray-600"
              />
            </div>
          )}

          {success && (
            <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg px-4 py-3 text-emerald-400 text-sm">
              <CheckCircle className="w-4 h-4 flex-shrink-0" /> {success}
            </div>
          )}
        </div>

        <div className="px-6 pb-6 flex gap-3">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold text-sm transition-all">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={loading}
            className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all disabled:opacity-60"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
            {loading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminRestrictions() {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState(null);

  const load = () => {
    setLoading(true);
    base44.entities.BankAccount.list().then(data => {
      setAccounts(data);
      setLoading(false);
    });
  };

  useEffect(load, []);

  const filtered = accounts.filter(a => {
    const matchSearch = (a.fullName || "").toLowerCase().includes(search.toLowerCase()) ||
      (a.accountNumber || "").includes(search);
    const matchFilter = filter === "all" || a.status === filter;
    return matchSearch && matchFilter;
  });

  const counts = {
    all: accounts.length,
    active: accounts.filter(a => a.status === "active").length,
    frozen: accounts.filter(a => a.status === "frozen").length,
    restricted: accounts.filter(a => a.status === "restricted").length,
    suspended: accounts.filter(a => a.status === "suspended").length,
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-white text-2xl font-bold">Account Restrictions</h1>
          <p className="text-gray-400 text-sm mt-1">Freeze, restrict, suspend accounts and add warning messages</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 text-gray-400 hover:text-white text-sm border border-gray-700 rounded-lg px-3 py-2 hover:border-gray-600 transition-colors">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {["all", "active", "frozen", "restricted", "suspended"].map(f => {
          const conf = STATUS_CONFIG[f];
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all capitalize ${
                filter === f
                  ? f === "all" ? "bg-blue-600 text-white" : `${conf?.bg} ${conf?.color}`
                  : "bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700"
              }`}
            >
              {f} <span className="ml-1 opacity-70">({counts[f] ?? accounts.length})</span>
            </button>
          );
        })}
      </div>

      {/* Search */}
      <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-xl px-4 py-3">
        <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search by name or account number..."
          className="flex-1 bg-transparent text-white text-sm outline-none placeholder-gray-600"
        />
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-gray-900 border border-gray-800 rounded-xl py-16 text-center">
          <ShieldAlert className="w-10 h-10 text-gray-700 mx-auto mb-3" />
          <p className="text-gray-500">No accounts found</p>
        </div>
      ) : (
        <div className="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Account Holder</th>
                  <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Account No.</th>
                  <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Status</th>
                  <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Warning</th>
                  <th className="text-left px-5 py-3.5 text-gray-500 font-semibold text-xs uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {filtered.map(acc => {
                  const cfg = STATUS_CONFIG[acc.status] || STATUS_CONFIG.active;
                  const Icon = cfg.icon;
                  return (
                    <tr key={acc.id} className="hover:bg-gray-800/40 transition-colors">
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-600/20 flex items-center justify-center text-blue-400 text-xs font-bold flex-shrink-0">
                            {(acc.fullName || "?")[0].toUpperCase()}
                          </div>
                          <div>
                            <div className="text-white font-medium">{acc.fullName}</div>
                            <div className="text-gray-500 text-xs">{acc.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-gray-400 font-mono text-xs">{acc.accountNumber}</td>
                      <td className="px-5 py-4">
                        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border ${cfg.bg} ${cfg.color}`}>
                          <Icon className="w-3 h-3" /> {cfg.label}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-gray-500 text-xs max-w-[180px]">
                        {acc.warningMessage ? (
                          <span className="text-amber-400 truncate block">{acc.warningMessage}</span>
                        ) : (
                          <span className="text-gray-700">—</span>
                        )}
                      </td>
                      <td className="px-5 py-4">
                        <button
                          onClick={() => setSelected(acc)}
                          className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors"
                        >
                          Manage
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {selected && (
        <AccountModal
          account={selected}
          onClose={() => setSelected(null)}
          onSave={load}
        />
      )}
    </div>
  );
}