import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, User, Lock } from "lucide-react";

const ADMIN_ACCOUNT = "6533338597";

export default function SignIn() {
  const navigate = useNavigate();
  const [showPass, setShowPass] = useState(false);
  const [accountId, setAccountId] = useState("");
  const [password, setPassword] = useState("");
  const [captcha, setCaptcha] = useState("");
  const [error, setError] = useState("");
  const captchaCode = "MCBZ9";

  const handleLogin = () => {
    setError("");
    if (!accountId || !password) { setError("Please enter your Account ID and Password."); return; }
    if (captcha.toUpperCase() !== captchaCode) { setError("Captcha is incorrect. Please try again."); return; }

    // Hardcoded admin credentials — bypasses localStorage account lookup
    if (accountId.trim() === ADMIN_ACCOUNT && password === "Admin@2024") {
      localStorage.setItem("bankUser", JSON.stringify({
        name: "Administrator",
        accountType: "Admin",
        accountNumber: ADMIN_ACCOUNT,
        email: "admin@craftcredit.com",
        isAdmin: true,
      }));
      navigate("/pin");
      return;
    }

    const accounts = JSON.parse(localStorage.getItem("bankAccounts") || "[]");
    const match = accounts.find(acc => acc.accountNumber === accountId && acc.password === password);

    if (match) {
      localStorage.setItem("bankUser", JSON.stringify({
        name: match.fullName,
        accountType: match.accountType,
        accountNumber: match.accountNumber,
        email: match.email,
        profileImage: match.profileImage || null,
      }));
      navigate("/pin");
    } else {
      setError("Invalid Account ID or Password. Please check your credentials.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <div className="h-48 relative overflow-hidden">
        <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&h=300&fit=crop" alt="bank" className="w-full h-full object-cover" />
      </div>

      <div className="flex-1 flex items-start justify-center -mt-6 px-4 pb-8">
        <div className="bg-white w-full max-w-sm rounded-2xl shadow-lg p-6">
          <h1 className="text-2xl font-semibold text-gray-800 text-center mb-1">Sign In</h1>
          <p className="text-gray-400 text-sm text-center mb-2">Log in using your Account Number.</p>
          <p className="text-xs text-blue-600 text-center mb-5 bg-blue-50 rounded py-1.5 px-2">Use the Account Number generated during registration as your Account ID.</p>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded px-3 py-2 mb-4">{error}</div>
          )}

          <div className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider block mb-1">Account ID (Account Number)</label>
              <div className="flex items-center border border-gray-200 rounded px-3 py-3 gap-2">
                <User className="w-4 h-4 text-gray-300 flex-shrink-0" />
                <input className="flex-1 text-sm text-gray-700 outline-none placeholder-gray-300" placeholder="e.g. 4027564938"
                  value={accountId} onChange={e => setAccountId(e.target.value)} />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider block mb-1">PASSWORD</label>
              <div className="flex items-center border border-gray-200 rounded px-3 py-3 gap-2">
                <Lock className="w-4 h-4 text-gray-300 flex-shrink-0" />
                <input className="flex-1 text-sm text-gray-700 outline-none placeholder-gray-300" placeholder="Password"
                  type={showPass ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} />
                <button type="button" onClick={() => setShowPass(!showPass)} className="text-gray-300">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-black px-4 py-2 rounded font-mono font-bold text-white text-lg tracking-widest select-none flex-shrink-0">{captchaCode}</div>
              <div className="flex-1 border border-gray-200 rounded px-3 py-3">
                <input className="w-full text-sm text-gray-700 outline-none placeholder-gray-300" placeholder="Enter Captcha"
                  value={captcha} onChange={e => setCaptcha(e.target.value)} />
              </div>
            </div>

            <button onClick={handleLogin} className="w-full py-3.5 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700 transition-colors">
              Log In
            </button>

            <p className="text-sm text-gray-500 text-center cursor-pointer hover:underline">Forgot Password?</p>

            <div className="text-center space-y-1 pt-1">
              <Link to="/create-account" className="block text-sm text-blue-600 hover:underline">Don't have an account? Create a new one</Link>
              <Link to="/" className="block text-sm text-gray-500 hover:underline">Back to Home Page</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}