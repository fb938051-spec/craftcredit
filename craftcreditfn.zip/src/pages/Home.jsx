import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu, X, Star, Mail, MapPin, ChevronUp, Facebook,
  Twitter, Instagram, Youtube, Linkedin
} from "lucide-react";

// ─── NAVBAR ────────────────────────────────────────────────
function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-100">
      <div className="px-4 flex items-center justify-between h-14">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="relative w-10 h-10">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-orange-500 via-pink-500 to-blue-500" />
            <div className="absolute inset-[3px] rounded-full bg-white" />
            <div className="absolute inset-[7px] rounded-full bg-gradient-to-br from-orange-400 to-blue-500" />
          </div>
          <div>
            <div className="font-extrabold text-sm leading-none tracking-widest text-gray-900">CRAFTCREDIT</div>
            <div className="text-[9px] tracking-[0.18em] text-gray-500 font-medium mt-0.5">FINANCE BANK</div>
          </div>
        </div>

        {/* Right: dots + hamburger */}
        <div className="flex items-center gap-4">
          {/* Three dots */}
          <button className="flex items-center gap-[3px] p-1">
            <span className="w-1 h-1 rounded-full bg-gray-400 block" />
            <span className="w-1 h-1 rounded-full bg-gray-400 block" />
            <span className="w-1 h-1 rounded-full bg-gray-400 block" />
          </button>
          {/* Hamburger */}
          <button onClick={() => setOpen(!open)} className="p-1">
            {open ? <X className="w-7 h-7 text-gray-800" /> : <Menu className="w-7 h-7 text-gray-800" />}
          </button>
        </div>
      </div>

      {/* Slide-down menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white overflow-hidden shadow-lg"
          >
            {["Home", "About Us", "Money Transfer", "Services", "Contact Us"].map(l => (
              <a
                key={l}
                href={`#${l.toLowerCase().replace(/ /g, "")}`}
                onClick={() => setOpen(false)}
                className="block px-6 py-4 text-gray-800 font-medium border-b border-gray-100 text-base"
              >
                {l}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

// ─── HERO ───────────────────────────────────────────────────
function HeroSection() {
  return (
    <section id="home" className="pt-14 bg-white">
      {/* Text content */}
      <div className="px-5 pt-8 pb-6">
        <h1 className="text-[2rem] font-extrabold text-gray-900 leading-tight">
          Transfer Money Across The World In Real time
        </h1>
        <p className="mt-3 text-gray-500 text-[15px]">Simple. Quick. Secure Banking System</p>

        {/* CTA Buttons */}
        <div className="mt-5 flex gap-3">
          <Link to="/create-account" className="px-5 py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition-colors text-sm whitespace-nowrap">
            Get Started
          </Link>
          <Link to="/signin" className="px-5 py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition-colors text-sm whitespace-nowrap">
            Transfer Money Now
          </Link>
        </div>

        {/* Avatars + rating */}
        <div className="mt-6 flex items-center gap-3">
          <div className="flex -space-x-3">
            {[
              "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face",
              "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&h=60&fit=crop&crop=face",
              "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=60&h=60&fit=crop&crop=face",
              "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=60&h=60&fit=crop&crop=face",
            ].map((src, i) => (
              <img key={i} src={src} alt="" className="w-10 h-10 rounded-full border-2 border-white object-cover" />
            ))}
          </div>
        </div>
        <div className="mt-2 flex items-center gap-1">
          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          <span className="font-bold text-gray-800 text-sm">4.5</span>
          <span className="text-gray-500 text-sm">(709.3 K Reviews)</span>
        </div>
      </div>

      {/* Hero image — full width, woman with gradient ring */}
      <div className="relative flex justify-center overflow-hidden" style={{ minHeight: 340 }}>
        {/* Large gradient circle behind */}
        <div
          className="absolute rounded-full"
          style={{
            width: 340,
            height: 340,
            bottom: -40,
            left: "50%",
            transform: "translateX(-50%)",
            background: "linear-gradient(135deg, #7c3aed 0%, #a855f7 30%, #3b82f6 60%, #06b6d4 100%)",
          }}
        />
        {/* Woman image on top */}
        <img
          src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=500&h=600&fit=crop&crop=face"
          alt="Happy customer"
          className="relative z-10 w-72 object-cover object-top"
          style={{ height: 360 }}
        />
      </div>
    </section>
  );
}

// ─── DARK INFO BAND ────────────────────────────────────────
function InfoBand() {
  return (
    <section className="bg-gray-900 py-10 px-4">
      <div className="max-w-6xl mx-auto">
        <p className="text-gray-300 text-base leading-relaxed">
          Your{" "}
          <a href="#" className="text-blue-400 hover:underline font-medium">
            Craft Credit Finance Bank
          </a>{" "}
          account is your key to unlocking a universe of opportunities. Whether making international payments, receiving funds, managing your digital business, or accessing capital, Craft Credit Finance Bank opens your business up to the world.{" "}
          <a href="#" className="text-blue-400 hover:underline font-medium">
            Learn More
          </a>
        </p>
      </div>
    </section>
  );
}

// ─── WHY CHOOSE US ─────────────────────────────────────────
function WhyChooseUs() {
  const items = [
    {
      title: "We're Fast",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=500&h=400&fit=crop",
    },
    {
      title: "We're Safe",
      image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=500&h=400&fit=crop",
    },
    {
      title: "We're Trustworthy",
      image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=500&h=400&fit=crop",
    },
    {
      title: "We're Low Cost",
      image: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=500&h=400&fit=crop",
    },
  ];

  return (
    <section id="services" className="py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <p className="text-blue-600 font-semibold text-sm mb-2">Why Choose Craft Credit Finance Bank</p>
        <h2 className="text-3xl font-extrabold text-gray-900 mb-3">A New Era Of Online Banking</h2>
        <p className="text-gray-500 mb-10 max-w-xl">
          Our digital banking services are transparent and quick, and we're building a reliable network.
        </p>

        <div className="space-y-10">
          {items.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-64 md:h-80 object-cover rounded-xl"
              />
              <h3 className="mt-4 text-xl font-bold text-gray-900">{item.title}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── MOBILE APP ────────────────────────────────────────────
function MobileApp() {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <p className="text-blue-600 font-semibold text-sm mb-2">Unified Platform</p>
        <h2 className="text-3xl font-extrabold text-gray-900 mb-3">Powerful Mobile & Online App</h2>
        <p className="text-gray-500 mb-8">Our service is quick and easy to use, and you can download our app from any app store.</p>
        <img
          src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=700&h=420&fit=crop"
          alt="Mobile app"
          className="w-full rounded-2xl object-cover h-64 md:h-96"
        />
      </div>
    </section>
  );
}

// ─── PAY FOR BUSINESS ──────────────────────────────────────
function PayForBusiness() {
  return (
    <section className="py-10 bg-white">
      <div className="px-5">
        <h2 className="text-2xl font-extrabold text-gray-900 mb-2">Pay For Business</h2>
        <p className="text-gray-500 text-sm mb-5">
          With our trusted and reliable banking firm you can pay for your business activities anywhere around the world.
        </p>
        {/* Dark card with globe illustration */}
        <div className="w-full rounded-2xl overflow-hidden bg-gray-900 relative" style={{ minHeight: 200 }}>
          <div className="absolute inset-0 flex items-center justify-center opacity-30">
            <div className="w-48 h-48 rounded-full border-4 border-blue-400" />
          </div>
          <div className="relative z-10 p-6 flex flex-col gap-3">
            {/* Fake stat bars */}
            <div className="flex items-end gap-2 mt-4">
              {[40, 65, 50, 80, 55, 90, 70].map((h, i) => (
                <div key={i} className="flex-1 rounded-sm bg-blue-500 opacity-80" style={{ height: h }} />
              ))}
            </div>
            <div className="flex gap-4 mt-2">
              <div className="bg-blue-600 rounded px-3 py-1 text-white text-xs font-semibold">$ 0.00 USD</div>
              <div className="bg-gray-700 rounded px-3 py-1 text-gray-300 text-xs">$ GENESIS</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── HOW WE SUPPORT YOU ────────────────────────────────────
const services = [
  {
    title: "Send Money",
    description: "With our digital platform, you may send money to relatives and friends all across the world.",
    illustration: "https://images.unsplash.com/photo-1567427017947-545c5f8d16ad?w=400&h=300&fit=crop",
    color: "from-orange-50 to-yellow-50",
  },
  {
    title: "Currency Chart",
    description: "You can always watch the market's movement and make trading decisions with our currency charts.",
    illustration: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=300&fit=crop",
    color: "from-blue-50 to-indigo-50",
  },
  {
    title: "Rate Alert",
    description: "To enable our clients to convert, we at Craft Credit Finance Bank provide the finest currency rates in the market.",
    illustration: "https://images.unsplash.com/photo-1579621970795-87facc2f976d?w=400&h=300&fit=crop",
    color: "from-purple-50 to-pink-50",
  },
  {
    title: "Create Account",
    description: "Create a free digital bank account with us today to send money around the world.",
    illustration: "https://images.unsplash.com/photo-1434626881859-194d67b2b86f?w=400&h=300&fit=crop",
    color: "from-green-50 to-teal-50",
  },
];

function HowWeSupport() {
  return (
    <section className="py-10 bg-white">
      <div className="px-5">
        <p className="text-blue-600 font-semibold text-sm mb-1">Key Features</p>
        <h2 className="text-2xl font-extrabold text-gray-900 mb-2">How We Support You</h2>
        <p className="text-gray-500 text-sm mb-8">
          Transfer money to your friends & family anywhere, anytime without delay.
        </p>

        <div className="space-y-10">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              {/* Illustration image */}
              <div className={`w-full rounded-2xl overflow-hidden bg-gradient-to-br ${s.color} mb-4`}>
                <img
                  src={s.illustration}
                  alt={s.title}
                  className="w-full h-52 object-cover mix-blend-multiply"
                />
              </div>
              <h3 className="text-lg font-bold text-gray-900">{s.title}</h3>
              <p className="mt-1 text-gray-500 text-sm leading-relaxed">{s.description}</p>
              <a href="#" className="mt-2 inline-block text-blue-600 font-semibold text-sm hover:underline">
                View Details
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── FOOTER ────────────────────────────────────────────────
function Footer() {
  return (
    <footer id="contact" className="bg-gray-900 text-white pt-10 pb-6">
      <div className="px-5">
        {/* Logo */}
        <div className="flex items-center gap-2 mb-3">
          <div className="relative w-10 h-10">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-orange-500 via-pink-500 to-blue-500" />
            <div className="absolute inset-[3px] rounded-full bg-gray-900" />
            <div className="absolute inset-[7px] rounded-full bg-gradient-to-br from-orange-400 to-blue-500" />
          </div>
          <div>
            <div className="font-extrabold text-sm leading-none tracking-widest text-white">CRAFTCREDIT</div>
            <div className="text-[9px] tracking-[0.18em] text-gray-400 font-medium mt-0.5">FINANCE BANK</div>
          </div>
        </div>

        <p className="text-gray-400 text-sm leading-relaxed mb-5">
          Craft Credit Finance Bank transformed the digital banking industry using data and technology more than ten years ago.
        </p>

        {/* Follow Us */}
        <p className="text-white text-sm font-semibold mb-3">Follow Us :</p>
        <div className="flex gap-3 mb-8">
          {[Facebook, Twitter, Instagram, Youtube, Linkedin].map((Icon, i) => (
            <a key={i} href="#" className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center hover:bg-blue-600 transition-colors">
              <Icon className="w-4 h-4 text-white" />
            </a>
          ))}
        </div>

        {/* Quick Link */}
        <div className="mb-6">
          <h4 className="font-bold text-white text-sm mb-3">Quick Link</h4>
          <ul className="space-y-2">
            {["About Us", "Services", "Set FAQ", "Money Transfer"].map(l => (
              <li key={l}><a href="#" className="text-gray-400 text-sm hover:text-white transition-colors">{l}</a></li>
            ))}
          </ul>
        </div>

        {/* Help Center */}
        <div className="mb-6">
          <h4 className="font-bold text-white text-sm mb-3">Help Center</h4>
          <ul className="space-y-2">
            {["Contact Us", "Set FAQ", "Privacy Policy", "Terms & Conditions"].map(l => (
              <li key={l}><a href="#" className="text-gray-400 text-sm hover:text-white transition-colors">{l}</a></li>
            ))}
          </ul>
        </div>

        {/* Contact Info */}
        <div className="mb-8">
          <h4 className="font-bold text-white text-sm mb-3">Contact Info</h4>
          <div className="space-y-2">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 mt-0.5 text-gray-400 flex-shrink-0" />
              <span className="text-gray-400 text-sm">Address: New York, NY USA</span>
            </div>
            <div className="flex items-start gap-2">
              <Mail className="w-4 h-4 mt-0.5 text-gray-400 flex-shrink-0" />
              <span className="text-gray-400 text-sm">Mail Us: support@craftcreditfn.com</span>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-5 text-center text-gray-500 text-xs">
          © {new Date().getFullYear()} All rights reserved | Craft Credit Finance Bank
        </div>
      </div>
    </footer>
  );
}

// ─── SCROLL TO TOP ─────────────────────────────────────────
function ScrollToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const fn = () => setShow(window.scrollY > 300);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-50 w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-blue-700"
        >
          <ChevronUp className="w-5 h-5" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}

// ─── PAGE ──────────────────────────────────────────────────
export default function Home() {
  return (
    <div className="bg-white">
      <Navbar />
      <HeroSection />
      <InfoBand />
      <WhyChooseUs />
      <MobileApp />
      <PayForBusiness />
      <HowWeSupport />
      <Footer />
      <ScrollToTop />
    </div>
  );
}