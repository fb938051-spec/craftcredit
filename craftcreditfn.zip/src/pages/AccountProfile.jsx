import React from "react";
import DashboardLayout from "../components/dashboard/DashboardLayout";
import { Coffee, Calendar, MapPin, Phone, Pencil } from "lucide-react";

export default function AccountProfile() {
  return (
    <DashboardLayout>
      <div className="p-4 pb-16">
        <div className="bg-white rounded-xl shadow-sm p-5">
          <div className="flex justify-between items-start mb-5">
            <h1 className="font-bold text-gray-900 text-lg">Thomas Profile</h1>
            <button className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center">
              <Pencil className="w-4 h-4 text-white" />
            </button>
          </div>

          <div className="flex flex-col items-center mb-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl border-4 border-purple-200 overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
                  alt="profile"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <p className="mt-3 text-blue-600 font-semibold text-lg">Thomas James</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-3 text-gray-500 text-sm">
              <Coffee className="w-5 h-5 text-gray-300" />
              <span>Current</span>
            </div>
            <div className="flex items-center gap-3 text-gray-500 text-sm">
              <Calendar className="w-5 h-5 text-gray-300" />
              <span>2006-07-13</span>
            </div>
            <div className="flex items-center gap-3 text-gray-500 text-sm">
              <MapPin className="w-5 h-5 text-gray-300" />
              <span>Bsbzb, Midway Islands</span>
            </div>
            <div className="flex items-center gap-3 text-gray-500 text-sm">
              <Phone className="w-5 h-5 text-gray-300" />
              <span>63663663</span>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}