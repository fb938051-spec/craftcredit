import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Search, Loader2, ArrowUpRight, ArrowDownLeft, Clock, CheckCircle, XCircle, RotateCcw, Printer } from "lucide-react";

const TYPE_CONFIG = {
  "/dashboard/transactions/credit": {
    title: "Credit / Debit Transactions",
    types: ["credit", "debit", "deposit"],
  },
  "/dashboard/transactions/wire": {
    title: "Wire Transactions",
    types: ["wire_transfer"],
  },
  "/dashboard/transactions/domestic": {
    title: "Domestic Transactions",
    types: ["domestic_transfer"],
  },
  "/dashboard/transactions/loan": {
    title: "Loan Transactions",
    types: ["loan_disbursement"],
  },
};

const STATUS_BADGE = {
  processing: { icon: Clock, cls: "bg-amber-100 text-amber-700", label: "Processing" },
  completed:  { icon: CheckCircle, cls: "bg-green-100 text-green-700", label: "Completed" },
  declined:   { icon: XCircle, cls: "bg-red-100 text-red-700", label: "Declined" },
  reversed:   { icon: RotateCcw, cls: "bg-purple-100 text-purple-700", label: "Reversed" },
};

const TYPE_LABEL = {
  credit: "Credit",
  debit: "Debit",
  deposit: "Deposit",
  wire_transfer: "Wire Transfer",
  domestic_transfer: "Domestic Transfer",
  loan_disbursement: "Loan Disbursement",
};

function printReceipt(tx) {
  const date = tx.created_date ? new Date(tx.created_date).toLocaleString() : "—";
  const isOut = tx.type === "debit" || tx.type === "wire_transfer" || tx.type === "domestic_transfer";
  const eftLabel = tx.eftType === "immediate" ? " (Immediate EFT)" : tx.eftType === "normal" ? " (Normal EFT)" : "";

  const printContent = `
    <html>
    <head>
      <title>Transaction Receipt - ${tx.reference || tx.id}</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 30px; color: #111; max-width: 400px; margin: 0 auto; }
        h1 { text-align: center; color: #1d4ed8; font-size: 18px; margin-bottom: 4px; }
        .bank { text-align: center; color: #555; font-size: 12px; margin-bottom: 20px; }
        .amount { text-align: center; font-size: 28px; font-weight: bold; margin: 16px 0 4px; color: ${isOut ? "#ef4444" : "#16a34a"}; }
        .status { text-align: center; margin-bottom: 20px; }
        .badge { display: inline-block; padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; background: #dcfce7; color: #166534; }
        .divider { border-top: 1px solid #e5e7eb; margin: 14px 0; }
        .row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 13px; }
        .label { color: #9ca3af; }
        .value { font-weight: 600; text-align: right; max-width: 60%; }
        .footer { text-align: center; font-size: 11px; color: #9ca3af; margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 14px; }
      </style>
    </head>
    <body>
      <h1>CraftCredit Finance Bank</h1>
      <div class="bank">Official Transaction Receipt</div>
      <div class="divider"></div>
      <div class="amount">${isOut ? "-" : "+"}$${Number(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
      <div class="status"><span class="badge">✓ Completed</span></div>
      <div class="divider"></div>
      <div class="row"><span class="label">Reference</span><span class="value">${tx.reference || "—"}</span></div>
      <div class="row"><span class="label">Type</span><span class="value">${TYPE_LABEL[tx.type] || tx.type}${eftLabel}</span></div>
      ${tx.beneficiaryName ? `<div class="row"><span class="label">Recipient</span><span class="value">${tx.beneficiaryName}</span></div>` : ""}
      ${tx.beneficiaryBank ? `<div class="row"><span class="label">Bank</span><span class="value">${tx.beneficiaryBank}</span></div>` : ""}
      ${tx.beneficiaryAccount ? `<div class="row"><span class="label">Account</span><span class="value">${tx.beneficiaryAccount}</span></div>` : ""}
      ${tx.fee ? `<div class="row"><span class="label">Fee</span><span class="value">$${Number(tx.fee).toFixed(2)}</span></div>` : ""}
      ${tx.narration || tx.description ? `<div class="row"><span class="label">Narration</span><span class="value">${tx.narration || tx.description}</span></div>` : ""}
      <div class="row"><span class="label">Date & Time</span><span class="value">${date}</span></div>
      <div class="footer">
        This is an official receipt from CraftCredit Finance Bank.<br/>
        Printed on ${new Date().toLocaleString()}
      </div>
    </body>
    </html>
  `;
  const win = window.open("", "_blank", "width=500,height=700");
  win.document.write(printContent);
  win.document.close();
  win.focus();
  win.print();
}

export default function Transactions() {
  const location = useLocation();
  const config = TYPE_CONFIG[location.pathname] || TYPE_CONFIG["/dashboard/transactions/credit"];
  const [txs, setTxs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [results, setResults] = useState(10);

  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");

  useEffect(() => {
    setLoading(true);
    base44.entities.Transaction.filter({ accountNumber: bankUser.accountNumber }, "-created_date", 200).then(data => {
      setTxs(data);
      setLoading(false);
    });
  }, [location.pathname]);

  const filtered = txs
    .filter(t => config.types.includes(t.type))
    .filter(t => {
      if (!search) return true;
      const q = search.toLowerCase();
      return (
        (t.reference || "").toLowerCase().includes(q) ||
        (t.beneficiaryName || "").toLowerCase().includes(q) ||
        (t.description || "").toLowerCase().includes(q)
      );
    })
    .slice(0, results);

  const all = txs.filter(t => config.types.includes(t.type));

  return (
    <div className="p-4 bg-white min-h-screen">
      <h1 className="text-xl font-semibold text-gray-900 text-center mb-5">{config.title}</h1>

      <div className="flex items-center justify-between mb-3 gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">Show:</span>
          <select value={results} onChange={e => setResults(Number(e.target.value))}
            className="border border-gray-200 rounded text-xs px-2 py-1">
            <option value={7}>7</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
        </div>
        <div className="flex items-center border border-gray-200 rounded px-3 py-2 gap-2 flex-1 max-w-xs">
          <Search className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
          <input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)}
            className="flex-1 text-xs outline-none text-gray-600" />
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-10 text-gray-400 text-sm">No transactions found</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-teal-50">
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">S/N</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Amount</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Type</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Reference</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Recipient</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Description</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Status</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Date</th>
                <th className="text-left p-2.5 text-gray-600 font-semibold whitespace-nowrap">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map((tx, i) => {
                const isOut = tx.type === "debit" || tx.type === "wire_transfer" || tx.type === "domestic_transfer";
                const status = tx.status || "completed";
                const SBadge = STATUS_BADGE[status] || STATUS_BADGE.completed;
                const SIcon = SBadge.icon;
                const eftLabel = tx.eftType === "immediate" ? " ⚡" : "";
                return (
                  <tr key={tx.id} className={`hover:bg-gray-50 ${status === "processing" ? "animate-pulse" : ""}`}>
                    <td className="p-2.5 text-gray-500">{i + 1}</td>
                    <td className="p-2.5 font-bold whitespace-nowrap">
                      <span className={isOut ? "text-red-500" : "text-green-600"}>
                        {isOut ? "-" : "+"}${Number(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                      </span>
                    </td>
                    <td className="p-2.5 whitespace-nowrap">
                      <span className="flex items-center gap-1">
                        {isOut ? <ArrowUpRight className="w-3 h-3 text-red-400" /> : <ArrowDownLeft className="w-3 h-3 text-green-500" />}
                        {TYPE_LABEL[tx.type] || tx.type}{eftLabel}
                      </span>
                    </td>
                    <td className="p-2.5 font-mono text-gray-500 whitespace-nowrap">{tx.reference || "—"}</td>
                    <td className="p-2.5 text-gray-700">{tx.beneficiaryName || "—"}</td>
                    <td className="p-2.5 text-gray-500 max-w-[140px] truncate">{tx.narration || tx.description || "—"}</td>
                    <td className="p-2.5 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-semibold ${SBadge.cls}`}>
                        <SIcon className="w-3 h-3" />
                        {SBadge.label}
                      </span>
                    </td>
                    <td className="p-2.5 text-gray-400 whitespace-nowrap">
                      {tx.created_date ? new Date(tx.created_date).toLocaleDateString() : "—"}
                    </td>
                    <td className="p-2.5">
                      {status === "completed" ? (
                        <button
                          onClick={() => printReceipt(tx)}
                          className="flex items-center gap-1 px-2 py-1 bg-blue-50 text-blue-600 rounded text-xs font-semibold hover:bg-blue-100 transition-colors whitespace-nowrap"
                        >
                          <Printer className="w-3 h-3" /> Print
                        </button>
                      ) : (
                        <span className="text-gray-300 text-xs">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <p className="text-xs text-gray-400 text-center mt-3">
        Showing {filtered.length} of {all.length} entries
      </p>
    </div>
  );
}