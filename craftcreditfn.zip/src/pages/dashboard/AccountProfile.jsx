import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Pencil, Coffee, Calendar, MapPin, Phone, ShieldCheck, Snowflake, ShieldAlert, Ban, Shield } from "lucide-react";

const STATUS_CONFIG = {
  active:     { label: "Active",      icon: ShieldCheck,  bg: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200", dot: "bg-emerald-500" },
  frozen:     { label: "Frozen",      icon: Snowflake,    bg: "bg-blue-50",    text: "text-blue-700",    border: "border-blue-200",    dot: "bg-blue-500" },
  restricted: { label: "Restricted",  icon: ShieldAlert,  bg: "bg-amber-50",   text: "text-amber-700",   border: "border-amber-200",   dot: "bg-amber-500" },
  suspended:  { label: "Suspended",   icon: Ban,          bg: "bg-red-50",     text: "text-red-700",     border: "border-red-200",     dot: "bg-red-500" },
  closed:     { label: "Closed",      icon: Shield,       bg: "bg-gray-100",   text: "text-gray-600",    border: "border-gray-300",    dot: "bg-gray-400" },
};

export default function AccountProfile() {
  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");
  const [account, setAccount] = useState(null);

  useEffect(() => {
    if (bankUser.accountNumber) {
      base44.entities.BankAccount.filter({ accountNumber: bankUser.accountNumber }).then(res => {
        if (res.length > 0) setAccount(res[0]);
      });
    }
  }, []);

  const status = account?.status || "active";
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.active;
  const StatusIcon = cfg.icon;

  return (
    <div className="p-4 bg-gray-50 min-h-screen">
      <div className="bg-white rounded-2xl shadow-sm p-5">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-lg font-bold text-gray-900 border-b-2 border-blue-600 pb-1">My Profile</h1>
          <button className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
            <Pencil className="w-4 h-4 text-white" />
          </button>
        </div>

        <div className="flex flex-col items-center mb-6">
          <div className="w-20 h-20 rounded-2xl overflow-hidden border-4 border-purple-300 shadow-md mb-3">
            {bankUser.profileImage ? (
              <img src={bankUser.profileImage} alt="" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-blue-100 flex items-center justify-center">
                <span className="text-blue-600 font-bold text-3xl">{(bankUser.name || "U")[0]}</span>
              </div>
            )}
          </div>
          <h2 className="text-blue-600 font-bold text-lg">{bankUser.name || "Account Holder"}</h2>

          {/* Account Status Badge */}
          <div className={`mt-3 flex items-center gap-2 px-4 py-2 rounded-full border ${cfg.bg} ${cfg.border}`}>
            <span className={`w-2 h-2 rounded-full ${cfg.dot} ${status === "active" ? "animate-pulse" : ""}`} />
            <StatusIcon className={`w-3.5 h-3.5 ${cfg.text}`} />
            <span className={`text-xs font-bold uppercase tracking-wide ${cfg.text}`}>{cfg.label}</span>
          </div>

          {/* Warning message if any */}
          {account?.warningMessage && (
            <div className="mt-3 w-full bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-start gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
              <p className="text-amber-700 text-xs leading-relaxed">{account.warningMessage}</p>
            </div>
          )}

          {/* Restriction notice */}
          {(account?.transferRestricted || account?.withdrawalRestricted) && (
            <div className="mt-2 w-full bg-red-50 border border-red-200 rounded-xl px-4 py-3">
              <p className="text-red-700 text-xs font-semibold mb-1">Account Restrictions:</p>
              <ul className="text-red-600 text-xs space-y-0.5">
                {account.transferRestricted && <li>• Outgoing transfers are currently blocked</li>}
                {account.withdrawalRestricted && <li>• Withdrawals are currently blocked</li>}
              </ul>
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <Coffee className="w-4 h-4 text-gray-400" />
            <span>{account?.accountType || bankUser.accountType || "Current"}</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span>{bankUser.dob || "—"}</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <MapPin className="w-4 h-4 text-gray-400" />
            <span>{account?.country || bankUser.country || "—"}</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <Phone className="w-4 h-4 text-gray-400" />
            <span>{account?.phone || bankUser.phone || "—"}</span>
          </div>
        </div>
      </div>
    </div>
  );
}