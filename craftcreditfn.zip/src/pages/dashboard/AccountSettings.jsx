import React, { useState, useRef } from "react";

export default function AccountSettings() {
  const [profileImg, setProfileImg] = useState(null);
  const [passwords, setPasswords] = useState({ old: "", new: "", confirm: "" });
  const [pins, setPins] = useState({ current: "", new: "", confirm: "" });
  const fileRef = useRef();

  return (
    <div className="p-4 bg-gray-50 min-h-screen space-y-5">

      {/* General Information */}
      <div className="bg-white rounded-xl shadow-sm p-5">
        <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wide mb-4">GENERAL INFORMATION</h2>

        <div className="flex flex-col items-center mb-5">
          <div className="w-16 h-16 rounded-full overflow-hidden border-4 border-purple-200 mb-2">
            <img
              src={profileImg ? URL.createObjectURL(profileImg) : "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face"}
              alt="" className="w-full h-full object-cover"
            />
          </div>
          <div className="text-xs text-gray-500 mb-1">1776027685...</div>
          <button type="button" onClick={() => fileRef.current.click()} className="text-xs text-blue-600 hover:underline mb-1">Upload or Drag...</button>
          <button type="button" onClick={() => fileRef.current.click()} className="text-xs text-blue-600 hover:underline">Upload Picture</button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => setProfileImg(e.target.files[0])} />
          <button className="mt-2 bg-blue-600 text-white text-xs px-4 py-1.5 rounded hover:bg-blue-700">Save</button>
        </div>

        {[
          { label: "Account No", value: "4027564938" },
          { label: "Account Type", value: "Current" },
          { label: "Email", value: "A5661663" },
          { label: "Gender", value: "Male" },
          { label: "Martial Status", value: "None" },
        ].map(({ label, value }) => (
          <div key={label} className="mb-3">
            <label className="block text-xs text-gray-500 mb-1">{label}</label>
            <input readOnly value={value} className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2.5 text-sm text-gray-600 outline-none" />
          </div>
        ))}
      </div>

      {/* Contact Information */}
      <div className="bg-white rounded-xl shadow-sm p-5">
        <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wide mb-4">CONTACT INFORMATION</h2>
        <div className="mb-3">
          <label className="block text-xs text-gray-500 mb-1">Current Address</label>
          <input readOnly value="Mrazfz (2ezo Nam Razeh Stra..." className="w-full bg-gray-100 border border-gray-200 rounded px-3 py-2.5 text-sm text-gray-600 outline-none" />
        </div>
      </div>

      {/* Change Password */}
      <div className="bg-white rounded-xl shadow-sm p-5">
        <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wide mb-4">CHANGE PASSWORD</h2>
        {[
          { label: "Old Password", key: "old" },
          { label: "New Password", key: "new" },
          { label: "Confirm Password", key: "confirm" },
        ].map(({ label, key }) => (
          <div key={key} className="mb-3">
            <label className="block text-xs text-gray-500 mb-1">{label}</label>
            <input type="password" placeholder={label} value={passwords[key]}
              onChange={e => setPasswords(p => ({ ...p, [key]: e.target.value }))}
              className="w-full border border-gray-200 rounded px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-400" />
          </div>
        ))}
        <button className="bg-blue-600 text-white px-6 py-2 rounded text-sm font-semibold hover:bg-blue-700">Change Password</button>
      </div>

      {/* Change PIN */}
      <div className="bg-white rounded-xl shadow-sm p-5">
        <h2 className="text-sm font-bold text-gray-900 uppercase tracking-wide mb-4">CHANGE PIN</h2>
        {[
          { label: "Current Pin", key: "current" },
          { label: "New Pin", key: "new" },
          { label: "Confirm Pin", key: "confirm" },
        ].map(({ label, key }) => (
          <div key={key} className="mb-3">
            <label className="block text-xs text-gray-500 mb-1">{label}</label>
            <input type="password" placeholder={label} value={pins[key]}
              onChange={e => setPins(p => ({ ...p, [key]: e.target.value }))}
              className="w-full border border-gray-200 rounded px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-400" />
          </div>
        ))}
        <button className="bg-blue-600 text-white px-6 py-2 rounded text-sm font-semibold hover:bg-blue-700">Change Pin</button>
      </div>
    </div>
  );
}