import React, { useState } from "react";
import { DollarSign, ArrowRight, CheckCircle, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function LoanMortgages() {
  const [form, setForm] = useState({ amount: "", narration: "" });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.amount || !form.narration) return;
    setLoading(true);

    await base44.entities.LoanApplication.create({
      accountNumber: bankUser.accountNumber || "",
      fullName: bankUser.name || "Unknown",
      email: bankUser.email || "",
      amount: parseFloat(form.amount),
      purpose: form.narration,
      status: "pending",
    });

    setLoading(false);
    setSuccess(true);
    setForm({ amount: "", narration: "" });
  };

  if (success) {
    return (
      <div className="p-6 bg-white min-h-screen flex flex-col items-center justify-center text-center">
        <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
          <CheckCircle className="w-8 h-8 text-green-500" />
        </div>
        <h2 className="text-xl font-bold text-gray-800 mb-2">Application Submitted!</h2>
        <p className="text-gray-500 text-sm max-w-xs mb-6">Your loan application has been submitted successfully. Our team will review it and get back to you shortly.</p>
        <button
          onClick={() => setSuccess(false)}
          className="px-6 py-2.5 bg-blue-600 text-white rounded font-semibold text-sm hover:bg-blue-700"
        >
          Submit Another
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 bg-white min-h-screen">
      <h1 className="text-xl font-semibold text-gray-900 text-center mb-6">Loan / Mortgage Application</h1>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-sm text-gray-600 mb-1">Amount</label>
          <div className="flex items-center border border-gray-200 rounded overflow-hidden">
            <div className="px-3 py-3 bg-gray-50 border-r border-gray-200">
              <DollarSign className="w-4 h-4 text-blue-500" />
            </div>
            <input
              type="number"
              placeholder="Amount"
              value={form.amount}
              onChange={e => update("amount", e.target.value)}
              required
              className="flex-1 px-3 py-3 text-sm outline-none text-gray-700 placeholder-gray-400"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm text-gray-600 mb-1">Receiver (Customer Care)</label>
          <input type="text" value="Customer Service" readOnly
            className="w-full bg-gray-100 border border-gray-200 rounded px-4 py-3 text-sm text-gray-500 outline-none" />
        </div>

        <div>
          <label className="block text-sm text-gray-600 mb-1">Narration / Purpose</label>
          <textarea
            placeholder="Loan Description"
            value={form.narration}
            onChange={e => update("narration", e.target.value)}
            required
            rows={5}
            className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400 resize-none"
          />
        </div>

        <div className="flex justify-center pt-2">
          <button
            type="submit"
            disabled={loading}
            className="flex items-center gap-2 bg-blue-600 text-white px-8 py-3 rounded font-semibold hover:bg-blue-700 disabled:opacity-70"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
            {loading ? "Submitting..." : "Submit Application"}
          </button>
        </div>
      </form>
    </div>
  );
}