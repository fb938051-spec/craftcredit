import React, { useState } from "react";
import { CreditCard } from "lucide-react";

const CARD_BRANDS = [
  { name: "Visa", color: "from-blue-500 to-blue-800", textColor: "text-blue-200", logo: "VISA" },
  { name: "Mastercard", color: "from-red-500 to-yellow-500", textColor: "text-yellow-100", logo: "MC" },
  { name: "Discover", color: "from-purple-500 to-purple-700", textColor: "text-purple-200", logo: "DISCOVER" },
  { name: "Amex", color: "from-green-500 to-teal-700", textColor: "text-green-100", logo: "AMEX" },
];

function randomCardNum() {
  const prefix = "6011";
  const rest = Array.from({length: 12}, () => Math.floor(Math.random()*10)).join("");
  const num = prefix + rest;
  return `${num.slice(0,4)} ${num.slice(4,8)} ${num.slice(8,12)} ${num.slice(12,16)}`;
}

function generateExp() {
  const now = new Date();
  return `${String(now.getMonth()+1).padStart(2,"0")}/${String(now.getFullYear()+1).slice(-2)}`;
}

function generateCvv() {
  return String(Math.floor(100+Math.random()*900));
}

export default function VirtualCard() {
  const [cardNum, setCardNum] = useState("");
  const [exp] = useState(generateExp());
  const [cvv] = useState(generateCvv());
  const [submitted, setSubmitted] = useState(false);
  const [brand, setBrand] = useState(CARD_BRANDS[2]);
  const [brandIdx, setBrandIdx] = useState(2);
  const name = "THOMAS JAMES";

  const handleGenerate = () => {
    const idx = (brandIdx + 1) % CARD_BRANDS.length;
    setBrandIdx(idx);
    setBrand(CARD_BRANDS[idx]);
    setCardNum(randomCardNum());
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!cardNum) return alert("Please generate a card first");
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="p-4 min-h-screen bg-white">
        <div className="text-center text-xs text-green-600 bg-green-100 py-2 px-4 mb-4 rounded">Credit Card Submit Successfully</div>

        {/* Debit card display */}
        <div className="bg-blue-900 rounded-2xl p-4 mb-6 relative overflow-hidden">
          <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 opacity-80">
            {["bg-blue-600","bg-purple-500","bg-red-500","bg-pink-500","bg-blue-700","bg-teal-500","bg-indigo-500","bg-purple-700","bg-blue-800"].map((c,i)=>(
              <div key={i} className={`${c}`}/>
            ))}
          </div>
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="text-white text-xs">cinnioncpf</div>
                <div className="text-white text-xs font-bold">Debit Card</div>
              </div>
              <div className="text-white text-xs font-bold">We understand your world</div>
            </div>
            <div className="text-white text-xs mb-4">🏷️</div>
            <div className="text-white font-mono font-bold text-lg tracking-widest mb-3">{cardNum}</div>
            <div className="flex justify-between items-end">
              <div>
                <div className="text-white/60 text-xs">NORTH YEAR</div>
                <div className="text-white font-bold text-sm">{name}</div>
              </div>
              <div className="text-right">
                <div className="text-white/60 text-xs">VALID UP TO</div>
                <div className="text-white font-bold text-lg">{exp} DISCOVER</div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center mb-4">
          <span className="bg-blue-600 text-white text-xs px-6 py-1.5 rounded">PROCESSING</span>
        </div>

        <div className="space-y-2 mb-6">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Card Limit</span>
            <span className="font-bold text-gray-900">$ 5,000</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Card Limit Remain</span>
            <span className="font-bold text-red-500">$ 5,000</span>
          </div>
        </div>

        <div className="flex justify-center">
          <button onClick={() => { setSubmitted(false); setCardNum(""); }} className="bg-blue-600 text-white px-8 py-2 rounded font-semibold hover:bg-blue-700">
            New Card
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 min-h-screen bg-white">
      <h1 className="text-xl font-semibold text-gray-900 text-center mb-6">Generate Credit Card</h1>

      {/* Card preview */}
      <div className={`bg-gradient-to-br ${brand.color} rounded-2xl p-5 mb-6 relative overflow-hidden`}>
        <div className="flex justify-between items-start mb-6">
          <div className="w-10 h-8 border-2 border-white/50 rounded flex items-center justify-center">
            <div className="w-6 h-4 border border-white/50 rounded-sm" />
          </div>
          {cardNum && <span className="text-white font-bold text-sm">{brand.logo}</span>}
        </div>
        <div>
          <div className="text-white/60 text-xs mb-0.5">card number</div>
          <div className="text-white font-mono font-bold text-base tracking-widest mb-4">
            {cardNum || "0123 4567 8910 1112"}
          </div>
        </div>
        <div className="flex justify-between items-end">
          <div>
            <div className="text-white/60 text-xs">cardholder name</div>
            <div className="text-white font-bold text-sm">{name}</div>
          </div>
          <div className="text-right">
            <div className="text-white/60 text-xs">expiration</div>
            <div className="text-white text-xs">VALID<br/>THRU ▶ {exp}</div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm text-gray-600 mb-1">Name</label>
          <input type="text" value={name} readOnly
            className="w-full bg-gray-100 border border-gray-200 rounded px-4 py-3 text-sm text-gray-600 outline-none" />
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-sm text-gray-600">Card Number</label>
            <button type="button" onClick={handleGenerate} className="bg-blue-600 text-white text-xs px-3 py-1 rounded hover:bg-blue-700">
              Generate Card
            </button>
          </div>
          <div className="flex items-center border border-gray-200 rounded overflow-hidden">
            <input type="text" readOnly value={cardNum} placeholder=""
              className="flex-1 bg-gray-50 px-4 py-3 text-sm text-gray-700 outline-none font-mono" />
            {cardNum && (
              <div className="px-3 py-2 bg-gray-50 border-l border-gray-200">
                <span className="text-xs font-bold text-orange-500">{brand.logo}</span>
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Expiration (mm/yy)</label>
            <input type="text" readOnly value={exp}
              className="w-full bg-gray-100 border border-gray-200 rounded px-4 py-3 text-sm text-gray-600 outline-none" />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">Security Code</label>
            <input type="text" readOnly value={cvv}
              className="w-full bg-gray-100 border border-gray-200 rounded px-4 py-3 text-sm text-gray-600 outline-none" />
          </div>
        </div>

        <div className="flex justify-center pt-2">
          <button type="submit" className="bg-blue-600 text-white px-8 py-3 rounded font-semibold hover:bg-blue-700">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
}