import React, { useState, useRef } from "react";
import { DollarSign, Copy, ArrowRight } from "lucide-react";

const CRYPTO_TYPES = ["Select","Bitcoin (BTC)","Ethereum (ETH)","USDT (TRC20)","USDT (ERC20)","Litecoin (LTC)","Dogecoin (DOGE)"];
const WALLET_ADDRESS = "TRX9xKq2mN8vPqLwzYcBf3hJsD7kEuR4Mn";

export default function OnlineDeposit() {
  const [form, setForm] = useState({ amount: "", cryptoType: "Select", captureFile: null });
  const fileRef = useRef();

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Deposit submitted!");
  };

  return (
    <div className="p-4 bg-white min-h-screen">
      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-sm text-gray-600 mb-1">Amount</label>
          <div className="flex items-center border border-gray-200 rounded overflow-hidden">
            <div className="px-3 py-3 bg-gray-50 border-r border-gray-200">
              <DollarSign className="w-4 h-4 text-blue-500" />
            </div>
            <input type="number" placeholder="Amount" value={form.amount} onChange={e => update("amount", e.target.value)}
              className="flex-1 px-3 py-3 text-sm outline-none text-gray-700 placeholder-gray-400" />
          </div>
        </div>

        <div>
          <label className="block text-sm text-gray-600 mb-1">Crypto Type</label>
          <select value={form.cryptoType} onChange={e => update("cryptoType", e.target.value)}
            className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400 text-gray-600">
            {CRYPTO_TYPES.map(t => <option key={t}>{t}</option>)}
          </select>
        </div>

        <div>
          <label className="block text-sm text-gray-600 mb-1">Wallet Address</label>
          <div className="flex items-center gap-2">
            <input readOnly value={WALLET_ADDRESS}
              className="flex-1 bg-gray-100 border border-gray-200 rounded px-3 py-3 text-sm text-gray-600 outline-none" />
            <button type="button" onClick={() => navigator.clipboard.writeText(WALLET_ADDRESS)}
              className="flex items-center gap-1 bg-blue-600 text-white text-xs px-3 py-3 rounded hover:bg-blue-700">
              <Copy className="w-3 h-3" /> Copy
            </button>
          </div>
        </div>

        {/* File upload */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm text-blue-600">Upload (Single File)</span>
            <span className="text-sm text-gray-400">✕</span>
          </div>
          <div className="flex items-center border border-gray-200 rounded overflow-hidden">
            <span className="px-4 py-3 text-sm text-gray-500 flex-1">{form.captureFile ? form.captureFile.name : "Choose file..."}</span>
            <button type="button" onClick={() => fileRef.current.click()}
              className="px-4 py-3 bg-gray-100 border-l border-gray-200 text-sm text-gray-700 hover:bg-gray-200">Browse</button>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => update("captureFile", e.target.files[0])} />
          </div>
        </div>

        {/* Image placeholder */}
        <div className="flex justify-center py-6">
          <div className="relative w-48 h-36">
            <div className="absolute right-0 top-0 w-40 h-28 bg-white border-2 border-gray-200 rounded-lg flex items-end justify-center pb-2 shadow">
              <div className="w-24 h-16 bg-blue-500 rounded" style={{clipPath:"polygon(0 100%,50% 30%,100% 100%)"}}>
                <div className="w-6 h-6 bg-blue-700 rounded-full mt-1 mx-auto" />
              </div>
              <div className="absolute top-1 right-1 w-4 h-4 bg-red-400 rounded-full" />
            </div>
            <div className="absolute left-0 bottom-0 w-40 h-28 bg-white border-2 border-gray-200 rounded-lg flex items-end justify-center pb-2 shadow opacity-80">
              <div className="w-24 h-16 bg-blue-500 rounded" style={{clipPath:"polygon(0 100%,50% 30%,100% 100%)"}}>
                <div className="w-6 h-6 bg-blue-700 rounded-full mt-1 mx-auto" />
              </div>
              <div className="absolute top-1 right-1 w-4 h-4 bg-red-400 rounded-full" />
            </div>
          </div>
        </div>

        <div className="flex justify-center pt-2">
          <button type="submit" className="flex items-center gap-2 bg-blue-600 text-white px-8 py-3 rounded font-semibold hover:bg-blue-700">
            <ArrowRight className="w-4 h-4" /> Deposit
          </button>
        </div>
      </form>
    </div>
  );
}