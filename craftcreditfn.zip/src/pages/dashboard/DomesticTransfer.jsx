import React, { useState, useEffect } from "react";
import { DollarSign, ArrowRight, Loader2, AlertCircle, Zap, Clock } from "lucide-react";
import { base44 } from "@/api/base44Client";
import TransferReceipt from "@/components/banking/TransferReceipt";

const ACCOUNT_TYPES = [
  "Select Account Type","Savings Account","Current Account","Checking Account",
  "Fixed Deposit","Non Resident Account","Online Banking","Domicilary Account","Joint Account"
];

const IMMEDIATE_FEE_PERCENT = 1.5; // 1.5% fee for immediate EFT

export default function DomesticTransfer() {
  const [form, setForm] = useState({
    amount: "", beneficiaryName: "", bankName: "", accountNumber: "",
    accountType: "Select Account Type", narration: "",
    eftType: "normal", // "normal" or "immediate"
    transferMode: "external", // "external" or "internal"
    internalAccountNumber: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [receipt, setReceipt] = useState(null);
  const [balance, setBalance] = useState(0);
  const [account, setAccount] = useState(null);
  const [internalAccount, setInternalAccount] = useState(null);
  const [lookingUp, setLookingUp] = useState(false);

  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");

  useEffect(() => {
    if (bankUser.accountNumber) {
      base44.entities.BankAccount.filter({ accountNumber: bankUser.accountNumber }).then(res => {
        if (res.length > 0) {
          setAccount(res[0]);
          setBalance(res[0].balance || 0);
        }
      });
    }
  }, []);

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  // Look up internal account as user types
  const handleInternalLookup = async (accNum) => {
    update("internalAccountNumber", accNum);
    setInternalAccount(null);
    if (accNum.length >= 8) {
      setLookingUp(true);
      const res = await base44.entities.BankAccount.filter({ accountNumber: accNum });
      if (res.length > 0 && res[0].accountNumber !== bankUser.accountNumber) {
        setInternalAccount(res[0]);
      } else {
        setInternalAccount(null);
      }
      setLookingUp(false);
    }
  };

  const amt = parseFloat(form.amount) || 0;
  const fee = form.eftType === "immediate" ? parseFloat((amt * IMMEDIATE_FEE_PERCENT / 100).toFixed(2)) : 0;
  const totalDeduction = amt + fee;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!amt || amt <= 0) { setError("Please enter a valid amount."); return; }

    if (form.transferMode === "internal") {
      if (!form.internalAccountNumber.trim()) { setError("Please enter the recipient's account number."); return; }
      if (!internalAccount) { setError("Recipient account not found in our system. Please verify the account number."); return; }
    } else {
      if (!form.beneficiaryName.trim()) { setError("Beneficiary name is required."); return; }
      if (!form.bankName.trim()) { setError("Bank name is required."); return; }
      if (!form.accountNumber.trim()) { setError("Beneficiary account number is required."); return; }
    }

    if (totalDeduction > balance) {
      setError(`Insufficient balance. You need $${totalDeduction.toLocaleString("en-US", { minimumFractionDigits: 2 })} (including ${fee > 0 ? `$${fee.toFixed(2)} fee` : "no fee"}) but your balance is $${balance.toLocaleString("en-US", { minimumFractionDigits: 2 })}.`);
      return;
    }

    if (account?.transferRestricted) {
      setError("Your account has outgoing transfer restrictions. Please contact support.");
      return;
    }

    setLoading(true);

    const isImmediate = form.eftType === "immediate";
    const isInternal = form.transferMode === "internal";
    const reference = `DOM-${Date.now()}`;
    const newSenderBalance = balance - totalDeduction;

    const beneficiaryName = isInternal ? internalAccount.fullName : form.beneficiaryName;
    const beneficiaryBank = isInternal ? "CraftCredit Finance Bank" : form.bankName;
    const beneficiaryAccount = isInternal ? form.internalAccountNumber : form.accountNumber;

    // Deduct sender balance immediately for Immediate EFT, or for internal transfers
    if (isImmediate || isInternal) {
      await base44.entities.BankAccount.update(account.id, { balance: newSenderBalance });
    }

    // For internal transfers, credit the recipient immediately
    if (isInternal) {
      const recipientNewBalance = (internalAccount.balance || 0) + amt;
      await base44.entities.BankAccount.update(internalAccount.id, { balance: recipientNewBalance });

      // Create credit transaction for recipient
      await base44.entities.Transaction.create({
        accountNumber: internalAccount.accountNumber,
        fullName: internalAccount.fullName,
        type: "credit",
        amount: amt,
        balanceBefore: internalAccount.balance || 0,
        balanceAfter: recipientNewBalance,
        description: `Received from ${bankUser.name} (${bankUser.accountNumber})`,
        reference,
        status: "completed",
        beneficiaryName: internalAccount.fullName,
        beneficiaryBank: "CraftCredit Finance Bank",
        beneficiaryAccount: internalAccount.accountNumber,
        narration: form.narration || `Transfer from ${bankUser.name}`,
        performedBy: bankUser.name,
      });
    }

    const tx = await base44.entities.Transaction.create({
      accountNumber: bankUser.accountNumber,
      fullName: bankUser.name,
      type: "domestic_transfer",
      amount: amt,
      fee: fee > 0 ? fee : undefined,
      eftType: form.eftType,
      balanceBefore: balance,
      balanceAfter: isImmediate || isInternal ? newSenderBalance : balance,
      description: `${isImmediate ? "Immediate" : "Normal"} EFT to ${beneficiaryName} at ${beneficiaryBank}`,
      reference,
      status: isImmediate || isInternal ? "completed" : "processing",
      beneficiaryName,
      beneficiaryBank,
      beneficiaryAccount,
      narration: form.narration,
      performedBy: bankUser.name,
    });

    setLoading(false);
    setReceipt({ ...tx, eftType: form.eftType, fee: fee > 0 ? fee : undefined });
    setForm({
      amount: "", beneficiaryName: "", bankName: "", accountNumber: "",
      accountType: "Select Account Type", narration: "",
      eftType: "normal", transferMode: "external", internalAccountNumber: "",
    });
    setInternalAccount(null);
    // Refresh balance
    base44.entities.BankAccount.filter({ accountNumber: bankUser.accountNumber }).then(res => {
      if (res.length > 0) { setAccount(res[0]); setBalance(res[0].balance || 0); }
    });
  };

  return (
    <div className="p-4 bg-white min-h-screen">
      <h1 className="text-xl font-semibold text-gray-900 text-center mb-2">Domestic Transfer</h1>
      <p className="text-center text-xs text-gray-400 mb-5">
        Available Balance: <span className="font-bold text-blue-600">${balance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
      </p>

      {error && (
        <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg px-4 py-3 mb-4">
          <AlertCircle className="w-4 h-4 flex-shrink-0" /> {error}
        </div>
      )}

      {/* Transfer Mode */}
      <div className="mb-5">
        <label className="block text-sm text-gray-600 mb-2 font-semibold">Transfer To</label>
        <div className="grid grid-cols-2 gap-3">
          <button type="button"
            onClick={() => { update("transferMode", "external"); setInternalAccount(null); }}
            className={`py-3 px-4 rounded-xl border-2 text-sm font-semibold transition-all ${form.transferMode === "external" ? "border-blue-600 bg-blue-50 text-blue-700" : "border-gray-200 text-gray-500"}`}>
            Other Bank
          </button>
          <button type="button"
            onClick={() => update("transferMode", "internal")}
            className={`py-3 px-4 rounded-xl border-2 text-sm font-semibold transition-all flex items-center justify-center gap-2 ${form.transferMode === "internal" ? "border-green-600 bg-green-50 text-green-700" : "border-gray-200 text-gray-500"}`}>
            <span>CraftCredit User</span>
          </button>
        </div>
      </div>

      {/* EFT Type */}
      <div className="mb-5">
        <label className="block text-sm text-gray-600 mb-2 font-semibold">Transfer Speed</label>
        <div className="grid grid-cols-2 gap-3">
          <button type="button" onClick={() => update("eftType", "normal")}
            className={`py-3 px-3 rounded-xl border-2 text-sm font-semibold transition-all ${form.eftType === "normal" ? "border-blue-600 bg-blue-50 text-blue-700" : "border-gray-200 text-gray-500"}`}>
            <Clock className="w-4 h-4 mx-auto mb-1" />
            Normal EFT
            <p className="text-xs font-normal mt-0.5 opacity-70">1-2 business days · No fee</p>
          </button>
          <button type="button" onClick={() => update("eftType", "immediate")}
            className={`py-3 px-3 rounded-xl border-2 text-sm font-semibold transition-all ${form.eftType === "immediate" ? "border-orange-500 bg-orange-50 text-orange-700" : "border-gray-200 text-gray-500"}`}>
            <Zap className="w-4 h-4 mx-auto mb-1" />
            Immediate EFT
            <p className="text-xs font-normal mt-0.5 opacity-70">Instant · {IMMEDIATE_FEE_PERCENT}% fee</p>
          </button>
        </div>
        {form.eftType === "immediate" && amt > 0 && (
          <div className="mt-2 bg-orange-50 border border-orange-200 rounded-lg px-3 py-2 text-xs text-orange-700">
            Fee: <strong>${fee.toFixed(2)}</strong> · Total deducted: <strong>${totalDeduction.toLocaleString("en-US", { minimumFractionDigits: 2 })}</strong>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Amount */}
        <div>
          <label className="block text-sm text-gray-600 mb-1">Amount</label>
          <div className="flex items-center border border-gray-200 rounded overflow-hidden">
            <div className="px-3 py-3 bg-gray-50 border-r border-gray-200">
              <DollarSign className="w-4 h-4 text-gray-500" />
            </div>
            <input type="number" placeholder="Amount" value={form.amount} onChange={e => update("amount", e.target.value)}
              className="flex-1 px-3 py-3 text-sm outline-none text-gray-700 placeholder-gray-400" />
          </div>
        </div>

        {/* Internal Transfer Fields */}
        {form.transferMode === "internal" ? (
          <div>
            <label className="block text-sm text-gray-600 mb-1">Recipient's CraftCredit Account Number</label>
            <input type="text" placeholder="Enter account number" value={form.internalAccountNumber}
              onChange={e => handleInternalLookup(e.target.value)}
              className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400" />
            {lookingUp && <p className="text-xs text-gray-400 mt-1">Looking up account...</p>}
            {!lookingUp && form.internalAccountNumber.length >= 8 && internalAccount && (
              <div className="mt-2 bg-green-50 border border-green-200 rounded-lg px-3 py-2 text-xs text-green-700 font-semibold">
                ✓ {internalAccount.fullName} — {internalAccount.accountType || "Account"}
              </div>
            )}
            {!lookingUp && form.internalAccountNumber.length >= 8 && !internalAccount && (
              <p className="text-xs text-red-500 mt-1">Account not found in CraftCredit system.</p>
            )}
          </div>
        ) : (
          <>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Beneficiary Account Name</label>
              <input type="text" placeholder="Beneficiary Account Name" value={form.beneficiaryName} onChange={e => update("beneficiaryName", e.target.value)}
                className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Bank Name</label>
              <input type="text" placeholder="Bank Name" value={form.bankName} onChange={e => update("bankName", e.target.value)}
                className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Beneficiary Account Number</label>
              <input type="text" placeholder="Beneficiary Account Number" value={form.accountNumber} onChange={e => update("accountNumber", e.target.value)}
                className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-1">Select Account Type</label>
              <select value={form.accountType} onChange={e => update("accountType", e.target.value)}
                className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400 text-gray-600">
                {ACCOUNT_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </>
        )}

        <div>
          <label className="block text-sm text-gray-600 mb-1">Narration/Purpose</label>
          <textarea placeholder="Fund Description" value={form.narration} onChange={e => update("narration", e.target.value)}
            rows={3} className="w-full border border-gray-200 rounded px-4 py-3 text-sm outline-none focus:border-blue-400 resize-none" />
        </div>

        <div className="flex justify-center pt-2">
          <button type="submit" disabled={loading}
            className={`flex items-center gap-2 text-white px-8 py-3 rounded font-semibold disabled:opacity-60 ${form.eftType === "immediate" ? "bg-orange-500 hover:bg-orange-600" : "bg-blue-600 hover:bg-blue-700"}`}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : form.eftType === "immediate" ? <Zap className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            {loading ? "Processing..." : form.eftType === "immediate" ? "Send Immediately" : "Transfer"}
          </button>
        </div>
      </form>

      {receipt && <TransferReceipt tx={receipt} onClose={() => setReceipt(null)} />}
    </div>
  );
}