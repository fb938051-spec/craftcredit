import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  Plus, Copy, Search, ChevronLeft, ChevronRight,
  ChevronDown, ChevronUp, AlertTriangle, ShieldAlert, Snowflake, Ban, ArrowUpRight, ArrowDownLeft, Clock, CheckCircle, XCircle, RotateCcw
} from "lucide-react";

function BankingDetailsModal({ onClose }) {
  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");
  const details = [
    { label: "Bank Name", value: "CraftCredit Finance Bank" },
    { label: "Account Number", value: bankUser.accountNumber || "—" },
    { label: "Account Type", value: bankUser.accountType || "—" },
    { label: "Routing Number", value: "362583736" },
    { label: "Swift Code", value: "RHYU79F" },
  ];
  const [copied, setCopied] = useState(null);

  const copy = (val, label) => {
    navigator.clipboard.writeText(val);
    setCopied(label);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden">
        <div className="bg-blue-600 px-5 py-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Banking Details</h2>
            <button onClick={onClose} className="text-white/70 hover:text-white text-xl leading-none">✕</button>
          </div>
          <p className="text-blue-100 text-xs mt-1">Share these details to receive payments</p>
        </div>
        <div className="p-5 space-y-4">
          {details.map(d => (
            <div key={d.label}>
              <label className="block text-xs text-gray-400 font-medium mb-1">{d.label}</label>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-800 font-medium">{d.value}</div>
                <button onClick={() => copy(d.value, d.label)}
                  className={`flex items-center gap-1 text-xs px-3 py-2.5 rounded-lg font-semibold transition-colors ${copied === d.label ? "bg-green-500 text-white" : "bg-blue-600 text-white hover:bg-blue-700"}`}>
                  <Copy className="w-3 h-3" />{copied === d.label ? "Copied!" : "Copy"}
                </button>
              </div>
            </div>
          ))}
        </div>
        <div className="px-5 pb-5">
          <button onClick={onClose} className="w-full py-2.5 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 font-medium transition-colors">Close</button>
        </div>
      </div>
    </div>
  );
}

const STATUS_WARNING = {
  frozen: { icon: Snowflake, bg: "bg-blue-50 border-blue-300", text: "text-blue-800", label: "Account Frozen", msg: "Your account is currently frozen. Transactions are paused." },
  restricted: { icon: ShieldAlert, bg: "bg-amber-50 border-amber-300", text: "text-amber-800", label: "Account Restricted", msg: "Your account has active restrictions." },
  suspended: { icon: Ban, bg: "bg-red-50 border-red-300", text: "text-red-800", label: "Account Suspended", msg: "Your account is suspended. Please contact support immediately." },
  closed: { icon: Ban, bg: "bg-gray-100 border-gray-300", text: "text-gray-700", label: "Account Closed", msg: "This account has been closed." },
};

const TYPE_LABEL = {
  credit: "Credit", debit: "Debit", deposit: "Deposit",
  wire_transfer: "Wire Transfer", domestic_transfer: "Domestic Transfer", loan_disbursement: "Loan Disbursement",
};

const TX_STATUS_BADGE = {
  processing: "bg-amber-100 text-amber-700",
  completed: "bg-green-100 text-green-700",
  declined: "bg-red-100 text-red-700",
  reversed: "bg-purple-100 text-purple-700",
};

export default function Dashboard() {
  const [depositOpen, setDepositOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);
  const [bankingDetails, setBankingDetails] = useState(false);
  const [search, setSearch] = useState("");
  const [results, setResults] = useState(7);
  const [balance, setBalance] = useState(0);
  const [account, setAccount] = useState(null);
  const [recentTxs, setRecentTxs] = useState([]);

  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");
  const userName = bankUser.name || "Account Holder";
  const profileImage = bankUser.profileImage || null;

  useEffect(() => {
    if (!bankUser.accountNumber) return;
    base44.entities.BankAccount.filter({ accountNumber: bankUser.accountNumber }).then(accounts => {
      if (accounts.length > 0) {
        setBalance(accounts[0].balance || 0);
        setAccount(accounts[0]);
      }
    });
    base44.entities.Transaction.filter({ accountNumber: bankUser.accountNumber }, "-created_date", 50).then(setRecentTxs);
  }, [bankUser.accountNumber]);

  const status = account?.status || "active";
  const isRestricted = status !== "active";
  const statusWarning = STATUS_WARNING[status];

  const creditTxs = recentTxs.filter(t => ["credit", "debit", "deposit", "loan_disbursement"].includes(t.type));
  const domesticTxs = recentTxs.filter(t => t.type === "domestic_transfer");
  const wireTxs = recentTxs.filter(t => t.type === "wire_transfer");

  const displayedDomestic = domesticTxs
    .filter(t => !search || (t.beneficiaryName || "").toLowerCase().includes(search.toLowerCase()) || (t.reference || "").toLowerCase().includes(search.toLowerCase()))
    .slice(0, results);

  return (
    <div className={`bg-gray-100 min-h-screen ${isRestricted ? "animate-pulse-slow" : ""}`}>

      {/* Account Status Warning Banner */}
      {statusWarning && (
        <div className={`mx-3 mt-3 px-4 py-3 rounded-xl border flex items-start gap-3 ${statusWarning.bg}`}>
          <statusWarning.icon className={`w-5 h-5 mt-0.5 flex-shrink-0 ${statusWarning.text}`} />
          <div>
            <p className={`text-sm font-bold ${statusWarning.text}`}>{statusWarning.label}</p>
            <p className={`text-xs mt-0.5 ${statusWarning.text}`}>
              {account?.warningMessage || statusWarning.msg}
            </p>
          </div>
        </div>
      )}

      {/* Custom warning message from admin */}
      {account?.warningMessage && status === "active" && (
        <div className="mx-3 mt-3 px-4 py-3 rounded-xl border border-amber-300 bg-amber-50 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 mt-0.5 flex-shrink-0 text-amber-600" />
          <p className="text-xs text-amber-800">{account.warningMessage}</p>
        </div>
      )}

      {/* Transfer/Withdrawal restrictions notice */}
      {(account?.transferRestricted || account?.withdrawalRestricted) && (
        <div className="mx-3 mt-2 px-4 py-3 rounded-xl border border-red-300 bg-red-50">
          <p className="text-xs font-semibold text-red-700 mb-1">Account Restrictions Active:</p>
          <ul className="text-xs text-red-600 space-y-0.5">
            {account.transferRestricted && <li>• Outgoing transfers are blocked</li>}
            {account.withdrawalRestricted && <li>• Withdrawals are blocked</li>}
          </ul>
        </div>
      )}

      {/* Balance Card */}
      <div className={`bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 px-4 pt-4 pb-10 mt-2 ${isRestricted ? "opacity-80" : ""}`}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-white/40 flex-shrink-0">
              {profileImage ? (
                <img src={profileImage} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-white/20 flex items-center justify-center">
                  <span className="text-white text-xs font-bold">{userName[0]}</span>
                </div>
              )}
            </div>
            <span className="text-white text-sm font-semibold">{userName}</span>
          </div>
          <button onClick={() => setBankingDetails(true)}
            className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors">
            <Plus className="w-4 h-4 text-white" />
          </button>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-white text-base font-medium">Balance :</span>
          <span className="text-white text-2xl font-bold">${balance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</span>
        </div>
      </div>

      {/* Main content */}
      <div className={`px-3 -mt-6 space-y-3 pb-8 ${isRestricted ? "pointer-events-none opacity-70" : ""}`}>

        {/* Deposit / Transfer dropdowns */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <button onClick={() => { setDepositOpen(v => !v); setTransferOpen(false); }}
              className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold text-gray-700">
              <span>Deposit</span>
              {depositOpen ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
            </button>
            {depositOpen && (
              <div className="px-3 pb-3">
                <Link to="/dashboard/deposit" className="block w-full bg-green-500 text-white text-sm py-2 rounded-lg text-center font-semibold hover:bg-green-600 transition-colors">
                  Deposit
                </Link>
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <button onClick={() => { setTransferOpen(v => !v); setDepositOpen(false); }}
              className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold text-gray-700">
              <span>Transfer</span>
              {transferOpen ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
            </button>
            {transferOpen && (
              <div className="px-3 pb-3 space-y-2">
                <Link to="/dashboard/domestic-transfer" className="block w-full bg-blue-600 text-white text-sm py-2 rounded-lg text-center font-semibold hover:bg-blue-700 transition-colors">
                  Domestic Transfer
                </Link>
                <Link to="/dashboard/wire-transfer" className="block w-full bg-teal-500 text-white text-sm py-2 rounded-lg text-center font-semibold hover:bg-teal-600 transition-colors">
                  Wire Transfer
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Account Overview */}
        <div className="bg-white rounded-xl shadow-sm px-4 py-4 space-y-3">
          <div className="flex justify-center">
            <span className={`text-white text-xs font-bold px-5 py-1.5 rounded-full tracking-wide uppercase ${
              status === "active" ? "bg-green-500" :
              status === "frozen" ? "bg-blue-500" :
              status === "restricted" ? "bg-amber-500" :
              "bg-red-500"
            }`}>{status}</span>
          </div>
          <div className="flex justify-between items-center border-b border-gray-50 pb-2">
            <span className="text-sm text-gray-500">Account Type:</span>
            <span className="text-sm text-gray-800 font-medium">{bankUser.accountType || "—"}</span>
          </div>
          <div className="flex justify-between items-center border-b border-gray-50 pb-2">
            <span className="text-sm text-gray-500">Account Number:</span>
            <span className="text-sm text-gray-800 font-mono">{bankUser.accountNumber || "—"}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-500">Last Login IP:</span>
            <span className="text-sm text-red-500 font-mono">102.90.82.80</span>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-2">
            <Link to="/dashboard/domestic-transfer" className="bg-purple-100 text-purple-700 rounded-full py-2 text-xs font-semibold text-center hover:bg-purple-200 transition-colors">Domestic Transfer</Link>
            <Link to="/dashboard/wire-transfer" className="bg-teal-100 text-teal-700 rounded-full py-2 text-xs font-semibold text-center hover:bg-teal-200 transition-colors">Wire Transfer</Link>
            <Link to="/dashboard/transactions/domestic" className="bg-purple-100 text-purple-700 rounded-full py-2 text-xs font-semibold text-center hover:bg-purple-200 transition-colors">Domestic Transactions</Link>
            <Link to="/dashboard/transactions/wire" className="bg-teal-100 text-teal-700 rounded-full py-2 text-xs font-semibold text-center hover:bg-teal-200 transition-colors">Wire Transactions</Link>
          </div>
        </div>

        {/* Recent Credit/Debit Transactions */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="px-4 py-3 flex items-center justify-between">
            <h3 className="font-bold text-gray-900 text-base">Recent Credit/Debit Transactions</h3>
            <Link to="/dashboard/transactions/credit" className="text-blue-500 text-xs hover:underline">View all</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-teal-100">
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">S/N</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Amount</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Type</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Description</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Status</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Date</th>
                </tr>
              </thead>
              <tbody>
                {creditTxs.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-6 text-gray-400">No transactions yet</td></tr>
                ) : creditTxs.slice(0, 7).map((tx, i) => (
                  <tr key={tx.id} className={`border-t border-gray-50 ${tx.status === "processing" ? "animate-pulse" : ""}`}>
                    <td className="px-3 py-2 text-gray-500">{i + 1}</td>
                    <td className="px-3 py-2 font-bold">
                      <span className={tx.type === "debit" ? "text-red-500" : "text-green-600"}>
                        {tx.type === "debit" ? "-" : "+"}${Number(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-gray-600 whitespace-nowrap">{TYPE_LABEL[tx.type] || tx.type}</td>
                    <td className="px-3 py-2 text-gray-500 max-w-[120px] truncate">{tx.description || "—"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-semibold ${TX_STATUS_BADGE[tx.status || "completed"]}`}>
                        {tx.status || "completed"}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-gray-400 whitespace-nowrap">{tx.created_date ? new Date(tx.created_date).toLocaleDateString() : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Domestic Transactions */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="px-4 py-3 flex items-center justify-between">
            <h3 className="font-bold text-gray-900 text-base">Recent Domestic Transactions</h3>
            <Link to="/dashboard/transactions/domestic" className="text-blue-500 text-xs hover:underline">View all</Link>
          </div>
          <div className="px-4 pb-2 flex items-center gap-2">
            <span className="text-xs text-gray-500">Show:</span>
            <select value={results} onChange={e => setResults(Number(e.target.value))}
              className="border border-gray-300 rounded text-xs px-2 py-1 text-gray-700 bg-white outline-none">
              <option value={7}>7</option><option value={10}>10</option><option value={25}>25</option>
            </select>
          </div>
          <div className="px-4 pb-3">
            <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 gap-2 w-48">
              <Search className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..."
                className="flex-1 text-xs outline-none text-gray-600 placeholder:text-gray-400" />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-teal-100">
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">S/N</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Amount</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Reference</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Recipient</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Status</th>
                  <th className="text-left px-3 py-2.5 text-gray-600 font-semibold">Date</th>
                </tr>
              </thead>
              <tbody>
                {displayedDomestic.length === 0 ? (
                  <tr><td colSpan={6} className="text-center py-4 text-gray-400">No data available in table</td></tr>
                ) : displayedDomestic.map((tx, i) => (
                  <tr key={tx.id} className={`border-t border-gray-50 ${tx.status === "processing" ? "animate-pulse" : ""}`}>
                    <td className="px-3 py-2 text-gray-500">{i + 1}</td>
                    <td className="px-3 py-2 text-red-500 font-bold">-${Number(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                    <td className="px-3 py-2 font-mono text-gray-500 whitespace-nowrap">{tx.reference || "—"}</td>
                    <td className="px-3 py-2 text-gray-700">{tx.beneficiaryName || "—"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${TX_STATUS_BADGE[tx.status || "completed"]}`}>
                        {tx.status || "completed"}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-gray-400 whitespace-nowrap">{tx.created_date ? new Date(tx.created_date).toLocaleDateString() : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 text-center text-xs text-gray-400 border-t border-gray-50">
            Showing {displayedDomestic.length} of {domesticTxs.length} entries
          </div>
          <div className="px-4 pb-4 flex items-center gap-2">
            <button className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded hover:bg-gray-50 transition-colors">
              <ChevronLeft className="w-4 h-4 text-gray-600" />
            </button>
            <button className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded hover:bg-gray-50 transition-colors">
              <ChevronRight className="w-4 h-4 text-gray-600" />
            </button>
          </div>
        </div>

      </div>

      {bankingDetails && <BankingDetailsModal onClose={() => setBankingDetails(false)} />}
    </div>
  );
}