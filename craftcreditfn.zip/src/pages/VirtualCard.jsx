import React, { useState } from "react";
import DashboardLayout from "../components/dashboard/DashboardLayout";

function generateCardNumber() {
  const prefixes = { visa: "4", mastercard: "5", discover: "6011", amex: "37" };
  const rand = () => Math.floor(Math.random() * 10000).toString().padStart(4, "0");
  const type = Math.random() > 0.5 ? "discover" : "visa";
  if (type === "discover") return { number: `6011 ${rand()} ${rand()} ${rand()}`, type: "discover", color: "from-purple-500 to-purple-800" };
  return { number: `4${rand().slice(1)} ${rand()} ${rand()} ${rand()}`, type: "visa", color: "from-gray-500 to-gray-800" };
}

export default function VirtualCard() {
  const [card, setCard] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const name = "Thomas James";
  const expiry = "07/26";
  const cvv = "897";

  const handleGenerate = () => {
    setCard(generateCardNumber());
  };

  return (
    <DashboardLayout>
      <div className="p-5 pb-16">
        {!submitted ? (
          <>
            <h1 className="text-2xl font-light text-gray-800 text-center mb-6">Generate Credit Card</h1>

            {/* Card preview */}
            <div className={`w-full max-w-xs mx-auto rounded-2xl p-5 mb-6 bg-gradient-to-br ${card ? card.color : "from-gray-400 to-gray-700"} shadow-lg`}>
              <div className="flex justify-between items-start mb-6">
                <div className="w-10 h-8 bg-gray-200 rounded flex items-center justify-center">
                  <div className="w-6 h-4 border-2 border-gray-400 rounded" />
                </div>
                {card?.type === "discover" && <span className="text-white font-bold text-sm">DISCOVER</span>}
                {card?.type === "visa" && <span className="text-white font-bold italic text-lg">VISA</span>}
              </div>
              <div>
                <p className="text-white/60 text-xs mb-0.5">card number</p>
                <p className="text-white font-mono text-base tracking-wider">{card?.number || "0000 0000 0000 0000"}</p>
              </div>
              <div className="flex justify-between mt-4">
                <div>
                  <p className="text-white/60 text-xs mb-0.5">cardholder name</p>
                  <p className="text-white text-xs font-semibold uppercase">{name}</p>
                </div>
                <div className="text-right">
                  <p className="text-white/60 text-[10px]">expiration</p>
                  <p className="text-white/60 text-[10px]">VALID THRU ▶</p>
                  <p className="text-white text-xs font-semibold">{expiry}</p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-500 block mb-1">Name</label>
                <input className="w-full px-3 py-3 bg-gray-100 rounded text-sm text-gray-500 outline-none" value={name} readOnly />
              </div>
              <div>
                <label className="text-sm text-gray-500 block mb-1">Card Number</label>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-gray-100 rounded px-3 py-3 text-sm text-gray-500 font-mono">
                    {card?.number || ""}
                  </div>
                  <button onClick={handleGenerate} className="px-3 py-3 bg-blue-600 text-white text-xs font-semibold rounded whitespace-nowrap">
                    Generate Card
                  </button>
                  {card && (
                    <div className="w-12 h-8 flex items-center justify-center bg-gray-800 rounded">
                      <span className="text-white text-[8px] font-bold uppercase">{card.type}</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm text-gray-500 block mb-1">Expiration (mm/yy)</label>
                  <input className="w-full px-3 py-3 bg-gray-100 rounded text-sm text-gray-500 outline-none" value={expiry} readOnly />
                </div>
                <div>
                  <label className="text-sm text-gray-500 block mb-1">Security Code</label>
                  <input className="w-full px-3 py-3 bg-gray-100 rounded text-sm text-gray-500 outline-none" value={cvv} readOnly />
                </div>
              </div>
              <div className="flex justify-center pt-2">
                <button onClick={() => card && setSubmitted(true)} className="px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700">Submit</button>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* Success banner */}
            <div className="bg-teal-400 text-white px-4 py-3 flex justify-between items-center -mx-5 -mt-5 mb-5 rounded-t">
              <span className="text-sm font-medium">Credit Card Submit Successfully</span>
              <button onClick={() => setSubmitted(false)} className="text-white font-bold">CLOSE</button>
            </div>

            {/* Card display */}
            <div className="bg-blue-700 rounded-2xl p-4 mb-5 max-w-xs mx-auto">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <p className="text-white/60 text-xs">cinnioncpf</p>
                  <p className="text-white text-sm font-bold">Debit Card</p>
                </div>
                <p className="text-white/60 text-xs">We understand your world</p>
              </div>
              {/* Colorful grid */}
              <div className="grid grid-cols-4 gap-1 mb-3">
                {["bg-gray-200","bg-purple-500","bg-pink-600","bg-teal-400","bg-purple-700","bg-pink-700","bg-purple-400","bg-pink-500"].map((c,i)=>(
                  <div key={i} className={`h-8 rounded ${c}`} />
                ))}
              </div>
              <p className="text-white font-mono text-sm tracking-widest mb-2">{card?.number}</p>
              <div className="flex justify-between items-center">
                <p className="text-white text-xs font-semibold uppercase">{name}</p>
                <p className="text-white text-sm font-bold">DISCOVER</p>
              </div>
              <p className="text-white/60 text-xs">VALID UP TO {expiry}</p>
            </div>

            <div className="flex justify-center mb-4">
              <span className="px-6 py-1.5 bg-blue-600 text-white text-xs font-bold rounded">PROCESSING</span>
            </div>

            <div className="space-y-2 mb-5">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Card Limit</span>
                <span className="font-semibold">$ 5,000</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Card Limit Remain</span>
                <span className="font-semibold text-red-500">$ 5,000</span>
              </div>
            </div>

            <div className="flex justify-center">
              <button onClick={() => { setCard(null); setSubmitted(false); }} className="px-8 py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700">New Card</button>
            </div>
          </>
        )}
        <p className="text-center text-xs text-gray-400 mt-8">Copyright © 2025 Cinnioncpf Finance Bank. All rights reserved.</p>
      </div>
    </DashboardLayout>
  );
}