import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Lock } from "lucide-react";

export default function PinEntry() {
  const navigate = useNavigate();
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");

  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");
  const accounts = JSON.parse(localStorage.getItem("bankAccounts") || "[]");
  const userAccount = accounts.find(a => a.accountNumber === bankUser.accountNumber);
  const profileImage = bankUser.profileImage || null;

  const handleKey = (val) => {
    if (val === "X") {
      setPin(p => p.slice(0, -1));
      setError("");
    } else if (val === "C") {
      setPin("");
      setError("");
    } else if (pin.length < 6) {
      setPin(p => p + val);
    }
  };

  const isAdmin = bankUser.isAdmin === true && bankUser.accountNumber === "6533338597";

  const handleSubmit = () => {
    if (pin.length < 4) {
      setError("Please enter at least 4 digits.");
      return;
    }
    // Admin uses hardcoded PIN
    if (isAdmin) {
      if (pin !== "1234") {
        setError("Incorrect PIN. Please try again.");
        setPin("");
        return;
      }
      navigate("/admin");
      return;
    }
    if (!userAccount || userAccount.pin !== pin) {
      setError("Incorrect PIN. Please try again.");
      setPin("");
      return;
    }
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <div className="h-48 relative overflow-hidden">
        <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&h=300&fit=crop" alt="bank" className="w-full h-full object-cover" />
      </div>

      <div className="flex-1 flex items-start justify-center -mt-6 px-4 pb-8">
        <div className="bg-white w-full max-w-sm rounded-2xl shadow-lg p-6">
          {/* User info */}
          <div className="flex items-center gap-3 mb-4">
            {profileImage ? (
              <img src={profileImage} alt="user" className="w-12 h-12 rounded-full border-2 border-purple-300 object-cover flex-shrink-0" />
            ) : (
              <div className="w-12 h-12 rounded-full bg-blue-100 border-2 border-purple-300 flex items-center justify-center flex-shrink-0">
                <span className="text-blue-600 font-bold text-lg">{(bankUser.name || "U")[0]}</span>
              </div>
            )}
            <span className="text-lg font-semibold text-gray-800">{bankUser.name || "Account Holder"}</span>
          </div>

          <h2 className="text-2xl font-semibold text-gray-800 text-center">Welcome</h2>
          <p className="text-blue-500 text-sm text-center mb-5">Enter PIN</p>

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded px-3 py-2 mb-3 text-center font-medium">{error}</div>
          )}

          <div className="mb-5">
            <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider block mb-2">PINCODE</label>
            <div className="flex items-center border border-gray-200 rounded px-3 py-3 gap-2">
              <Lock className="w-4 h-4 text-gray-300" />
              <div className="flex-1 text-sm text-gray-700 tracking-widest">
                {pin.length > 0 ? "•".repeat(pin.length) : <span className="text-gray-300">PINCODE</span>}
              </div>
            </div>
          </div>

          {/* Number pad */}
          <div className="grid grid-cols-3 gap-3 mb-5">
            {["1","2","3","4","5","6","7","8","9","X","0","C"].map(k => (
              <button
                key={k}
                onClick={() => handleKey(k)}
                className="h-12 w-12 mx-auto rounded-full border-2 border-blue-600 text-blue-600 font-semibold text-lg flex items-center justify-center hover:bg-blue-50 active:bg-blue-100 transition-colors"
              >
                {k}
              </button>
            ))}
          </div>

          <button
            onClick={handleSubmit}
            className="w-full py-3 bg-blue-600 text-white font-semibold rounded text-sm hover:bg-blue-700 transition-colors"
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}