import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard, DollarSign, Upload, Download, Wifi,
  CreditCard, Settings, ChevronDown, ChevronRight,
  Bell, MessageCircle, Menu, X, User, Inbox, LogOut
} from "lucide-react";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: DollarSign, label: "Online Deposit", path: "/dashboard/deposit" },
  {
    icon: Upload, label: "Transfer Funds", path: "/dashboard/transfer",
    children: [
      { label: "Domestic Transfer", path: "/dashboard/domestic-transfer" },
      { label: "Wire Transfer", path: "/dashboard/wire-transfer" },
    ]
  },
  { icon: Download, label: "Loan & Mortgages", path: "/dashboard/loan" },
  {
    icon: Wifi, label: "Transaction", path: "/dashboard/transactions",
    children: [
      { label: "Credit / Debit Transactions", path: "/dashboard/transactions/credit" },
      { label: "Wire Transaction", path: "/dashboard/transactions/wire" },
      { label: "Domestic Transaction", path: "/dashboard/transactions/domestic" },
      { label: "Loan Transaction", path: "/dashboard/transactions/loan" },
    ]
  },
  { icon: CreditCard, label: "Virtual Card", path: "/dashboard/virtual-card" },
  {
    icon: Settings, label: "Settings", path: "/dashboard/settings",
    children: [
      { label: "Account Profile", path: "/dashboard/settings/profile" },
      { label: "Account Settings", path: "/dashboard/settings/account" },
    ]
  },
];

export default function DashboardLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expanded, setExpanded] = useState({});
  const [profileMenu, setProfileMenu] = useState(false);
  const location = useLocation();

  const toggle = (label) => setExpanded(e => ({ ...e, [label]: !e[label] }));
  const isActive = (path) => location.pathname === path;
  const isParentActive = (item) => item.children?.some(c => location.pathname === c.path) || location.pathname === item.path;

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Top bar */}
      <div className="bg-blue-600 h-14 flex items-center justify-between px-4 fixed top-0 left-0 right-0 z-50">
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-white">
          <Menu className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-4">
          <button className="text-white relative">
            <MessageCircle className="w-5 h-5" />
          </button>
          <button className="text-white relative">
            <Bell className="w-5 h-5" />
          </button>
          <button onClick={() => setProfileMenu(!profileMenu)} className="text-white relative">
            <Settings className="w-5 h-5" />
            {profileMenu && (
              <div className="absolute right-0 top-8 bg-white rounded-xl shadow-xl w-52 z-50 overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-100 flex items-center gap-3">
                  <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=60&h=60&fit=crop&crop=face" alt="" className="w-9 h-9 rounded-full object-cover" />
                  <div className="text-left">
                    <p className="font-semibold text-gray-800 text-sm">Thomas James</p>
                    <p className="text-xs text-gray-400">Current</p>
                  </div>
                </div>
                <Link to="/dashboard/settings/profile" className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50">
                  <User className="w-4 h-4 text-gray-400" /> My Profile
                </Link>
                <Link to="/dashboard" className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50">
                  <Inbox className="w-4 h-4 text-gray-400" /> My Inbox
                </Link>
                <Link to="/" className="flex items-center gap-3 px-4 py-3 text-sm text-red-500 hover:bg-gray-50">
                  <LogOut className="w-4 h-4" /> Log Out
                </Link>
              </div>
            )}
          </button>
        </div>
      </div>

      <div className="flex pt-14 flex-1">
        {/* Sidebar overlay */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-40 flex">
            <div className="w-64 bg-white h-full shadow-xl overflow-y-auto flex flex-col">
              {/* User */}
              <div className="px-5 pt-6 pb-4 flex flex-col items-center border-b border-gray-100">
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
                    alt="user"
                    className="w-16 h-16 rounded-full object-cover border-4 border-purple-200"
                  />
                </div>
                <p className="font-bold text-gray-900 mt-2 text-sm">Thomas James</p>
                <p className="text-xs text-gray-400">Current</p>
              </div>

              {/* Nav */}
              <nav className="py-2 flex-1">
                {navItems.map(item => (
                  <div key={item.label}>
                    {item.children ? (
                      <>
                        <button
                          onClick={() => toggle(item.label)}
                          className={`w-full flex items-center gap-3 px-5 py-3.5 text-sm font-medium transition-colors
                            ${isParentActive(item) ? "bg-blue-600 text-white" : "text-gray-600 hover:bg-gray-50"}`}
                        >
                          <item.icon className="w-4 h-4 flex-shrink-0" />
                          <span className="flex-1 text-left">{item.label}</span>
                          {expanded[item.label] ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                        </button>
                        {expanded[item.label] && (
                          <div className="bg-gray-50">
                            {item.children.map(child => (
                              <Link
                                key={child.path}
                                to={child.path}
                                onClick={() => setSidebarOpen(false)}
                                className={`block pl-12 pr-5 py-3 text-sm transition-colors
                                  ${isActive(child.path) ? "text-blue-600 font-semibold" : "text-gray-500 hover:text-blue-600"}`}
                              >
                                · {child.label}
                              </Link>
                            ))}
                          </div>
                        )}
                      </>
                    ) : (
                      <Link
                        to={item.path}
                        onClick={() => setSidebarOpen(false)}
                        className={`flex items-center gap-3 px-5 py-3.5 text-sm font-medium transition-colors
                          ${isActive(item.path) ? "bg-blue-600 text-white" : "text-gray-600 hover:bg-gray-50"}`}
                      >
                        <item.icon className="w-4 h-4 flex-shrink-0" />
                        {item.label}
                      </Link>
                    )}
                  </div>
                ))}
              </nav>
            </div>
            <div className="flex-1 bg-black/30" onClick={() => setSidebarOpen(false)} />
          </div>
        )}

        {/* Main content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}