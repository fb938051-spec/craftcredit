import React from "react";
import { CheckCircle, Clock, X, Printer } from "lucide-react";

export default function TransferReceipt({ tx, onClose }) {
  const date = tx.created_date ? new Date(tx.created_date).toLocaleString() : new Date().toLocaleString();
  const isCompleted = tx.status === "completed";
  const isImmediate = tx.eftType === "immediate";

  const handlePrint = () => {
    const printContent = `
      <html>
      <head>
        <title>Transfer Receipt - ${tx.reference}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 30px; color: #111; max-width: 400px; margin: 0 auto; }
          h1 { text-align: center; color: #1d4ed8; font-size: 18px; margin-bottom: 4px; }
          .bank { text-align: center; color: #555; font-size: 12px; margin-bottom: 20px; }
          .amount { text-align: center; font-size: 28px; font-weight: bold; margin: 16px 0 4px; }
          .status { text-align: center; margin-bottom: 20px; }
          .badge { display: inline-block; padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; }
          .badge-green { background: #dcfce7; color: #166534; }
          .badge-amber { background: #fef3c7; color: #92400e; }
          .divider { border-top: 1px solid #e5e7eb; margin: 14px 0; }
          .row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 13px; }
          .label { color: #9ca3af; }
          .value { font-weight: 600; text-align: right; max-width: 60%; }
          .footer { text-align: center; font-size: 11px; color: #9ca3af; margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 14px; }
        </style>
      </head>
      <body>
        <h1>CraftCredit Finance Bank</h1>
        <div class="bank">Official Transfer Receipt</div>
        <div class="divider"></div>
        <div class="amount">$${Number(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
        <div class="status">
          <span class="badge ${isCompleted ? "badge-green" : "badge-amber"}">${isCompleted ? "✓ Completed" : "⏱ Processing"}</span>
        </div>
        <div class="divider"></div>
        <div class="row"><span class="label">Reference</span><span class="value">${tx.reference || "—"}</span></div>
        <div class="row"><span class="label">Transfer Type</span><span class="value">${(tx.type || "").replace(/_/g, " ").toUpperCase()} ${isImmediate ? "(Immediate EFT)" : "(Normal EFT)"}</span></div>
        <div class="row"><span class="label">Recipient</span><span class="value">${tx.beneficiaryName || "—"}</span></div>
        <div class="row"><span class="label">Recipient Bank</span><span class="value">${tx.beneficiaryBank || "—"}</span></div>
        <div class="row"><span class="label">Recipient Account</span><span class="value">${tx.beneficiaryAccount || "—"}</span></div>
        ${tx.beneficiaryCountry ? `<div class="row"><span class="label">Country</span><span class="value">${tx.beneficiaryCountry}</span></div>` : ""}
        ${tx.fee ? `<div class="row"><span class="label">Transaction Fee</span><span class="value">$${Number(tx.fee).toFixed(2)}</span></div>` : ""}
        <div class="row"><span class="label">Narration</span><span class="value">${tx.narration || tx.description || "—"}</span></div>
        <div class="row"><span class="label">Date & Time</span><span class="value">${date}</span></div>
        <div class="footer">
          This is an official receipt from CraftCredit Finance Bank.<br/>
          Printed on ${new Date().toLocaleString()}
        </div>
      </body>
      </html>
    `;
    const win = window.open("", "_blank", "width=500,height=700");
    win.document.write(printContent);
    win.document.close();
    win.focus();
    win.print();
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl overflow-hidden">
        {/* Header */}
        <div className={`px-5 py-4 flex items-center justify-between ${isCompleted ? "bg-green-600" : "bg-blue-600"}`}>
          <h2 className="text-white font-bold text-base">Transfer Receipt</h2>
          <button onClick={onClose} className="text-white/70 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Icon */}
        <div className="flex flex-col items-center pt-6 pb-4">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-3 ${isCompleted ? "bg-green-100" : "bg-amber-100"}`}>
            {isCompleted
              ? <CheckCircle className="w-9 h-9 text-green-500" />
              : <Clock className="w-9 h-9 text-amber-500" />
            }
          </div>
          <p className="text-gray-500 text-sm font-medium">{isCompleted ? "Transfer Successful" : "Transfer Submitted"}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">
            ${Number(tx.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
          </p>
          <span className={`mt-2 px-3 py-1 rounded-full text-xs font-semibold ${isCompleted ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}`}>
            {isCompleted ? "✓ Completed" : "⏱ Processing"}
          </span>
        </div>

        {/* Details */}
        <div className="px-5 pb-5 space-y-2.5">
          {[
            ["Reference", tx.reference || "—"],
            ["Transfer Type", `${(tx.type || "").replace(/_/g, " ").toUpperCase()} ${isImmediate ? "(Immediate EFT)" : "(Normal EFT)"}`],
            ["Recipient", tx.beneficiaryName || "—"],
            ["Recipient Bank", tx.beneficiaryBank || "—"],
            ["Recipient Account", tx.beneficiaryAccount || "—"],
            tx.beneficiaryCountry ? ["Country", tx.beneficiaryCountry] : null,
            tx.fee ? ["Transaction Fee", `$${Number(tx.fee).toFixed(2)}`] : null,
            ["Narration", tx.narration || tx.description || "—"],
            ["Date & Time", date],
          ].filter(Boolean).map(([label, value]) => (
            <div key={label} className="flex justify-between items-start gap-3">
              <span className="text-xs text-gray-400 flex-shrink-0">{label}</span>
              <span className="text-xs text-gray-800 font-medium text-right break-all">{value}</span>
            </div>
          ))}

          {!isCompleted && (
            <div className="border-t border-gray-100 pt-3 mt-2 text-xs text-gray-400 text-center">
              Your transfer is being processed and will be completed shortly.
            </div>
          )}

          <div className="flex gap-2 mt-3">
            {isCompleted && (
              <button
                onClick={handlePrint}
                className="flex-1 flex items-center justify-center gap-2 py-3 border border-blue-200 text-blue-600 font-semibold rounded-xl text-sm hover:bg-blue-50 transition-colors"
              >
                <Printer className="w-4 h-4" /> Print Receipt
              </button>
            )}
            <button
              onClick={onClose}
              className={`py-3 font-semibold rounded-xl text-sm transition-colors text-white ${isCompleted ? "flex-1 bg-green-600 hover:bg-green-700" : "w-full bg-blue-600 hover:bg-blue-700"}`}
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}