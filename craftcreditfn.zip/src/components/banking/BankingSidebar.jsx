import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Home, DollarSign, Upload, Download, Wifi, CreditCard, Settings,
  ChevronDown, ChevronRight, X, ShieldCheck
} from "lucide-react";

const NAV = [
  { label: "Dashboard", icon: Home, path: "/dashboard" },
  { label: "Online Deposit", icon: DollarSign, path: "/dashboard/deposit" },
  {
    label: "Transfer Funds", icon: Upload, path: null,
    children: [
      { label: "Domestic Transfer", path: "/dashboard/domestic-transfer" },
      { label: "Wire Transfer", path: "/dashboard/wire-transfer" },
    ]
  },
  { label: "Loan & Mortgages", icon: Download, path: "/dashboard/loan" },
  {
    label: "Transaction", icon: Wifi, path: null,
    children: [
      { label: "Credit / Debit Transaction", path: "/dashboard/transactions/credit" },
      { label: "Wire Transaction", path: "/dashboard/transactions/wire" },
      { label: "Domestic Transaction", path: "/dashboard/transactions/domestic" },
      { label: "Loan Transaction", path: "/dashboard/transactions/loan" },
    ]
  },
  { label: "Virtual Card", icon: CreditCard, path: "/dashboard/virtual-card" },
  {
    label: "Settings", icon: Settings, path: null,
    children: [
      { label: "Account Profile", path: "/dashboard/profile" },
      { label: "Account Settings", path: "/dashboard/settings" },
    ]
  },
];

export default function BankingSidebar({ open, onClose }) {
  const location = useLocation();
  const [expanded, setExpanded] = useState({});
  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");
  const userName = bankUser.name || "Account Holder";
  const accountType = bankUser.accountType || "";
  const isAdmin = bankUser.accountNumber === "6533338597";

  const toggle = (label) => setExpanded(e => ({ ...e, [label]: !e[label] }));

  const isActive = (path) => path && location.pathname === path;
  const isParentActive = (children) => children?.some(c => location.pathname === c.path);

  return (
    <>
      {/* Overlay */}
      {open && <div className="fixed inset-0 bg-black/40 z-40" onClick={onClose} />}

      <div className={`fixed top-0 left-0 h-full w-64 bg-white shadow-2xl z-50 transform transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full"} overflow-y-auto`}>
        {/* User profile */}
        <div className="p-6 pb-4 border-b border-gray-100">
          <div className="flex justify-end mb-2">
            <button onClick={onClose}><X className="w-5 h-5 text-gray-400" /></button>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-full overflow-hidden border-4 border-purple-200 mb-2">
              <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face" alt="" className="w-full h-full object-cover" />
            </div>
            <div className="font-bold text-gray-900">{userName}</div>
            <div className="text-xs text-gray-500">{accountType || "Current"}</div>
          </div>
        </div>

        {/* Admin Portal Link — only visible for admin account */}
        {isAdmin && (
          <div className="px-4 pt-3">
            <Link
              to="/admin"
              onClick={onClose}
              className="flex items-center gap-2 w-full bg-gray-900 text-white text-xs font-bold px-4 py-2.5 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              Admin Portal
            </Link>
          </div>
        )}

        {/* Nav */}
        <nav className="py-3">
          {NAV.map(item => (
            <div key={item.label}>
              {item.children ? (
                <>
                  <button
                    onClick={() => toggle(item.label)}
                    className={`w-full flex items-center gap-3 px-5 py-3 text-sm font-medium transition-colors
                      ${isParentActive(item.children) ? "bg-blue-600 text-white" : "text-gray-700 hover:bg-gray-50"}`}
                  >
                    <item.icon className="w-4 h-4 flex-shrink-0" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {expanded[item.label] || isParentActive(item.children)
                      ? <ChevronDown className="w-4 h-4" />
                      : <ChevronRight className="w-4 h-4" />}
                  </button>
                  {(expanded[item.label] || isParentActive(item.children)) && (
                    <div className="pl-12 py-1">
                      {item.children.map(child => (
                        <Link
                          key={child.label}
                          to={child.path}
                          onClick={onClose}
                          className={`block py-2 text-sm ${isActive(child.path) ? "text-blue-600 font-medium" : "text-gray-600 hover:text-blue-600"}`}
                        >
                          · {child.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link
                  to={item.path}
                  onClick={onClose}
                  className={`flex items-center gap-3 px-5 py-3 text-sm font-medium transition-colors
                    ${isActive(item.path) ? "bg-blue-600 text-white" : "text-gray-700 hover:bg-gray-50"}`}
                >
                  <item.icon className="w-4 h-4 flex-shrink-0" />
                  {item.label}
                </Link>
              )}
            </div>
          ))}
        </nav>
      </div>
    </>
  );
}