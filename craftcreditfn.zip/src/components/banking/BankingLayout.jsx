import React, { useState, useRef } from "react";
import { Outlet, Link, useNavigate } from "react-router-dom";
import { Menu, MessageCircle, Bell, Settings, User, Inbox, LogOut } from "lucide-react";
import BankingSidebar from "./BankingSidebar";
import MessagesPanel from "./MessagesPanel";
import NotificationsPanel from "./NotificationsPanel";

export default function BankingLayout() {
  const navigate = useNavigate();
  const bankUser = JSON.parse(localStorage.getItem("bankUser") || "{}");
  const userName = bankUser.name || "Account Holder";
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [messagesOpen, setMessagesOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const lastTap = useRef(0);

  const guard = (fn) => (e) => {
    e.preventDefault();
    e.stopPropagation();
    const now = Date.now();
    if (now - lastTap.current < 400) return;
    lastTap.current = now;
    fn();
  };

  const openMessages = guard(() => { setProfileOpen(false); setNotificationsOpen(false); setMessagesOpen(v => !v); });
  const openNotifications = guard(() => { setProfileOpen(false); setMessagesOpen(false); setNotificationsOpen(v => !v); });
  const openProfile = guard(() => { setMessagesOpen(false); setNotificationsOpen(false); setProfileOpen(v => !v); });

  const handleLogout = () => {
    localStorage.removeItem("bankUser");
    setProfileOpen(false);
    navigate("/signin");
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top navbar */}
      <div className="bg-blue-600 h-12 flex items-center justify-between px-4 sticky top-0 z-30">
        {/* Hamburger - opens sidebar */}
        <button
          onTouchStart={(e) => { e.preventDefault(); setSidebarOpen(true); }}
          onClick={() => setSidebarOpen(true)}
          className="text-white p-2 rounded active:bg-white/30"
        >
          <Menu className="w-6 h-6" />
        </button>

        {/* Right icons */}
        <div className="flex items-center gap-3">
          {/* Chat icon */}
          <button
            onTouchEnd={openMessages}
            onClick={openMessages}
            className="text-white p-2 rounded active:bg-white/30 touch-manipulation"
          >
            <MessageCircle className="w-5 h-5" />
          </button>

          {/* Bell icon */}
          <button
            onTouchEnd={openNotifications}
            onClick={openNotifications}
            className="text-white p-2 rounded active:bg-white/30 touch-manipulation"
          >
            <Bell className="w-5 h-5" />
          </button>

          {/* Settings / Profile dropdown */}
          <button
            onTouchEnd={openProfile}
            onClick={openProfile}
            className="text-white p-2 rounded active:bg-white/30 touch-manipulation"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>



      {/* Messages panel */}
      {messagesOpen && <MessagesPanel onClose={() => setMessagesOpen(false)} />}

      {/* Notifications panel */}
      {notificationsOpen && <NotificationsPanel onClose={() => setNotificationsOpen(false)} />}

      {/* Profile dropdown rendered OUTSIDE the navbar to avoid clipping */}
      {profileOpen && (
        <>
          <div
            className="fixed inset-0 z-[60]"
            onClick={() => setProfileOpen(false)}
          />
          <div className="fixed top-12 right-4 bg-white rounded-xl shadow-2xl w-52 overflow-hidden z-[70]">
            <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 border-b">
              <div className="w-9 h-9 rounded-full overflow-hidden flex-shrink-0">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
                  alt=""
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <div className="text-xs font-bold text-gray-900">{userName}</div>
                <div className="text-xs text-gray-500">Current</div>
              </div>
            </div>
            <Link
              to="/dashboard/profile"
              onClick={() => setProfileOpen(false)}
              className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50"
            >
              <User className="w-4 h-4" /> My Profile
            </Link>
            <Link
              to="/dashboard"
              onClick={() => setProfileOpen(false)}
              className="flex items-center gap-3 px-4 py-3 text-sm text-gray-700 hover:bg-gray-50"
            >
              <Inbox className="w-4 h-4" /> Dashboard
            </Link>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-500 hover:bg-gray-50"
            >
              <LogOut className="w-4 h-4" /> Log Out
            </button>
          </div>
        </>
      )}

      {/* Sidebar */}
      <BankingSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Page content */}
      <div className="min-h-[calc(100vh-3rem)]">
        <Outlet />
      </div>

      {/* Footer */}
      <div className="text-center text-xs text-gray-500 py-4 border-t bg-white">
        Copyright © {new Date().getFullYear()} CraftCredit Finance Bank. All rights reserved.
      </div>
    </div>
  );
}