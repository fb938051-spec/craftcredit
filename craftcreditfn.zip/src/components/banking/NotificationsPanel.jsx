import React from "react";
import { X, Bell, CheckCircle2, AlertCircle, Info } from "lucide-react";

const NOTIFICATIONS = [
  {
    id: 1,
    type: "success",
    title: "Account Activated",
    message: "Your CraftCredit account has been successfully activated.",
    time: "Just now",
    unread: true,
  },
  {
    id: 2,
    type: "info",
    title: "Security Reminder",
    message: "Never share your PIN or password with anyone, including bank staff.",
    time: "1h ago",
    unread: true,
  },
  {
    id: 3,
    type: "warning",
    title: "Profile Incomplete",
    message: "Please complete your profile to unlock all banking features.",
    time: "Yesterday",
    unread: false,
  },
];

const iconMap = {
  success: <CheckCircle2 className="w-4 h-4 text-green-500" />,
  info: <Info className="w-4 h-4 text-blue-500" />,
  warning: <AlertCircle className="w-4 h-4 text-amber-500" />,
};

const bgMap = {
  success: "bg-green-50",
  info: "bg-blue-50",
  warning: "bg-amber-50",
};

export default function NotificationsPanel({ onClose }) {
  const unreadCount = NOTIFICATIONS.filter(n => n.unread).length;

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-[60]" onClick={onClose} />

      {/* Panel */}
      <div
        className="fixed top-12 right-4 bg-white rounded-xl shadow-2xl w-80 z-[70] overflow-hidden border border-gray-100"
        style={{ maxHeight: "calc(100vh - 56px)" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-blue-600">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-white" />
            <span className="font-bold text-white text-sm">Notifications</span>
            {unreadCount > 0 && (
              <span className="bg-white text-blue-600 text-xs font-bold px-1.5 py-0.5 rounded-full leading-none">
                {unreadCount}
              </span>
            )}
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Subheader */}
        <div className="flex items-center justify-between px-4 py-2 bg-gray-50 border-b border-gray-100">
          <span className="text-xs text-gray-500">{unreadCount} unread</span>
          <button className="text-xs text-blue-600 font-medium hover:underline">Mark all as read</button>
        </div>

        {/* Notification list */}
        <div className="overflow-y-auto" style={{ maxHeight: "340px" }}>
          {NOTIFICATIONS.map((notif) => (
            <div
              key={notif.id}
              className={`flex items-start gap-3 px-4 py-3 border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors ${notif.unread ? bgMap[notif.type] + "/40" : ""}`}
            >
              <div className={`w-8 h-8 rounded-full ${bgMap[notif.type]} flex items-center justify-center flex-shrink-0`}>
                {iconMap[notif.type]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <span className={`text-xs text-gray-900 ${notif.unread ? "font-bold" : "font-medium"}`}>
                    {notif.title}
                  </span>
                  <span className="text-[10px] text-gray-400 flex-shrink-0 ml-2">{notif.time}</span>
                </div>
                <p className="text-xs text-gray-500 leading-relaxed">{notif.message}</p>
              </div>
              {notif.unread && (
                <div className="w-2 h-2 rounded-full bg-blue-600 flex-shrink-0 mt-1.5" />
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-gray-50 border-t border-gray-100 text-center">
          <button className="text-xs text-blue-600 font-medium hover:underline">
            View all notifications
          </button>
        </div>
      </div>
    </>
  );
}