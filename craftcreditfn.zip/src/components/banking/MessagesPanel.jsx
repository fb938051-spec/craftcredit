import React from "react";
import { X, MessageCircle, Search } from "lucide-react";

const SAMPLE_MESSAGES = [
  {
    id: 1,
    name: "CraftCredit Support",
    avatar: "CC",
    color: "bg-blue-600",
    message: "Welcome to CraftCredit Finance Bank! We're here to help you 24/7.",
    time: "Just now",
    unread: true,
  },
  {
    id: 2,
    name: "Transaction Alert",
    avatar: "TA",
    color: "bg-green-500",
    message: "Your account has been successfully verified.",
    time: "2h ago",
    unread: false,
  },
];

export default function MessagesPanel({ onClose }) {
  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 z-[60]" onClick={onClose} />

      {/* Panel */}
      <div className="fixed top-12 right-10 bg-white rounded-xl shadow-2xl w-80 z-[70] overflow-hidden border border-gray-100"
        style={{ maxHeight: "calc(100vh - 56px)" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-blue-600">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-white" />
            <span className="font-bold text-white text-sm">Messages</span>
            <span className="bg-white text-blue-600 text-xs font-bold px-1.5 py-0.5 rounded-full leading-none">
              {SAMPLE_MESSAGES.filter(m => m.unread).length}
            </span>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search */}
        <div className="px-3 py-2 border-b border-gray-100 bg-gray-50">
          <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-lg px-3 py-1.5">
            <Search className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
            <input
              className="text-xs outline-none flex-1 text-gray-600 placeholder:text-gray-400"
              placeholder="Search messages..."
            />
          </div>
        </div>

        {/* Message list */}
        <div className="overflow-y-auto" style={{ maxHeight: "320px" }}>
          {SAMPLE_MESSAGES.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 px-4 py-3 border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors ${msg.unread ? "bg-blue-50/40" : ""}`}
            >
              <div className={`w-9 h-9 rounded-full ${msg.color} flex items-center justify-center flex-shrink-0 text-white text-xs font-bold`}>
                {msg.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-0.5">
                  <span className={`text-xs font-semibold text-gray-900 ${msg.unread ? "font-bold" : ""}`}>
                    {msg.name}
                  </span>
                  <span className="text-[10px] text-gray-400 flex-shrink-0 ml-2">{msg.time}</span>
                </div>
                <p className="text-xs text-gray-500 truncate">{msg.message}</p>
              </div>
              {msg.unread && (
                <div className="w-2 h-2 rounded-full bg-blue-600 flex-shrink-0 mt-1.5" />
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-gray-50 border-t border-gray-100 text-center">
          <button className="text-xs text-blue-600 font-medium hover:underline">
            View all messages
          </button>
        </div>
      </div>
    </>
  );
}