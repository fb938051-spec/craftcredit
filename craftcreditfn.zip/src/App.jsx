import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Home from './pages/Home';
import CreateAccount from './pages/CreateAccount';
import SignIn from './pages/SignIn.jsx';
import PinEntry from './pages/PinEntry.jsx';
import BankingLayout from './components/banking/BankingLayout';
import Dashboard from './pages/dashboard/Dashboard.jsx';
import WireTransfer from './pages/dashboard/WireTransfer.jsx';
import DomesticTransfer from './pages/dashboard/DomesticTransfer.jsx';
import Transactions from './pages/dashboard/Transactions.jsx';
import OnlineDeposit from './pages/dashboard/OnlineDeposit';
import LoanMortgages from './pages/dashboard/LoanMortgages.jsx';
import AdminLoans from './pages/admin/AdminLoans.jsx';
import VirtualCard from './pages/dashboard/VirtualCard';
import AccountProfile from './pages/dashboard/AccountProfile';
import AccountSettings from './pages/dashboard/AccountSettings';
import AdminLayout from './pages/admin/AdminLayout';
import AdminOverview from './pages/admin/AdminOverview';
import AdminAccounts from './pages/admin/AdminAccounts';
import AdminFund from './pages/admin/AdminFund';

import AdminClients from './pages/admin/AdminClients';
import AdminActivityLog from './pages/admin/AdminActivityLog';
import AdminTransactions from './pages/admin/AdminTransactions';
import AdminEmail from './pages/admin/AdminEmail';
import AdminRestrictions from './pages/admin/AdminRestrictions';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/create-account" element={<CreateAccount />} />
      <Route path="/signin" element={<SignIn />} />
      <Route path="/pin" element={<PinEntry />} />
      <Route path="/dashboard" element={<BankingLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="deposit" element={<OnlineDeposit />} />
        <Route path="domestic-transfer" element={<DomesticTransfer />} />
        <Route path="wire-transfer" element={<WireTransfer />} />
        <Route path="loan" element={<LoanMortgages />} />
        <Route path="virtual-card" element={<VirtualCard />} />
        <Route path="profile" element={<AccountProfile />} />
        <Route path="settings" element={<AccountSettings />} />
        <Route path="transactions/credit" element={<Transactions />} />
        <Route path="transactions/wire" element={<Transactions />} />
        <Route path="transactions/domestic" element={<Transactions />} />
        <Route path="transactions/loan" element={<Transactions />} />
      </Route>
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminOverview />} />
        <Route path="accounts" element={<AdminAccounts />} />
        <Route path="fund" element={<AdminFund />} />
        <Route path="loans" element={<AdminLoans />} />
        <Route path="clients" element={<AdminClients />} />
        <Route path="transactions" element={<AdminTransactions />} />
        <Route path="activity" element={<AdminActivityLog />} />
        <Route path="email" element={<AdminEmail />} />
        <Route path="restrictions" element={<AdminRestrictions />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;